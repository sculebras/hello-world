﻿using Newtonsoft.Json.Linq;
using Pea.Model;
using SmartFormat;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using static Pea.Model.Constants;

namespace Pea.Business
{

    public class NotifyStateChangeInfo
    {
        public string id { get; set; }
        public EstadoType state { get; set; }
        public string user { get; set; }
        public Role role { get; set; }
        public bool isauto { get; set; }
    }

    class SolicitudBusiness : GenericBusiness<Solicitud>
    {
        static int DuracionMaximaDeSolicitudEnDias = int.Parse(ConfigurationManager.AppSettings["Biz-Solicitud-DiasVencimiento"] ?? "12"); // tanto para created no signed, como para signed
        static string UserNameWorker = Role.Worker.ToString();
        static JObject notificacionConfig = BusinessConfigHelper.notificacionlConfig;

        //Situaciones que disparan el envío de E - mails:

        //Anular de forma Manual:
        //1 Si el LP Anula una solicitud -> Se envía un mail al FSS (puede ser más de una dirección de mail, ya que los FSS de una agencia pueden ser varios) de la agencia.
        //2 Si el FSS Anula una solicitud -> Se envía un mail al LP que generó la solicitud (Writing).

        //Anular Automático(cumplidos los 12 días de firmado):
        //3 4 Por cada solicitud que se haya firmado y no se haya presentado, se envían dos mails de aviso de anulación al LP: 3 días antes y 1 día antes.  
        //5  Una vez anulada se envía un mail a las FSS de la agencia, con copia al LP Writing.

        //Eliminación Automática (cumplidos los 12 días de creada):
        //6 7 Por cada solicitud que haya sido creada y no se haya firmado, se envían dos mails de aviso de eliminación al LP: 3 días antes y 1 día antes.  
        //8 Una vez eliminada se envía un mail de aviso al LP Writing.

        //9 Pasar a Reportada->mail a FSS
        //10 Pasar a Completa(Enviar a control)->mail a FSS

        //La casilla de mail desde la cual se realizará el envío la proveerá Prudential.


        // ocurre ante cada cambio en coleccion solicitud propiedad estado
        public static void ProcesarCambioEstado(Solicitud sol)
        {
            EstadoType estado;
            if (!Enum.TryParse<EstadoType>(sol.Estado, out estado))
            {
                throw new Exception("estado from solicitud " + sol.id + " cant be parsed: " + sol.Estado.ToString());
            }


            var estadoenconf = notificacionConfig[NotificacionType.NuevoEstado.ToString()]?["estados"]?[estado.ToString()];
            // es un cambio de estado o se realizo baja logica automatica
            if (estadoenconf != null || (sol.del && sol.updatedby == Role.Worker.ToString()))
            {
                // si esta configurado en el template de notificaciones lo carga
                CrearNotificacionCambioEstadoManual(sol, estado);
            }

        }



        private static void CrearNotificacionCambioEstadoManual(Solicitud sol, EstadoType estado)
        {
            if (sol.del)
            {
                // este estado no existe en la base es un adhoc para resolver logica post delete, aparece en la tabla de notif
                // case EstadoType.Eliminada: 
                estado = EstadoType.Eliminada;
            }
            Role role;
            var user = UserBusiness.GetMyUserName();
            bool isauto = false;
            if (sol.updatedby == Role.Worker.ToString())
            {
                role = Role.Worker;
                isauto = true;
                user = sol.updatedby;
            }
            else
            {
                var roles = UserBusiness.GetMyRoles();
                role = roles.FirstOrDefault();
            }
            //var not = new NotifyStateChangeInfo { id = sol.id, state = estado, user = user?UserNameWorker, role = role, isauto = user==null?true:false };
            var notificacion = new Notificacion()
            {
                gid = sol.gid,
                id = sol.id,
                ver = sol.ver,
                name = "Solicitud",
                type = NotificacionType.NuevoEstado.ToString(),
                subtype = estado.ToString(),
                created = DateTime.UtcNow,
                updated = DateTime.UtcNow,
                updatedby = user,
                createdby = user,
                createdbyrole = role.ToString(),
                //request = JsonConvert.SerializeObject(new { evento="normal" }),
                isauto = isauto,
                state = ((int)estado).ToString()
            };
            using (var ctx = new Pea.DataAccess.BaseContext<Notificacion>().GetDbCtx())
            {
                ctx.Notificacion.Add(notificacion);
                ctx.SaveChanges();
            }
        }

        class SolicitudUsers
        {
            public UserInfo Lp { get; set; }
            public List<UserInfo> Fss { get; set; }
        }

        static CultureInfo cult = new CultureInfo("es");// lo dejo aca por si a futuro cambia por mail.
        public static Mail PrepararMailDeNotificacion(NotificacionType type, Notificacion notificacion, Solicitud solicitud, Sync sync)
        {
            // es llamado en la notifiacion por dos razones
            // para que no pague el tiempo la carga manual y para que se puedan hacer insert bulks directo en la tabla
            // notificaciones , como en el caso de automatico
            //var mails = new List<Mail>();

            bool isauto = notificacion.isauto;
            //notificacionConfig[];

            var mail = new Mail();
            SolicitudUsers users = GetUsersFromCreatedby(solicitud.createdby);

            DateTimeOffset? date = null;
            switch (type)
            {
                case NotificacionType.FuturaAnulacion:
                    date = solicitud.signed;
                    break;
                case NotificacionType.FuturaEliminacion:
                    date = solicitud.created;
                    break;
            }
            var daysLeft = date != null ? (date.Value.AddDays(DuracionMaximaDeSolicitudEnDias) - DateTime.UtcNow).TotalDays : 0;
            daysLeft = daysLeft < 0 ? 0 : daysLeft;
            daysLeft = Math.Ceiling(daysLeft); // 1.99 => 2 , 0.1=>1 es decir si falta una hora dira un dia
            //var daysLSTMD = TimeSpan.FromDays(daysLeftSinceTilMaxdays).Humanize(maxUnit:TimeUnit.Day, minUnit: TimeUnit.Day,culture:cult);
            var daysLSTMD = daysLeft > 1 ? daysLeft + " días" : "1 día";
            var apellidoasegurado = solicitud?.DatosPA?.Apellidos;
            apellidoasegurado = string.IsNullOrWhiteSpace(apellidoasegurado) ? "NN" : apellidoasegurado;
            dynamic data = new { apellidoasegurado = apellidoasegurado, daysLSTMD = daysLSTMD, users = users, solicitud = solicitud, notificacion = notificacion }; // con el data en el tamplate es mas facil de buscar

            EstadoType estado = (EstadoType)int.Parse(notificacion.state);
            EstadoType? estadoanterior;
            if (string.IsNullOrWhiteSpace(sync.statefrom))
            {
                estadoanterior = null;
            }
            else
            {
                estadoanterior = (EstadoType)int.Parse(sync.statefrom);
            }

            string idauto = isauto ? "auto" : "manual";
            string idtype = type.ToString();
            string idestado = estado.ToString();
            string idestadoanterior = estadoanterior.ToString();
            string idrole = notificacion.createdbyrole;
            string nombreevento = "normal"; // preparado para soportar multiples eventos de llegada
            // funciona de la siguiente manera, toma el valor del hijo si es posible, sino toma el del padre, parecido al closest de jquery
            // NTH hacerlo recursivo
            var nodotiponotif = notificacionConfig[idtype];
            var nodoestado = (nodotiponotif["estados"]?[idestado]) ?? nodotiponotif;
            var nodoevento = (nodoestado["eventos"]?[nombreevento]) ?? nodoestado;
            var nodopor = (nodoevento["por"]?[idrole]) ?? nodoevento;
            var nodohoja = nodopor;
            if (nodohoja != null)
            {

                var sub = nodoevento["subject"]?.ToObject<string>();
                var body = nodoevento["body"]?.ToObject<string>() ?? "";
                var to = string.Join(";", nodohoja["to"].ToObject<List<string>>().SelectMany(rol => getMailsByRol(rol, users)));
                var cc = string.Join(";", nodohoja["cc"].ToObject<List<string>>().SelectMany(rol => getMailsByRol(rol, users)));

                mail.To = to;
                mail.Cc = cc;
                mail.Subject = Smart.Format(sub, data);
                mail.Html = false;
                mail.Msg = Smart.Format(body, data); ;

                //mails.Add(mail);
            }
            return mail;
        }

        private static List<string> getMailsByRol(string rol, SolicitudUsers users)
        {
            var mails = new List<string>();
            if (rol == "LP")
            {
                mails.Add(users.Lp.Email_Addr);
            }
            else if (rol == "FSS")
            {
                mails.AddRange(users.Fss.Select(u => u.Email_Addr));
            }
            return mails;
        }

        private static SolicitudUsers GetUsersFromCreatedby(string createdby)
        {
            return new SolicitudUsers()
            {
                Fss = UserBusiness.GetFssFromLp(createdby),
                Lp = UserBusiness.GetUser(createdby)
            };
        }

        List<string> estadosConVencimientos = new List<string>() { EstadoType.Firmada.ToString(), EstadoType.Anulada.ToString() };
        public void AutoCrearNotificacionesPorProximosVencimientos()
        {

            //=3 4 Por cada solicitud que se haya firmado y no se haya presentado, se envían dos mails de aviso de anulación al LP: 3 días antes y 1 día antes.  
            //=6 7 Por cada solicitud que haya sido creada y no se haya firmado, se envían dos mails de aviso de eliminación al LP: 3 días antes y 1 día antes.  
            using (var ctx = new Pea.DataAccess.BaseContext<Notificacion>().GetDbCtx())
            {

                try
                {
                    var limitedias = DuracionMaximaDeSolicitudEnDias;
                    var name = "Solicitud";

                    var lestado = new List<EstadoType>() { EstadoType.Nueva, EstadoType.Firmada, EstadoType.Reportada, EstadoType.Completa };
                    var ldaysrunning = new List<int>() { limitedias - 3, limitedias - 1 };
                    foreach (var estado in lestado)
                    {
                        foreach (var daysrunning in ldaysrunning)
                        {
                            string field = string.Empty;
                            NotificacionType type;
                            if (estado == EstadoType.Nueva)
                            {
                                type = NotificacionType.FuturaEliminacion;
                                field = "created";
                            }
                            else
                            {
                                type = NotificacionType.FuturaAnulacion;
                                field = "signed";
                            }

                            var subtype = daysrunning.ToString();

                            var request = string.Empty;
                            SqlParameter[] filter = new SqlParameter[] {
                            new SqlParameter("@estado", ((int)estado).ToString()),
                            new SqlParameter("@daysrunning", daysrunning),
                            new SqlParameter("@type", type.ToString()),
                            new SqlParameter("@subtype", subtype),
                            new SqlParameter("@name", name),
                            new SqlParameter("@username", UserNameWorker)
                            //new SqlParameter("@request", request)
                        };

                            // inserta las notificaciones aun no cargadas comparando la lista de solicitudes left join notificaciones
                            var res = ctx.Database.ExecuteSqlCommandAsync(
                                @"
                            insert notificacion
                            (gid,id,ver,name,type,subtype,meth,created,updated,createdby,updatedby,createdbyrole,isauto,done,ok,del,request,response,serverupdated,state)
                            select a.gid,a.id,a.ver,@name,@type,@subtype,null,GETUTCDATE(),GETUTCDATE(),@username,@username,'',1,0,0,0,null,null,GETUTCDATE(),@estado
                            from Solicitud a left join notificacion b
                            on a.id = b.id and b.type=@type  and b.subtype = @subtype 
                            where a." + field + @" <= dateadd(dd,-(@daysrunning),GETUTCDATE()) and a.Estado = @estado and b.id is null 
                            ", filter).Result;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        //static Dictionary<string, object> dicchangeAnular = new Dictionary<string, object>() { { "id", null } ,{ "Estado", null } };
        //static Dictionary<string, object> dicchangeEliminar = new Dictionary<string, object>() { { "id", null }, { "del", null } };
        public void AutoAnularYElminar()
        {
            var list = new List<Solicitud>();

            var solicitudesAAnular = new List<Solicitud>();
            var solicitudesAEliminar = new List<Solicitud>();
            using (var ctx = new Pea.DataAccess.BaseContext<Notificacion>().GetDbCtx())
            {


                //=5  Una vez anulada se envía un mail a las FSS de la agencia, con copia al LP Writing.
                //Anular Automático(cumplidos los 12 días de firmado):
                //--nueva vencida firmada 2 / reportada 3 / completa 5(estado 1->estado = 4)
                SqlParameter[] filter = new SqlParameter[] {
                    new SqlParameter("@daysmax", DuracionMaximaDeSolicitudEnDias)
                };
                solicitudesAAnular = ctx.Solicitud.SqlQuery(
                    @"select * from solicitud where GETUTCDATE() > dateadd(day, @daysmax, signed) and Estado in (2,3,5)", filter).ToList();


                //=8 Una vez eliminada se envía un mail de aviso al LP Writing.
                //Eliminación Automática (cumplidos los 12 días de creada):
                //--nueva vencida(estado 1->eliminada / del = 1)
                SqlParameter[] filter2 = new SqlParameter[] {
                    new SqlParameter("@daysmax", DuracionMaximaDeSolicitudEnDias)
                };
                solicitudesAEliminar = ctx.Solicitud.SqlQuery(
                    @"select * from solicitud where GETUTCDATE() > dateadd(day, @daysmax, created) and Estado = 1", filter2).ToList();

            }

            // TODO fix lista dic para que no genericbusiness solo use los nobmres de los campos y no sus valores dbojs+(debiera ser una lista ordenada de campos) 
            if (solicitudesAAnular.Count() > 0)
            {
                solicitudesAAnular = solicitudesAAnular.Select(s => { s.Estado = ((int)EstadoType.Anulada).ToString(); s.MotivoAnulacion = "Automática"; return s; }).ToList();

                //var res1 = UpdateBulk(solicitudesAAnular, new List<Dictionary<string, object>>() { dicchangeAnular }).Result;
                foreach (var sol in solicitudesAAnular)
                {
                    var dicchangeAnular = new Dictionary<string, object>() { { "id", sol.id }, { "oldver", sol.ver }, { "Estado", sol.Estado } };
                    var res1 = Update(sol, dicchangeAnular).Result;
                }
            }
            if (solicitudesAEliminar.Count() > 0)
            {
                solicitudesAEliminar = solicitudesAEliminar.Select(s => { s.del = true; return s; }).ToList();
                foreach (var sol in solicitudesAEliminar)
                {
                    var dicchangeEliminar = new Dictionary<string, object>() { { "id", sol.id }, { "del", sol.del } };
                    var res1 = Delete(sol, dicchangeEliminar).Result;
                }
                //var res2 = DeleteBulk(solicitudesAEliminar, new List<Dictionary<string, object>>() { dicchangeEliminar }).Result;
            }


        }


    }
}
