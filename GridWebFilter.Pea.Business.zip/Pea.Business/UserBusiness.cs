﻿using Newtonsoft.Json;
using Pea.Business.Helpers;
using Pea.Infrastructure;
using Pea.Infrastructure.Extensions;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Runtime.Caching;
using System.Security.Claims;
//using System.Web;
using System.Security.Principal;
using static Pea.Model.Constants;

namespace Pea.Business
{
    public class UserBusiness
    {
        //Mocks Url:
        //DEV Sofre:
        //http://e-application.azurewebsites.net/api/users/GetAgentesAgente/X112071 --Lps pertenecientes a un AM o SM
        //http://e-application.azurewebsites.net/api/users/GetAgentesFSS/X174435 --Lps pertenecientes a un FSS
        //http://e-application.azurewebsites.net/api/users/GetUsuario/X112963  --Info del usuario

        //Prudential
        //Desarrollo:  http://ar01f141vd/peoplemanagment/api/Estructura/
        //Producción:  http://ar01f141vp/peoplemanagment/api/Estructura/
        //Ejemplo Desa:
        //http://ar01f141vd/peoplemanagment/api/Estructura/GetUsuario/X155963 


        public static void SetIdentityAsWorker()
        {
            //Set the CustomIdentity object on current threads for given username

            var username = Role.Worker.ToString();
            var role = Role.Worker.ToString();
            var genIdentity = new GenericIdentity(username);
            var workerIdentity = new ClaimsIdentity(genIdentity, new List<Claim>() { new Claim(ClaimTypes.Role, role) });
            var threadCurrentPrincipal = new GenericPrincipal(workerIdentity, new string[] { role });
            System.Threading.Thread.CurrentPrincipal = threadCurrentPrincipal;


            var res = GetOrAddToCache(username, () => new UserInfo() { Name = username, Role = role, Usuario = username }, false);

            // asume worker;
            //username = Role.Worker.ToString();
            //user = new UserInfo();
            //user.Role = ((int)Role.Worker).ToString();
        }


        /// <summary>
        /// Gets the current User Identity.
        /// </summary>
        /// <returns></returns>
        public static IIdentity GetMyIdentity()
        {
            return (ClaimsIdentity)System.Threading.Thread.CurrentPrincipal.Identity;
            //return System.Web.HttpContext.Current?.User?.Identity;
        }

        /// <summary>
        /// Gets the current User Name from Identity.
        /// </summary>
        /// <returns></returns>
        public static string GetMyUserName()
        {
            return GetMyIdentity()?.Name;
        }

        /// <summary>
        /// Gets the roles for the current User from the Identity.
        /// </summary>
        /// <returns></returns>
        public static List<Role> GetMyRoles()
        {
            var identity = (ClaimsIdentity)GetMyIdentity();
            return identity?.Claims.ToList().FindAll(c => c.Type == ClaimTypes.Role).Select(o =>
            {
                Role role;
                if (Enum.TryParse<Role>(o.Value, out role))
                {
                    return role;
                }
                else
                {
                    throw new Exception("Role parse fail for user " + identity.Name + " claim role " + o.Value);
                }
            }

            ).ToList();
        }

        /// <summary>
        /// Get User Data for current User from the User Service.
        /// /// </summary>
        /// <returns></returns>
        public static UserInfo GetMyInfo()
        {
            var usrname = GetMyUserName();
            if (string.IsNullOrWhiteSpace(usrname)) return null;
            return GetUser(usrname);
        }


        //private static ConcurrentDictionary<string, Lazy<object>> internalDic = new ConcurrentDictionary<string, Lazy<object>>();
        static int expirationInMinutes = int.Parse(ConfigurationManager.AppSettings["Cache-General-AbsoluteExpirationInMinutes"]);
        static T GetOrAddToCache<T>(string key, Func<T> fn, bool remove) where T : class
        {

            return LoggerHelper.ExceptionCatchAndLog(() =>
            {
                return CacheHelper.GetOrAdd(key, new CacheItemPolicy() { AbsoluteExpiration = DateTime.Now.AddMinutes(expirationInMinutes) }, remove, fn);

            });
        }
        /// <summary>
        /// Get the Agents thay works for the current User.
        /// </summary>
        /// <param name="strUser"></param>
        /// <returns></returns>
        public static List<UserInfo> GetMyAgents()
        {
            string strUser = GetMyUserName();
            if (string.IsNullOrEmpty(strUser)) return null;
            var roles = GetMyRoles();
            List<UserInfo> users = null;

            if (roles.Any(r => r == Constants.Role.FSS))
            {//ES FSS
                users = GetLpFromFss(strUser);
            }
            else if (roles.Any(r => r == Constants.Role.AM || r == Constants.Role.SM))
            {//ES AM o SM
                users = GetLpFromAmOrSm(strUser);
            }
            if (users == null)
            {
                return new List<UserInfo>(); // throw new Exception("Agent service not implemented for current profile.");
            }

            return users;
        }

        public static List<UserInfo> GetLpFromAmOrSm(string strUser)
        {
            return GetUsers("GetAgentesAgente", strUser).ToList();
        }

        public static List<UserInfo> GetLpFromFss(string strUser)
        {
            return GetUsers("GetAgentesFSS", strUser).ToList();
        }

        public static List<UserInfo> GetFssFromLp(string strUser)
        {
            return GetUsers("GetFSSAgente", strUser).ToList();
        }

        private static UserInfo[] GetUsers(string servicename, string strUser, bool refresh = false)
        {
            var key = servicename + '-' + strUser;
            return (GetOrAddToCache(key, () => GetDeserializedJsonUserService<UserInfo[]>(servicename, strUser).Select(u => AddRoleToUser(u)).ToArray(), refresh) ?? new UserInfo[0]);
        }

        public static UserInfo GetUser(string strUser, bool refresh = false)
        {
            return GetOrAddToCache(strUser, () => AddRoleToUser(GetDeserializedJsonUserService<UserInfo>("GetUsuario", strUser))
            , refresh);
            //return (res == null || string.IsNullOrEmpty(res.Usuario)) ? null : res;
        }
        static UserInfo AddRoleToUser(UserInfo user)
        {
            if (user == null) return null;
            user.Role = GetRoleDescription(user.JobCode);
            return user;
        }


        private static T GetDeserializedJsonUserService<T>(string strMethodName, string strUser)
        {
            if (string.IsNullOrEmpty(strMethodName)) throw new ArgumentNullException(strMethodName);
            if (string.IsNullOrEmpty(strUser)) throw new ArgumentNullException(strUser);

            string url = string.Format("{0}{1}/{2}",
                ConfigurationManager.AppSettings["UserServiceBaseUrl"],
                strMethodName, strUser);

            WebClient client = new WebClient();
            string json = client.DownloadString(new Uri(url));
            if (json == "{}")
            {
                return default(T);
            }
            else
            {
                return JsonConvert.DeserializeObject<T>(json);
            }
        }

        /// <summary>
        /// Returns the Role Description by its code.
        /// </summary>
        /// <param name="code">Role code</param>
        /// <returns></returns>
        private static string GetRoleDescription(int code)
        {
            Constants.Role[] roleEnum = EnumHelper.GetCollection<Constants.Role>();//(Constants.Role[])Enum.GetValues(typeof(Constants.Role));

            foreach (var roleEnumitem in roleEnum)
            {
                string[] strCodes = roleEnumitem.GetDescription().Split(',');
                if (strCodes.Any(c => c == code.ToString()))
                {
                    return roleEnumitem.GetName();//((Constants.Role)(object)(roleEnumitem)).ToString();
                }
            }
            throw new Exception("JobCode not implemented.");
        }

        /// <summary>
        /// Adds the User Roles to Identity claims.
        /// </summary>
        /// <param name="identity"></param>
        public static string AddRolesClaimsToIdentity(ClaimsIdentity identity)
        {
            var oUserInfo = GetUser(identity.Name, true); // toma datos de usuario del servicio actualizando ademas el cache
            if (oUserInfo == null)
            {
                return "User does not exist.";
            }
            //Delete Existing role claims
            identity.Claims.ToList().Where(c => c.Type == ClaimTypes.Role).ToList().ForEach(c => identity.RemoveClaim(c));
            identity.AddClaim(new Claim(ClaimTypes.Role, oUserInfo.Role));
            return string.Empty;
        }
    }
}


