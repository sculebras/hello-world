﻿using Newtonsoft.Json.Linq;
using Pea.Contracts;
using Pea.DataAccess;
using Pea.Infrastructure;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Dynamic;
using System.Linq;
using System.Linq.Dynamic;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.Caching;
using System.Security.Authentication;
using System.Threading.Tasks;
using static Pea.Model.Constants;

namespace Pea.Business
{

    public class GenericBusiness<T> : BusinessHandler<T> where T : class, ISyncable
    {
        static JObject config = BusinessConfigHelper.Config;
        static PropertyInfo[] props = typeof(T).GetProperties();
        static Dictionary<string, object> propNames = null;
        BaseContext<T> ctx = new BaseContext<T>();

        static string entityName = typeof(T).Name;
        const string serviceNameLocationTag = "services";
        static JObject entityConfig;
        static bool isSyncable = typeof(T).GetProperty("ver") != null;
        static bool hasGid = typeof(T).GetProperty("gid") != null;
        static PropertyInfo GetCreatedBy = typeof(T).GetProperty("createdby");
        static PropertyInfo GetUpdatedBy = typeof(T).GetProperty("updatedby");
        static PropertyInfo GetModifiedBy = typeof(T).GetProperty("modifiedby");
        static PropertyInfo GetId = typeof(T).GetProperty("id");

        //static Dictionary<string, object> security;
        string username;
        UserInfo user = null;
        List<string> users = new List<string>();
        static Security securityFilter = Security.CreatedBy; // default 
        PEAEntities db;

        List<string> originalExpand;

        public GenericBusiness()
        {
            if (propNames == null)
            {

                var servicesConfig = config[serviceNameLocationTag];
                entityConfig = (JObject)servicesConfig[entityName];
                if (entityConfig != null)

                {
                    propNames = props.ToDictionary(o => o.Name, o => new object());

                    var sec = entityConfig["Security"];
                    if (sec != null && sec.FirstOrDefault() != null)
                    {
                        var security = sec.ToObject<List<object>>(); // Dictionary<string, object>>();

                        if (security.Count() > 0)
                        {
                            securityFilter = 0;
                            Security secu = 0;
                            foreach (var o in security)
                            {
                                if (Enum.TryParse<Security>((string)o, out secu))
                                {
                                    securityFilter = securityFilter | secu;
                                }
                                else
                                {
                                    throw new Exception("Entity " + entityName + " has a bad Security ( enum flag ): " + o.ToString() + ". use security enum.");
                                }
                            }
                        }
                    }
                }
                else
                {
                    throw new Exception(entityName + " => require configuracon en config.json services para poder ser ejecutada.");
                }
            }

            user = UserBusiness.GetMyInfo();
            username = UserBusiness.GetMyUserName(); // tomar usuario del UserBiz // TODO confirmar diferenciar de un usuario inexistente del worker (getuser viene vacion vs se lanza el job)
            if (!string.IsNullOrEmpty(username))
            {
                users = UserBusiness.GetMyAgents().Select(o => o.Usuario).ToList();
                //var myfss = UserBusiness.GetFssFromLp(user);
                users.Add(username);
            }
            if (user == null)
            {
                throw new AuthenticationException("User hasnt been authenticated while accesing GenericBusiness. Access is denied.");
            }

        }

        private async Task<IResult<T>> callInternal(IList<T> objs, List<Dictionary<string, object>> list, meths meth)
        {
            var result = new Result<T>();

            try
            {
                using (db = ctx.GetDbCtx())
                {
                    //using (var transaction = new TransactionScope(
                    //        TransactionScopeOption.RequiresNew,
                    //        new TransactionOptions() { IsolationLevel = IsolationLevel.ReadCommitted },
                    //        TransactionScopeAsyncFlowOption.Enabled))
                    //{


                    //entry.State = EntityState.Modified;
                    //// http://stackoverflow.com/questions/15336248/entity-framework-5-updating-a-record
                    var set = ctx.GetSet();

                    var originals = await checkSyncedChanges(list, set, result, meth);
                    if (true) // result.ok)
                    {
                        //set.Attach(obj);
                        result.message = null;
                        var dic = list.First();
                        var dobj = objs.ToDictionary((it) => it.id); //GetId.GetValue(it));
                        Dictionary<string, T> dori = null;
                        if (meth != meths.create)
                        {
                            // TODO falla si no es create y no existe el item en la base , el svr ret 5xx pero deberia ser 409
                            dori = originals.ToDictionary((it) => it.id); //GetId.GetValue(it));  
                        }
                        foreach (var kv in dobj)
                        {
                            T ent = kv.Value;

                            switch (meth)
                            {
                                case meths.create:
                                    ent.createdby = username;
                                    break;
                                case meths.delete:
                                    ent.del = true; // baja logica
                                    break;
                                case meths.update:
                                    break;
                                case meths.read:
                                    break;
                                case meths.merge:
                                    break;
                                default:
                                    break;
                            }

                            ent.updatedby = username;
                            ent.gid = ent.gid ?? ent.id;

                            //workflow security
                            //if (WorkflowBusiness.ValidateWorkflowAuthorization<T>(ent, entityName, meth, dic))
                            //{
                            ApplyChangeToRowByMethod<T>(meth, ent, dic);
                            //}
                            //else
                            //{
                            //    result.ok = false;
                            //    result.message = "Business rules rejects action.";
                            //    result.meta = new Dictionary<string, object>() { { "unauthorized", true } };
                            //    return result;
                            //}
                        }


                        try
                        {
                            var x = await db.SaveChangesAsync();
                            setResults(result, objs, x);
                        }
                        catch (DbUpdateException e)
                        {
                            cleanContext();
                            result.message = e.InnerException.InnerException.Message;
                            result.ok = false;
                        }
                        catch (DbEntityValidationException e)
                        {
                            cleanContext();
                            parseError((IResultBase<T>)result, e);
                        }

                        await NotifySync(meth, objs, result, dic);


                        // after save custom biz // TODO hacer solo si cambios exitosos
                        foreach (dynamic ent in objs)
                        {
                            if (entityName == "Solicitud")
                            {
                                GetOrAddToCache(ent);

                                // NTH esto puede ser generico para que cualquier entidad hookee su logica de negocio pero no es necesario por ahora.
                                //apply Estado change to state sync
                                if (entityName == "Solicitud" && (dic.ContainsKey("Estado") || ent.del))
                                {
                                    var sol = ent as Solicitud;
                                    if (string.IsNullOrEmpty(sol.Estado) || ent.del)
                                    {
                                        sol = db.Solicitud.Find(ent.id);
                                    }
                                    SolicitudBusiness.ProcesarCambioEstado(sol); // ent as Solicitud); 
                                }
                            }
                        }
                        // end custom
                    }

                    //    transaction.Complete();
                    //}

                }

            }
            catch (Exception e)
            {
                result.ok = false;
                result.message = e.ToString();
            }

            return result;
        }


        /// <summary>
        /// cache
        /// </summary>
        static CacheItemPolicy cachepoli = new CacheItemPolicy(); // infinite

        public static T GetOrAddToCache(T ent)
        {
            var key = entityName + "-" + ent.id;
            var remove = true;
            return CacheHelper.GetOrAdd(key, cachepoli, remove, () => ent);
        }
        public static T GetOrFindAddToCache(string id)
        {
            return GetOrFindAddToCache<T>(entityName, id);
        }
        public static TT GetOrFindAddToCache<TT>(string entityName, string id)
            where TT : class
        {
            var key = entityName + "-" + id;
            var remove = true;
            return CacheHelper.GetOrAdd(key, cachepoli, remove, () =>
            {
                using (PEAEntities db = new BaseContext<T>().GetDbCtx())
                {
                    return db.Set<TT>().Find(id);
                }
            });
        }

        /// ///////////////




        private void cleanContext()
        {
            foreach (DbEntityEntry dbEntityEntry in db.ChangeTracker.Entries())
            {

                if (dbEntityEntry.Entity != null)
                {
                    dbEntityEntry.State = EntityState.Detached;
                }
            }
        }

        static Dictionary<string, object> notifySyncDic = new Dictionary<string, object>() { { "meth", null }, { "serverupdated", null },
                        { "txid", null }, { "clientType", null } , { "sessionid", null } , { "ok", null }, { "request", null }
                        , { "response", null } };
        static Dictionary<string, object> notifySyncDicWithState = notifySyncDic.Union(new Dictionary<string, object>()
        { { "state",null }, { "stateupdated",null }, {"stateevent",null }, {"statefrom" ,null } })
            .ToDictionary(o => o.Key, o => o.Value);

        async private Task NotifySync(meths meth, IList<T> objs, Result<T> res, Dictionary<string, object> objdic)
        {

            foreach (dynamic dobj in objs)
            {
                try
                {
                    var sid = entityName + "-" + dobj.id;
                    var ndic = notifySyncDic;
                    var now = DateTime.UtcNow;
                    var ent = new Sync()
                    {
                        sid = sid,
                        gid = hasGid ? dobj.gid : dobj.id,
                        id = dobj.id,
                        name = entityName,
                        meth = meth.ToString(),
                        created = dobj.created ?? DateTimeKind.Utc,
                        createdby = username,
                        updated = dobj.updated,
                        updatedby = username,
                        serverupdated = now,
                        txid = now.ToString("yyyyMMddHHmmssffffff"),
                        ver = dobj.ver,
                        clientType = SyncContextInfo?.clientType.ToString(),
                        sessionid = SyncContextInfo?.reference.ToString(),
                        ok = res.ok,
                        del = meth == meths.delete,
                        request = SyncContextInfo?.request
                    };
                    if (meth == meths.create)
                    {
                        ent.created = ent.updated;
                        ent.createdby = ent.updatedby;
                        ent.servercreated = now;
                    }

                    // custom biz apply Estado change to state sync
                    if (entityName == "Solicitud" && objdic.ContainsKey("Estado"))
                    {
                        var osync = db.Sync.Find(sid);
                        if (osync != null)
                        {
                            ent.statefrom = osync.state;
                        }
                        // cambia estado
                        ent.state = dobj.Estado;
                        ent.stateupdated = now;
                        ent.stateupdatedbyrol = user.Role;
                        //ent.stateevent = TODO add motivo anulacion
                        ndic = notifySyncDicWithState;
                    }
                    // end custom


                    var syncmeth = (!res.ok || meths.create == meth) ? meths.merge : meths.update; // solo hace merge la primera vez o si fallo, sino siempre tiene que serupdate y  se ahorra el find
                    ApplyChangeToRowByMethod<Sync>(meths.merge, ent, ndic, ent.sid);

                    if (SyncContextInfo?.enableLog ?? false) //TOFIX como contextinfo no esta iniciado en worker no salva al sync log
                    {
                        db.Set<SyncLog>().Add(ent);
                    }

                }
                catch (Exception ex)
                {
                    var a = ex;
                    throw;
                }
            }
            try
            {
                await db.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                // TODO log when fail but let continue
            }
            return;


        }


        private void ApplyChangeToRowByMethod<M>(meths meth, M ent, Dictionary<string, object> dic = null, object key = null) where M : class, ISyncable
        {
            M oit;
            var set = db.Set<M>();


            var id = key == null ? ent.id : key; // ((ISyncable)ent).id; // GetId.GetValue(ent); // 


            var entry = db.Entry(ent);

            switch (meth)
            {
                case meths.create:
                    set.Add(ent);
                    break;
                // desabilitado hasta corregir el upsert para que actualice solo los campos modificados
                //case meths.delete:
                //case meths.update:
                //oit = set.Find(id);
                //entry = dbCtx.Entry(oit);
                ////entry.CurrentValues.SetValues(ent);
                //setModifyToUpdatedColumns(dic, entry);
                //dbCtx.Upsert(ent).Execute(); // deshabilitado para insert pq va con created y update no, igual ahorra el find+update
                //break;
                //case meths.read:
                //    break;
                case meths.delete: // TODO cuando sea necesario diferenciar que las cuales son las bajas fisicas de las logicas
                case meths.update:
                case meths.merge:
                    // no se puede hacer el merge porque se actualizan distintas columnas, asi que find+update or find+insert
                    oit = set.Find(id);
                    if (oit != null)
                    {
                        entry = db.Entry(oit);
                        entry.CurrentValues.SetValues(ent);
                        setModifyToUpdatedColumns(meth, dic, entry);
                    }
                    else
                    {
                        set.Add(ent);
                    }
                    break;
                    //default:
                    //    break;
            }

        }

        // diccionarios de campos fijos enviados segun meth
        static Dictionary<string, bool> dicModificableColumns = new Dictionary<string, bool>() {
                { "del", false }, { "updated", true }, { "updatedby", true }, { "created", true }, { "createdby", true },
                { "oldver", false }, { "id", false } ,{ "gid", false} };
        static Dictionary<string, bool> dicModificableColumnsDelete = new Dictionary<string, bool>() {
                { "del", true }, { "updated", true }, { "updatedby", true }, { "created", false }, { "createdby", false },
                { "oldver", false }, { "id", false } ,{ "gid", false} };
        static Dictionary<string, bool> dicModificableColumnsUpdate = new Dictionary<string, bool>() {
                { "del", true }, { "updated", true }, { "updatedby", true }, { "created", false }, { "createdby", false },
                { "oldver", false }, { "id", false } ,{ "gid", false} };
        private static void setModifyToUpdatedColumns<M>(meths meth, Dictionary<string, object> dic, DbEntityEntry<M> entry) where M : class
        {
            if (dic == null) throw new ArgumentNullException("dic", "dictionary with updatable props must be provided, at least empty.");// dic = new Dictionary<string, object>();

            Dictionary<string, bool> dicMod = meth == meths.delete ? dicModificableColumnsDelete : meth == meths.update || meth == meths.merge ? dicModificableColumnsUpdate : dicModificableColumns;

            entry.OriginalValues.PropertyNames.ToList().ForEach(col =>
            {
                bool isModificable = false;
                bool isConfig = dicMod.TryGetValue(col, out isModificable);
                // si esta configurada en el dic sigue lo que dice el dic, sino esta configurada se fija si esta en el diccionario que se envia en cuyo caso solo hace el path de las que si envio y no todo el objeto recuperdo
                entry.Property(col).IsModified = ((isConfig && isModificable) || (!isConfig && dic.ContainsKey(col)));
            });
        }

        private static async Task<IList<T>> checkSyncedChanges(List<Dictionary<string, object>> list, DbSet<T> set, Result<T> results, meths meth)
        {
            // TODO cambia a un solo query / call en lugar de llamar a checksync 
            var ress = new List<ResultOne<T>>();
            var ritems = new List<T>();
            var ok = true;
            Dictionary<string, object> dicb = new Dictionary<string, object>();
            foreach (var dic in list)
            {
                var result = new ResultOne<T>();
                var ritem = await checkSyncedChange(dic, set, result, meth);
                ok = ok && result.ok;
                dicb.Add(dic["id"].ToString(), new { ok = result.ok, message = result.message });
                ritems.Add(ritem);
                ress.Add(result);

            }
            results.message = "see conflicts in meta";
            results.ok = ok;
            results.values = ritems;
            results.meta = new Dictionary<string, object>() { { "conflict", true }, { "conflicts", dicb } };
            return ritems;

        }


        private static async Task<T> checkSyncedChange(Dictionary<string, object> dic, DbSet<T> set, ResultOne<T> result, meths meth)
        {
            T item = null;
            List<T> qres;
            if (!dic.ContainsKey("id"))
            {
                result.ok = false;
                result.message = "id is required to sync.";
                return item;
            }
            var id = (string)dic["id"];
            switch (meth)
            {
                case meths.create:
                    qres = await GetById(set, id);
                    item = qres.SingleOrDefault();
                    if (qres.Count() == 1) { await getConflict(dic, set, result); }
                    else { result.ok = true; }
                    return item;
                //break;
                case meths.delete:
                    qres = await GetById(set, id);
                    item = qres.SingleOrDefault();
                    if (qres.Count() != 1) { await getConflict(dic, set, result); }
                    else { result.ok = true; }
                    return item;
                //break;
                case meths.update:
                    if (!dic.ContainsKey("oldver"))
                    {
                        qres = await GetById(set, id);
                        result.ok = false;
                        item = qres.SingleOrDefault();
                        await getConflict(dic, set, result);
                        result.message = "oldver is required to sync.";
                        return item;
                    }
                    var oldver = (string)dic["oldver"];
                    //qres = await GetByIdAndOldver(set, id, oldver); // HOTFIX DISABLED
                    qres = await GetById(set, id);
                    item = qres.SingleOrDefault();
                    if (qres.Count() != 1) { await getConflict(dic, set, result); }
                    else { result.ok = true; }
                    return item;
                    //break;
                    //case meths.read:
                    //    break;
                    //default:
                    //    break;
            }

            return null;
        }

        private static async Task<List<M>> GetByIdAndOldver<M>(DbSet<M> set, string id, string oldver) where M : class
        {
            return await (set.Where("id=\"" + id + "\"").Where("ver=\"" + oldver + "\"").ToListAsync());
        }

        private static async Task<List<M>> GetById<M>(DbSet<M> set, object id) where M : class
        {
            return await (set.Where("id=\"" + id + "\"").ToListAsync());
        }

        private static async Task<bool> getConflict(Dictionary<string, object> dic, DbSet<T> set, ResultOne<T> result)
        {
            // trae el disponible para mostrarselo al cliente
            IQueryable q = set.Where("id=\"" + dic["id"] + "\"");
            setqueryselect(q, "new (id,ver)");
            var qres2 = (await q.ToListAsync());
            var it = qres2.SingleOrDefault();

            result.message = "row id and oldver dont match with server version."; // please see returned value and resolve conflict at client.";
            setResult(result, it, 0);
            result.meta.Add("conflict", true);
            result.ok = false;
            return result.ok;
        }

        static volatile object dynliq = new object();
        private static IQueryable setqueryselect(IQueryable q, string sselect)
        {
            /// fix needed beacause is not thread safe
            lock (dynliq)
            {
                q = q.Select(sselect);
            }
            return q;
        }

        private static void parseError(IResultBase<T> result, DbEntityValidationException e)
        {
            result.ok = false;
            result.message = e.EntityValidationErrors
                    .SelectMany((a) => a.ValidationErrors)
                    .Select((a) => a.ErrorMessage)
                    .Aggregate((a, b) => (a + "," + b));
        }


        private static void setResult(ResultOne<T> result, dynamic obj, dynamic x)
        {
            result.value = null;
            result.meta = new Dictionary<string, object>();
            result.meta.Add("count", x);
            if (obj != null)
            {
                result.value = new { id = obj.id, ver = obj.ver };
                result.ok = true;
            }
            else
            {
                result.ok = false;
            }

        }
        private static void setResults(Result<T> result, dynamic objs, dynamic x)
        {
            result.values = null;
            result.meta = new Dictionary<string, object>();
            result.meta.Add("count", x);
            //if (isSyncable)
            //{
            var list = new List<Object>();
            foreach (var obj in objs)
            {
                list.Add(new { id = obj.id, ver = obj.ver, gid = obj.gid, del = obj.del });
            }
            //result.meta.Add("sync",new {values = list } );
            result.values = list;
            //}
            result.ok = true;


        }



        public override async Task<IResult<T>> CreateBulk(IList<T> objs, List<Dictionary<string, object>> list = null)
        {
            return await callInternal(objs, list, meths.create);
        }
        public override async Task<IResultOne<T>> Create(T obj, Dictionary<string, object> dic = null)
        {
            var objs = new List<T>() { obj };
            var list = new List<Dictionary<string, object>>() { dic };
            var res = await callInternal(objs, list, meths.create);
            return getOneResult(res);
        }
        public override async Task<IResult<T>> UpdateBulk(IList<T> objs, List<Dictionary<string, object>> list = null)
        {
            return await callInternal(objs, list, meths.update);
        }
        public override async Task<IResultOne<T>> Update(T obj, Dictionary<string, object> dic = null)
        {
            var objs = new List<T>() { obj };
            var list = new List<Dictionary<string, object>>() { dic };
            var res = await callInternal(objs, list, meths.update);
            return getOneResult(res);
        }
        public override async Task<IResult<T>> DeleteBulk(IList<T> objs, List<Dictionary<string, object>> list = null)
        {
            return await callInternal(objs, list, meths.delete);
        }
        public override async Task<IResultOne<T>> Delete(T obj, Dictionary<string, object> dic = null)
        {
            var objs = new List<T>() { obj };
            var list = new List<Dictionary<string, object>>() { dic };
            var res = await callInternal(objs, list, meths.delete);
            return getOneResult(res);
        }

        private static IResultOne<T> getOneResult(IResult<T> res)
        {
            return new ResultOne<T>() { message = res.message, meta = res.meta, ok = res.ok, value = res.values.FirstOrDefault() };
        }

        public override async Task<IResultOne<T>> ReadOne(IReadFilter filter)
        {
            var res = await Read(filter);
            var res2 = res.values.SingleOrDefault();
            var ct = (res2 != null ? 1 : 0);
            return new ResultOne<T>() { message = res.message, ok = res.ok, value = res2, meta = new Dictionary<string, object>() { { "count", ct } } };
        }

        public override async Task<IResult<T>> Read(IReadFilter filter)
        {

            filter = checkFilter(filter);

            // select is using http://dynamiclinq.azurewebsites.net/

            var top = filter.top;
            var expand = filter.expand;
            var skip = filter.skip;
            var order = filter.orderby;
            string selectedFields = filter.select != null && filter.select.Count > 0 ? string.Join(",", filter.select) : null;


            using (db = ctx.GetDbCtx())
            {
                Dictionary<string, object> dicMeta = new Dictionary<string, object>();
                if (skip.HasValue && skip.Value == 0)
                {
                    IQueryable respCount = GenerateQuery(filter, top, expand, skip, order, selectedFields, blCountOnly: true);
                    dicMeta.Add("totalCount", respCount.Count());
                }
                List<dynamic> resp = await ExecuteQuery(filter, top, expand, skip, order, selectedFields);

                var result = new Result<T>();

                if (expand != null && expand.Count > 0)
                    resp = reverseExpand(resp, (entityName == "Sync"));

                result.values = resp;
                //result.meta = new Dictionary<string, object>() { { "count", result.values.Count() } };
                dicMeta.Add("count", result.values.Count());
                result.meta = dicMeta;
                result.ok = true;
                return result;
            }

        }

        private async Task<List<dynamic>> ExecuteQuery(IReadFilter filter,
                                                int? top,
                                                List<string> expand,
                                                int? skip,
                                                List<KeyValuePair<string, OrderTy>> order,
                                                string selectedFields,
                                                bool blCountOnly = false)
        {
            IQueryable query = GenerateQuery(filter, top, expand, skip, order, selectedFields, blCountOnly);
            List<dynamic> resp = await query.ToListAsync();
            return resp;
        }

        private IQueryable GenerateQuery(IReadFilter filter,
            int? top,
            List<string> expand,
            int? skip,
            List<KeyValuePair<string, OrderTy>> order,
            string selectedFields,
            bool blCountOnly = false)
        {
            IQueryable query = ctx.GetQueryableSet();
            if (expand != null) expand.ForEach(o => query = query.Include(o));
            query = ApplyWhere(filter.where, query);
            
            if (!blCountOnly)
            {

                if (order != null)
                    query = query.OrderBy(order
                     .Select(o => string.Format("{0} {1}", o.Key, o.Value.ToString()))
                     .Aggregate((a, b) => a + ", " + b)
                     );
                else query = query.OrderBy("id");
            }

            if (blCountOnly) selectedFields = "1 as CountField";
            if (!string.IsNullOrEmpty(selectedFields)) query = setqueryselect(query, "new (" + selectedFields + ")");

            if (!blCountOnly && skip != null) query = query.Skip((int)skip);
            if (!blCountOnly && top != null) query = query.Take((int)top);
            
            return query;
        }


        private IQueryable ApplyWhere(List<WhereTy> where, IQueryable query)
        {
            if (where != null)
            {
                foreach (var item in where)
                {
                    var soper = item.oper.ToLinqOperator();
                    var prop = item.prop;
                    var val = item.value;
                    if (item.oper == OperTy.in_)
                    {
                        query = query.Where(string.Format("@0.Contains(outerIt.{0})", prop), val);
                    }
                    else if (item.oper == OperTy.Contains || item.oper == OperTy.StartsWith || item.oper == OperTy.EndsWith) {
                        query = query.Where(string.Format("{0}.{1}(@0)", prop, soper), val);
                    }
                    else
                    {
                        query = query.Where(string.Format("{0}{1}@0", prop, soper), val);
                    }
                }
            }
            query = AddSecurityFilter(query);
            if (entityName != "Sync")
            { // todo revisar si conviene directamente poner este filtro solo si no se pide el "del"
                query = query.Where(string.Format("{0}{1}@0", "del", "="), false); // filtra baja logica
            }

            return query;
        }
        

        private IQueryable AddSecurityFilter(IQueryable query)
        {
            //if (securityFilter)
            //    query = from q in (IQueryable<T>)query join s in db.Sync on q.id equals s.id where users.Contains(s.createdby) select q;


            if (securityFilter.HasFlag(Security.ReadAll)) return query;

            //if (securityFilter.HasFlag(Security.CreatedBy))
            //{ // implicito el createdby 
            query = query.Where(string.Format("@0.Contains(outerIt.{0})", "createdby"), users);
            //}
            return query;
        }

        private IReadFilter checkFilter(IReadFilter filter)
        {



            var ecs = entityConfig["Select"];
            var enabledSelects = ecs == null ? null : ecs.Select(it => (string)it).ToList<string>();
            var ece = entityConfig["Expand"];
            List<string> enabledExpansions = null;
            if (ece != null)
                enabledExpansions = ece.Count() == 0 ? null : ece.ToObject<Dictionary<string, string>>().Select(z => z.Key).ToList();

            if (filter.select != null) ValidProperties(filter.select);
            if (filter.orderby != null) ValidProperties(filter.orderby.Select(o => o.Key).ToList());
            if (filter.where != null) ValidProperties(filter.where.Select(o => o.prop).ToList());

            var its = filter.expand;
            // TODO check injection
            //filter.expand = checkFld(filter.expand);
            //filter.orderby = checkFld(filter.orderby);
            if (enabledExpansions != null && filter.expand != null)
            {
                filter.expand = filter.expand.Where(it => enabledExpansions.Contains(it.Split('.')[0])).ToList();
                filter.expand = fixExpand(filter.expand, ece.ToObject<Dictionary<string, string>>());
            }
            if (enabledSelects != null)
            {
                if (!enabledSelects.Contains("*"))
                { // deja pasar todos los campos
                    if (filter.select != null)
                        filter.select = filter.select.Where(it => enabledSelects.Contains(it)).ToList();
                    else
                        filter.select = enabledSelects;

                }

                if (filter.select != null && filter.select.Count == 0) throw new Exception(entityName + " => filter.select no incluye campos habilitados.");
            }
            else
            {
                throw new Exception(entityName + " => BasicRouteConstraints.select debe existir una configuraicon en config.json.");
            }

            return filter;

        }

        // TODO fixexpand === hardcodeo ==> arreglar asap
        private List<string> fixExpand(List<string> expand, Dictionary<string, string> configExpand)
        {
            var salida = new List<string>();
            originalExpand = expand;

            foreach (var it in expand)
            {
                string campoInclude = it;
                var configuracionActual = configExpand;
                string tabla = "";
                foreach (var campo in campoInclude.Split('.').ToList())
                {

                    //   entityName;
                    var campoReal = configuracionActual.First(t => t.Key == campo).Value;
                    var entityCon = (JObject)config[serviceNameLocationTag][campo];
                    if (entityCon != null)
                        configuracionActual = entityCon["Expand"] == null ? null : entityCon["Expand"].ToObject<Dictionary<string, string>>();
                    tabla = tabla + campoReal + ".";

                }

                salida.Add(tabla.Substring(0, tabla.Length - 1));

            }

            return salida;
        }

        private List<dynamic> reverseExpand(List<dynamic> consulta, bool delete)
        {
            List<dynamic> listaSalida = new List<dynamic>();
            try
            {
                foreach (dynamic item in consulta)
                {
                    listaSalida.Add(TransformarExpand(item, originalExpand, delete, ""));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listaSalida;
        }

        private dynamic TransformarExpand(dynamic objeto, List<string> expand, bool delete, string padre)
        {

            var itemTabla = ((Type)objeto.GetType()).Name;
            var entityCon = (JObject)config[serviceNameLocationTag][itemTabla];
            var configuracionActual = entityCon["Expand"] == null ? null : entityCon["Expand"].ToObject<Dictionary<string, string>>();
            configuracionActual = configuracionActual.Where(x => expand.Select(y => y.Split('.')[0]).Contains(x.Key)).ToDictionary(t => t.Key, t => t.Value); ;

            dynamic exapando = new ExpandoObject();
            var objSalida = exapando as IDictionary<string, object>;
            try
            {
                foreach (var PropiedadActual in ((Type)objeto.GetType()).GetProperties())
                {
                    var expandActual = configuracionActual.Where(x => x.Value == PropiedadActual.Name).FirstOrDefault();
                    if (expandActual.Key != null)
                    {

                        var expandReducido = expand.Where(y => y.Split('.')[0].Contains(expandActual.Key) && y.Split('.').Length > 0).Select(x => x.Substring(x.IndexOf('.') + 1)).ToList();

                        if (PropiedadActual.PropertyType.Name == "ICollection`1")
                        {
                            List<dynamic> listaobjeto = new List<dynamic>();
                            foreach (var item in PropiedadActual.GetValue(objeto))
                            {
                                if (delete || item.del == delete)
                                    listaobjeto.Add(TransformarExpand(item, expandReducido, delete, itemTabla));
                            }
                            objSalida[expandActual.Key] = listaobjeto;
                        }
                        else
                        {
                            var valor1 = PropiedadActual.GetValue(objeto);
                            if (valor1 == null)
                            {
                                objSalida[expandActual.Key] = null;
                            }
                            else
                            {
                                objSalida[expandActual.Key] = TransformarExpand(valor1, expandReducido, delete, itemTabla);
                            }
                        }

                    }
                    else
                    {
                        if (padre == PropiedadActual.Name)
                        {
                            objSalida[PropiedadActual.Name] = null;
                        }
                        else
                        {
                            objSalida[PropiedadActual.Name] = PropiedadActual.GetValue(objeto);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return exapando;

        }



        private static bool ValidProperties(List<string> l)
        {
            if (l == null) return true;
            var ok = l.Where(o => propNames.ContainsKey(o)).Count() == l.Count();
            if (ok) return ok;
            throw new Exception("invalid properties names");
        }

        private static List<string> checkFld(List<string> its)
        {
            //var sits = its as List<String>;
            //if (its == null || its.Count() == 0) return new List<T>();
            if (its is List<string>)
            {
                return its.Where(it => CheckValidString(it)).ToList();// TODO improve security / injection
            }
            throw new Exception("check field is null");
        }

        private static bool CheckValidString(string it)
        {
            return it.All(c => char.IsLetterOrDigit(c));
        }


    }

}
