﻿using Newtonsoft.Json;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using static Pea.Model.Constants;

namespace Pea.Business
{
    public class NotificarBusiness
    {
        private const string mailApp = "eApplication";
        HttpClient client = new HttpClient(); // no requiere dispose, no requiere crearlo multiples vesces como webclient
        public void EnviarNotificaciones()
        {
            //// NTH para este tipo de colas es conveniente usar rabbitmq en lugar de un job iterativo hacia una cola de notificacion en db.
            // utilizar rabbit o enqueue de hangfire si se requiere escalar a multiple threads de bulk notif
            //// refact a Notificar de cola lenta de BackgroundJob.Enqueue(() => NotificarInteresados(new NotifyStateChangeInfo{ id = sol.id, state=estado, user = user, role = role, isauto=false }));
            using (var ctx = new Pea.DataAccess.BaseContext<Notificacion>().GetDbCtx())
            {
                // procesa notificaciones de la solicitudes
                var list = from notificacion in ctx.Notificacion
                           join solicitud in ctx.Solicitud.Include(o => o.DatosPA)
                           on notificacion.gid equals solicitud.id
                           join sync in ctx.Sync
                           on solicitud.id equals sync.id
                           where notificacion.done == false && notificacion.name == "Solicitud" && sync.name == "Solicitud"
                           select new { notificacion, solicitud, solicitud.DatosPA, sync };
                //list.AsParallel().ForAll((o) => { Notificar(o.notificacion, o.solicitud, o.sync); });
                // saco el parallel para cortar el envio en caso de error.
                foreach (var o in list.ToArray())
                {
                    if (!Notificar(o.notificacion, o.solicitud, o.sync).Result)
                    {
                        break; // si se va por error corta el worker
                    }
                }

            }
        }

        // toma notificacion analiza que tiene que hacer y segun el tipo de notif envia mail
        public async Task<bool> Notificar(Notificacion notificacion, Solicitud solicitud, Sync sync)
        {
            NotificacionType type;
            if (Enum.TryParse<NotificacionType>(notificacion.type, out type))
            {
                // READ asume que son todos tipo mail pero diseño queda preparado para otro tipo de notificaciones (ej pushnotifications)
                var mail = SolicitudBusiness.PrepararMailDeNotificacion(type, notificacion, solicitud, sync);
                var wassent = await EnviarMail(mail);
                await updateNotificacionAfterMail(notificacion.nid, mail, wassent);
                if (wassent.isError)
                {
                    return false;
                }
                //mails.AsParallel().ForAll(async (mail) => // sacamos el parallel para evitar sobrecarga en endpoint
                //}
            }
            else
            {
                throw new Exception("no se pudo parsear el type de la notificacion nid:" + notificacion.nid.ToString() + " tipo:" + notificacion.type ?? string.Empty);
            }

            return true;

        }

        private static async Task<Notificacion> updateNotificacionAfterMail(long nid, Mail mail, EnviarMailResult wassent)
        {
            Notificacion notif;
            using (var ctx = new Pea.DataAccess.BaseContext<Notificacion>().GetDbCtx())
            {
                notif = ctx.Notificacion.Find(nid);
                notif.response = JsonConvert.SerializeObject(new { mail = mail, sent = DateTime.UtcNow, wassent = wassent }); // mail como property para permitir mas parametros de retorno
                notif.runs = (notif.runs ?? 0) + 1;
                if (wassent.isError || wassent.isOk == false)
                {
                    if (notif.runs >= mailMaxRetries)
                    {
                        notif.done = true; // deshabilita la notificacion
                    }

                    notif.error = true;
                }
                else if (wassent.isOk)
                {
                    notif.error = false;
                    notif.done = true;
                    notif.ok = true;
                }
                else
                {
                    // estado imposible
                    throw new Exception("Invalid result sending mail " + JsonConvert.SerializeObject(new { mail = mail, sent = DateTime.UtcNow, wassent = wassent }));
                }
                await ctx.SaveChangesAsync();
            }

            return notif;
        }

        static string mailServiceBaseUrl = ConfigurationManager.AppSettings["Mail-ServiceBaseUrl"];
        static string mailSendOnlyTo = ConfigurationManager.AppSettings["Mail-SendOnlyTo"];
        static string mailFrom = ConfigurationManager.AppSettings["Mail-From"];
        static int mailMaxRetries = int.Parse(ConfigurationManager.AppSettings["Mail-MaxRetries"]);

        public class EnviarMailResult
        {
            public bool isOk { get; internal set; }
            public bool isError { get; internal set; }
            public string message { get; internal set; }
        }
        public async Task<EnviarMailResult> EnviarMail(Mail mail)
        {
            try
            {

                //Llamada al Servicio de Envío de mails:
                //$.post('/api/Emails/' + pto + '/' + pfrom + '/' + pcc + '/' + psubject + '/' + pmsg + '/' + app)
                //Datos:
                //Producción: ar01f141vp / WSMail /
                //Desarrollo: ar01f141vd / WSMail /
                //La dirección de envío es "no-reply@prudential.com".
                //En el parámetro APP por default se ingresa eApplication. 
                //En el caso de PCC no se deban enviar datos se debe pasar un string vacío.
                //La respuesta del servicio de email puede ser: 
                //1. { "ErrorDesc":null,"IsOk":true}
                //2. { "ErrorDesc":"se produjo un error","IsOk":false}
                //3.{
                // "ErrorDesc": "An invalid character was found in the mail header: ';'.. pto:gustavomick@gmail.com;domiguel@sofrecom.com.ar;adasilva@sofrecom.com.ar;eschmoll@sofrecom.com.ar;psubject: E-Application  – LP  – Notificación de Anulación;pmsg:Mensaje de prueba.;papp: eApplication;pfrom:prudentialpea@gmail.com",
                //"IsOk": false
                // }
                if (!string.IsNullOrEmpty(mail.To))
                {


                    mail.App = mailApp;
                    mail.From = mailFrom; // "prudentialpea@gmail.com"
                    var to = mail.To;
                    var msg = mail.Msg;
                    var cc = mail.Cc;
                    if (!string.IsNullOrWhiteSpace(mailSendOnlyTo))
                    {
                        to = mailSendOnlyTo;
                        cc = string.Empty;
                        msg = "to:" + mail.To + System.Environment.NewLine + "cc:" + mail.Cc + System.Environment.NewLine + "------" + System.Environment.NewLine + mail.Msg;
                    }
                    //var query = ToQueryString(new Dictionary<string, string>() { { "pto", to }, { "psubject", mail.Subject }, { "pcc", cc }, { "pmsg", msg }, { "papp", mail.App }, { "pfrom", mail.From }, { "phtml", mail.Html.ToString() } });
                    //var url = mailServiceBaseUrl + query; //  @"http://localhost/Prudential.SendMailMock/api/sendEmail/send?pto=gustavomick@gmail.com&psubject=estaesunaprueba&pcc=&pmsg=esteeselbody&papp=pea&pfrom=prudentialpea@gmail.com&phtml=false";
                    //var res = await client.GetAsync(url);
                    var values = new Dictionary<string, string>() { { "pto", to }, { "psubject", mail.Subject }, { "pcc", cc }, { "pmsg", msg }, { "papp", mail.App }, { "pfrom", mail.From }, { "phtml", mail.Html.ToString() } };
                    var url = mailServiceBaseUrl;
                    var res = await client.PostAsync(url, new FormUrlEncodedContent(values));
                    if (res.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var mailres = JsonConvert.DeserializeObject<PrudentialMailResult>(await res.Content.ReadAsStringAsync());
                        return new EnviarMailResult() { isOk = mailres.IsOk, isError = false, message = mailres.ErrorDesc };
                    }
                    else
                    {
                        return new EnviarMailResult() { isOk = false, isError = true, message = "HTTP Error - StatusCode:" + res.StatusCode + " ReasonPhrase:" + res.ReasonPhrase };
                    }
                }
                else
                {
                    return new EnviarMailResult() { isOk = false, isError = true, message = "Mail data Error - TO is empty, is likely to have issues with userservice or/and LP user doesnt exist anymore." };
                }
            }
            catch (Exception ex)
            {
                // LOG HERE
                return new EnviarMailResult() { isOk = false, isError = true, message = ex.ToString() };
            }

        }

        private string ToQueryString(Dictionary<string, string> nvc)
        { // no cubre mas de un param con la misma key
            var array = nvc.Select(o => string.Format("{0}={1}", HttpUtility.UrlEncode(o.Key), HttpUtility.UrlEncode(o.Value)));
            //var array = (from key in nvc.AllKeys
            //             from value in nvc.GetValues(key)
            //             select string.Format("{0}={1}", HttpUtility.UrlEncode(key), HttpUtility.UrlEncode(value)))
            //    .ToArray();
            return "?" + string.Join("&", array);
        }
    }
}
