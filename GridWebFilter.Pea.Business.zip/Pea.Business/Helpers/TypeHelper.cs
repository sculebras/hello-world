﻿using Humanizer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pea.Business.Helpers
{
    public static class TypeHelper
    {
        public static Type GetType(ref string entity)
        {
            //seccion
            //var dbsetType = typeof(System.Data.Entity.DbSet<>).MakeGenericType();
            entity = entity.Pascalize();
            //if (enabledRoutes.Keys.Contains(ent))
            //{
            return Type.GetType("Pea.Model." + entity + ",Pea.Model");
            // TODO cachear                
        }

    }
}
