﻿using Autofac;
using Pea.Business;
using Pea.Contracts;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pea.Business
{
    public class BusinessAutofacModule : Module
    {
        // http://docs.autofac.org/en/latest/configuration/modules.html
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterGeneric(typeof(GenericBusiness<>)).As(typeof(BusinessHandler<>));
            builder.RegisterType(typeof(SolicitudBusiness)).As(typeof(BusinessHandler<Solicitud>));
            builder.RegisterType(typeof(SyncBulkBusiness)).As(typeof(BusinessHandler<SyncBulk>));
            //builder.RegisterAssemblyTypes(this.ThisAssembly)
            //       .Where(t => t.Name.EndsWith("Business")).AsImplementedInterfaces();
        }
    }
}