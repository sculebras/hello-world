﻿using Pea.Business.Helpers;
using Pea.Contracts;
using Pea.Model;
using Pea.Model.Filters;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Dynamic;
using System.Threading.Tasks;

namespace Pea.Business
{
    public class SyncBulkBusiness : BusinessHandler<SyncBulk>
    {

        class InternalSyncGroup
        {
            public string name { get; set; }
            public List<string> ids { get; set; }
            public DateTimeOffset maxDate { get; set; }
            public DateTimeOffset currentDate { get; set; }
            public List<Syncable> deletedRows { get; set; }

        }

        public override async Task<IResult<SyncBulk>> Read(IReadFilter filter)
        {
            // TEST http://localhost/Eapplication-Api/v1/SyncBulk?$filter=%7B%22serverupdated%22:%7B%22$gt%22:%221970-01-01T00:00:00.000Z%22%7D%7D&$orderby=%5B%5B%22serverupdated%22,%22Asc%22%5D%5D&$select=%5B%22gid%22,%22id%22,%22ver%22,%22name%22,%22serverupdated%22%5D&$top=500

            // version no bizgeneric
            var res = new Result<SyncBulk>();
            try
            {
                // version bizgeneric
                //var biz = new GenericBusiness<Sync>();
                //var res = await biz.Read(filter);
                //var res1 = ((IEnumerable<dynamic>)res.values)
                //    .GroupBy(o => o.name)
                //    .Select(g => new InternalSyncGroup { name = g.Key, ids = g.Select(go => (string)go.id).ToList(), maxDate = g.Max(o => o.serverupdated), })
                //    .ToList();

                // version no bizgeneric
                var user = UserBusiness.GetMyUserName() ?? string.Empty; // tomar usuario del UserBiz
                var roles = UserBusiness.GetMyRoles().ToDictionary((o) => o);
                var agents = UserBusiness.GetMyAgents().Select(o => o.Usuario).ToList();
                var users = new List<string>(agents);
                users.Add(user);
                var top = 1000000; // filter.top ?? 10000; // TOFIX paginado ordena por nombre en lugar de create
                var lastsync = (DateTimeOffset)filter.where.FirstOrDefault().value;
                List<InternalSyncGroup> changedids = null;
                dynamic deletedgids = null;
                DateTimeOffset maxdeletedgids;
                using (var ctx = new Pea.DataAccess.BaseContext<Sync>().GetDbCtx())
                {

                    // los delete que se requiere borrar en mobile porque se cambio de estado
                    // it works like a statemachine, asumes that if 5 and was changed then its moving from 4 to 5, so notify deleted 
                    var dgids = (from syncgid in ctx.Sync
                                 where
                                 syncgid.stateupdated > lastsync &&
                                 syncgid.state == "5" && syncgid.name == "Solicitud"
                                 select syncgid).GroupBy(o => o.name)
                                   .Select(g => new { g.Key, gids = g.Select(o1 => o1.gid).ToList(), maxDate = g.Max(o => o.serverupdated) })
                                   .ToDictionary(o => o.Key, o => new { o.gids, o.maxDate });
                    maxdeletedgids = dgids.Select(o => (DateTimeOffset?)o.Value.maxDate).Max() ?? DateTime.MinValue;
                    deletedgids = dgids.ToDictionary(o => o.Key, o => o.Value.gids);

                    // los changes en estados normales de mobile
                    List<string> mobileStates = (new List<string> { "1", "2", "3", "4" });
                    changedids = (from sync in ctx.Sync
                                  join syncgid in ctx.Sync
                                  on sync.gid equals syncgid.gid
                                  where
                                  sync.serverupdated > lastsync && // filtro fecha
                                  users.Contains(sync.createdby) && // filtro del logico y usuario
                                                                    // filtro para que envie estados visibles por mobile solamente            
                                                                    // NTH configurable fuera del bulk, b join con talba normalizada syncgid en lugar de filtrar a si misma
                                  mobileStates.Contains(syncgid.state) && syncgid.name == "Solicitud"
                                  select sync)
                                //res1 = ctx.Sync
                                //.Where(o => o.serverupdated > lastsync) // filtro fecha
                                //.Where(o => users.Contains(o.createdby)) // filtro del logico y usuario
                                .OrderBy(o => o.createdby)
                                .Take(top)
                                .GroupBy(o => o.name)
                                .Select(g => new InternalSyncGroup
                                {
                                    name = g.Key,
                                    ids = g.Where(od0 => !od0.del).Select(go => (string)go.id).ToList(),
                                    maxDate = g.Max(o => o.serverupdated),
                                    currentDate = DateTime.UtcNow,
                                    deletedRows = g.Where(od => od.del)
                                    .Select(od1 => new Syncable()
                                    {
                                        gid = od1.gid,
                                        id = od1.id,
                                        ver = od1.ver,
                                        del = od1.del,
                                        updated = od1.updated,
                                        updatedby = od1.updatedby,
                                        created = od1.created,
                                        createdby = od1.createdby
                                    }).ToList()
                                })
                                .ToList();
                }
                lastsync = lastsync < maxdeletedgids ? maxdeletedgids : lastsync;
                res = await GetPerSet(changedids, lastsync);
                //if (deletedgids.Count() > 0)
                res.meta.Add("gidsdeleted", deletedgids);

            }
            catch (Exception ex)
            {
                res.ok = false;
                res.message = ex.ToString();
            }

            return res;


            //dynamic repo;
            //foreach (var item in res1)
            //{
            //    var name = (string) item.name;

            //    ctx.Database.SqlQuery(TypeHelper.GetType(ref name), "select * from " + name)

            //    repo = Activator.CreateInstance(typeof(GenericBusiness<>).MakeGenericType(new Type[] { TypeHelper.GetType(ref name) }));
            //    var filter2 = new ReadFilter();
            //    filter2.where = new List<WhereTy>() { new WhereTy() { prop = "id", oper = OperTy.in_, value = item.ids } };
            //    var resrepo = await repo.Read(filter2);
            //    var b = resrepo;

            //}
            //return new Result<SyncBulk>();
        }

        private static async Task<Result<SyncBulk>> GetPerSet(List<InternalSyncGroup> res1, DateTimeOffset lastsync)
        {
            var res = new Result<SyncBulk>();
            var values = new List<SyncBulk>();
            res.ok = true;
            if (res1.Count() == 0)
            {
                res.ok = true;
                res.values = new List<object>();
                res.meta = new Dictionary<string, object>() { { "lastsync", lastsync } };
                return res;
            }

            var lsync = res1.Max(o => o.maxDate);
            lastsync = lastsync < lsync ? lsync : lastsync;
            res.meta = new Dictionary<string, object>() { { "lastsync", lastsync } };

            foreach (var item in res1)
            {
                var name = (string)item.name;

                // TODO cachear reflec
                var type = TypeHelper.GetType(ref name);
                dynamic genbiz = Activator.CreateInstance(typeof(GenericBusiness<>).MakeGenericType(new Type[] { type }));

                var filter2 = new ReadFilter();
                filter2.where = new List<WhereTy>() { new WhereTy() { prop = "id", oper = OperTy.in_, value = item.ids } };
                var resrepo = (await genbiz.Read(filter2)).values;
                resrepo.AddRange(item.deletedRows);

                // sqlquery directo no funciona por mapeo en domicilio1
                //var sids = string.Join(",", item.ids.Select(o => "'" + o + "'")); // item.ids.Aggregate((a1, a2) => a1 + ",'" + a2 +"'" );
                //var resrepo = await ctx.Database.SqlQuery(type, "select * from " + name + " where id in (" + sids + ")")
                //    .ToListAsync();

                // con linq.dynamic
                //var eids = item.ids.AsEnumerable();
                //var resrepo = ctx.Database.SqlQuery(type,"select * from " + name)
                //    .Where("@0.Contains(outerIt.id)", eids);

                values.Add(new SyncBulk() { rows = resrepo, name = item.name });


            }
            res.values = values;
            return res;
        }

        public override Task<IResultOne<SyncBulk>> Create(SyncBulk obj, Dictionary<string, object> dic = null)
        {
            throw new NotImplementedException();
        }

        public override Task<IResult<SyncBulk>> CreateBulk(IList<SyncBulk> objs, List<Dictionary<string, object>> list = null)
        {
            throw new NotImplementedException();
        }

        public override Task<IResultOne<SyncBulk>> Delete(SyncBulk obj, Dictionary<string, object> dic = null)
        {
            throw new NotImplementedException();
        }

        public override Task<IResult<SyncBulk>> DeleteBulk(IList<SyncBulk> objs, List<Dictionary<string, object>> list = null)
        {
            throw new NotImplementedException();
        }

        public override Task<IResultOne<SyncBulk>> ReadOne(IReadFilter filter)
        {
            throw new NotImplementedException();
        }

        public override Task<IResultOne<SyncBulk>> Update(SyncBulk obj, Dictionary<string, object> dic = null)
        {
            throw new NotImplementedException();
        }

        public override Task<IResult<SyncBulk>> UpdateBulk(IList<SyncBulk> objs, List<Dictionary<string, object>> list = null)
        {
            throw new NotImplementedException();
        }
    }

}