﻿using Hangfire;
using Pea.Business.Helpers;

namespace Pea.Business
{
    public static class SchedulerBusiness
    {
        public static void Start()
        {
            RecurringJob.AddOrUpdate("SolicitudBusiness.AutoAnularYElminar", () => AutoAnularYElminar(), Cron.Hourly);
            RecurringJob.AddOrUpdate("SolicitudBusiness.AutoCrearNotificacionesPorProximosVencimientos", () => AutoCrearNotificacionesPorProximosVencimientos(), Cron.Hourly);
            RecurringJob.AddOrUpdate("NotificarBusiness.EnviarNotificaciones", () => EnviarNotificaciones(), Cron.Minutely);
        }

        public static void AutoAnularYElminar()
        {
            LoggerHelper.ExceptionCatchAndLog(() =>
           {
               UserBusiness.SetIdentityAsWorker();
               var solbiz = (new SolicitudBusiness());
               solbiz.AutoAnularYElminar();
           });
        }

        public static void AutoCrearNotificacionesPorProximosVencimientos()
        {
            LoggerHelper.ExceptionCatchAndLog(() =>
            {
                UserBusiness.SetIdentityAsWorker();
                var solbiz = (new SolicitudBusiness());
                solbiz.AutoCrearNotificacionesPorProximosVencimientos();
            });
        }
        public static void EnviarNotificaciones()
        {
            LoggerHelper.ExceptionCatchAndLog(() =>
            {
                UserBusiness.SetIdentityAsWorker();
                var notibiz = (new NotificarBusiness());
                notibiz.EnviarNotificaciones();
            });
        }

    }
}
