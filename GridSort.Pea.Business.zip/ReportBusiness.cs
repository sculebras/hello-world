﻿using Pea.Business.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pea.Business
{
    public class ReportBusiness
    {
        public MemoryStream GeneratePdfReport(string idSolicitud)
        {
            var pdfReportGenerator = new PdfReportGeneratorHelper();
            return pdfReportGenerator.Generate(idSolicitud);
        }
    }
}
