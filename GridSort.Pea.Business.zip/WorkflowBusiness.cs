﻿using Pea.Contracts;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pea.Model.Constants;

namespace Pea.Business
{
    class WorkflowBusiness
    {

        public static bool ValidateWorkflowAuthorization<T>(T ent, string entityName,meths meth, Dictionary<string, object> dic)
            where T :ISyncable
        {
            if (entityName == "SolicitudSeccion")
            {
                return true;
            }

            var role = UserBusiness.GetMyRoles().FirstOrDefault();

            if (role == Role.Worker)
            {
                return true;
            }
           
            var canChangeState = true;
            EstadoType estado = EstadoType.Nueva;
            Solicitud solicitudActual = new Solicitud();
            if (meth != meths.create)
            {
                solicitudActual = GenericBusiness<Solicitud>.GetOrFindAddToCache(ent.gid);
                if (!Enum.TryParse<EstadoType>(solicitudActual.Estado, out estado))
                {
                    throw new Exception("estado from solicitud " + solicitudActual.id + " cant be parsed: " + solicitudActual.Estado.ToString());
                }

                if (role == Role.FSS)
                {
                    var agentes = UserBusiness.GetMyAgents();
                    if(!agentes.Any(a=>a.Usuario == solicitudActual.createdby))
                    {
                        return false;
                    }
                }
                else if(role == Role.LP)
                {
                    if(UserBusiness.GetMyIdentity().Name != solicitudActual.createdby)
                    {
                        return false;
                    }
                }
            }
            ////////
            switch (meth)
            {
                case meths.create:
                case meths.delete:
                    return role == Role.LP ;
                case meths.read:
                    throw new Exception("invalid method executed");
                //switch (estado)
                //{
                //    case EstadoType.Nueva:
                //    case EstadoType.Firmada:
                //        return role == Role.LP;
                //    case EstadoType.Reportada:
                //    case EstadoType.Anulada:
                //        return role == Role.LP || role == Role.FSS;
                //    case EstadoType.Completa:
                //        return role == Role.FSS || role == Role.AM || role == Role.SM;
                //    case EstadoType.Presentada:
                //        return role == Role.FSS || role == Role.AM || role == Role.SM;
                //    default:
                //        return false;
                //}

                case meths.merge: // TODO caso merge a revisar
                case meths.update:
                    if (role == Role.AM || role == Role.SM)
                    {
                        return false;
                    }
                    if (entityName == "Solicitud" && ((dic.ContainsKey("Estado") || ent.del)))
                    {
                        Solicitud solicitud = ent as Solicitud;
                        EstadoType estadoNuevo;
                        if (!Enum.TryParse<EstadoType>(solicitud.Estado, out estadoNuevo))
                        {
                            throw new Exception("estado from solicitud " + solicitud.id + " cant be parsed: " + solicitud.Estado.ToString());
                        }

                        if (!PuedeCambiarEstado(estado, estadoNuevo))
                            return false;
                    }

                    return PuedeCambiarOtrasPropsEnEstado(dic, role, estado);
            }

            return false;

        }

        private static bool PuedeCambiarOtrasPropsEnEstado(Dictionary<string, object> dic, Role role, EstadoType estado)
        {
            var onlyChangeState = true;

            List<string> validProps = new List<string>();
            validProps.Add("id");
            validProps.Add("ver");
            validProps.Add("oldver");
            validProps.Add("Estado");
            foreach (var k in dic.Keys)
            {
                if (!validProps.Contains(k))
                {
                    onlyChangeState = false;
                }
            }

            switch (estado)
            {
                case EstadoType.Nueva:
                case EstadoType.Firmada:
                    return role == Role.LP;
                case EstadoType.Reportada:
                    return role == Role.LP || (onlyChangeState && role == Role.FSS);
                case EstadoType.Completa:
                    return onlyChangeState && role == Role.FSS;
                default:
                    return false;
            }
        }

        public static bool PuedeCambiarEstado(EstadoType estado, EstadoType estadoNuevo)
        {
            Role role = Role.Worker;
            var user = UserBusiness.GetMyUserName();
            if (user != null)
            {
                role = UserBusiness.GetMyRoles().FirstOrDefault();
            }
           
            switch (estado)
            {
                case EstadoType.Nueva:
                    return (role == Role.LP && (estadoNuevo == EstadoType.Firmada || estadoNuevo == EstadoType.Eliminada));
                case EstadoType.Firmada:
                    return (role == Role.LP && (estadoNuevo == EstadoType.Reportada || estadoNuevo == EstadoType.Anulada));
                case EstadoType.Reportada:
                    if (role == Role.LP && (estadoNuevo == EstadoType.Completa || estadoNuevo == EstadoType.Anulada))
                    {
                        return true;
                    }
                    else if (role == Role.FSS && (estadoNuevo == EstadoType.Firmada || estadoNuevo == EstadoType.Anulada))
                    {
                        return true;
                    }
                    return false;
                case EstadoType.Anulada:
                    return false;
                case EstadoType.Completa:
                    return (role == Role.FSS && (estadoNuevo == EstadoType.Anulada || estadoNuevo == EstadoType.Reportada || estadoNuevo == EstadoType.Presentada));
                default:
                    return false;

            }
        }

    }
}
