﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using libphonenumber;
using Pea.Model;
using System.Text.RegularExpressions;

namespace Pea.Business.Helpers
{
    public class InfoFormatterHelper
    {
        public const string YES_LABEL = "Sí";
        public const string NO_LABEL = "No";

        public enum FormatType { TELEPHONE, CLAVE_TRIBUTARIA, NONE };

        public enum Symbols { ARS_USD, ARS, USD, LENGHT, WEIGTH, PLUS, MINUS }
        public static string Format(decimal? value)
        {
            NumberFormatInfo nfi = new CultureInfo("es-AR", false).NumberFormat;
            nfi.NumberDecimalDigits = 2;
            return value.HasValue ? value.Value.ToString("N", nfi) : string.Empty;
        }

        public static string Format(string value)
        {
            return value ?? " ";
        }

        public static string Format(long? value)
        {
            return value.HasValue ? value.Value.ToString() : string.Empty;
        }

        public static string Format(int? value)
        {
            return value.HasValue ? value.Value.ToString() : string.Empty;
        }

        public static string Format(bool? value)
        {
            return value.HasValue ? (value.Value ? YES_LABEL : NO_LABEL) : string.Empty;
        }

        public static string Format(DateTime? value)
        {
            return value.HasValue ? value.Value.ToString("dd/MM/yyyy", System.Globalization.CultureInfo.GetCultureInfo("ES-ar")) : string.Empty;
        }

        public static string Format(decimal? value, Symbols? prefix, Symbols? suffix)
        {
            return Format(Format(value), prefix, suffix);
        }

        public static string Format(long? value, Symbols? prefix, Symbols? suffix)
        {
            return Format(Format(value), prefix, suffix);
        }

        public static string Format(string value, FormatType format)
        {
            if (string.IsNullOrEmpty(value))
                return InfoFormatterHelper.Format(value);

            switch (format)
            {
                case FormatType.CLAVE_TRIBUTARIA:
                    if (value.Contains("-"))
                    {
                        return value;
                    }
                    var nro1 = value.Substring(0, 2);
                    var nro2 = value.Length > 2 ? value.Substring(2, 8) : " ";
                    var nro3 = value.Length > 10 ? value.Substring(10, 1) : " ";
                    return string.Format("{0}-{1}-{2}", nro1, nro2, nro3);
            }
            return InfoFormatterHelper.Format(value);
        }

        public static string Format(string value, Symbols? prefix, Symbols? suffix)
        {
            var result = Format(value);

            if (suffix.HasValue)
                result = string.Format("{0} {1}", result, GetSymbolValue(suffix.Value));

            if (prefix.HasValue)
                result = string.Format("{0} {1}", GetSymbolValue(prefix.Value), result);
            return result;
        }

        public static string FormatMoney(long? value, InfoFormatterHelper.Symbols? symbol)
        {
            NumberFormatInfo nfi = new CultureInfo("es-AR", false).NumberFormat;
            nfi.NumberDecimalDigits = 0;
            if (symbol.HasValue)
            {
                return Format((value.HasValue ? value.Value.ToString("N", nfi) : string.Empty), symbol.Value, null);
            }
            else
            {
                return value.HasValue ? value.Value.ToString("N", nfi) : string.Empty;
            }
        }

        public static string FormatMoney(long? value, IEnumerable<TipoMoneda> tiposMoneda, string tipoMonedaId)
        {
            NumberFormatInfo nfi = new CultureInfo("es-AR", false).NumberFormat;
            nfi.NumberDecimalDigits = 0;

            var moneda = tiposMoneda.Where(t => t.id == tipoMonedaId).FirstOrDefault() ?? new TipoMoneda();
            return string.Format("{0} {1}", moneda.name, (value.HasValue ? value.Value.ToString("N", nfi) : string.Empty));

        }

        public static string FormatMoney(long? value, Symbols symbol)
        {
            NumberFormatInfo nfi = new CultureInfo("es-AR", false).NumberFormat;
            nfi.NumberDecimalDigits = 0;
            return FormatMoney(value.HasValue ? value.Value.ToString("N", nfi) : string.Empty, symbol);
        }

        public static string FormatMoney(string value, Symbols symbol)
        {
            return string.Format("{0} {1}", GetSymbolValue(symbol), Regex.Replace(Format(value), @"(\d)(?=(\d{3})+(?!\d))", "$1."));
        }

        public static string FormatName(string name, string lastName)
        {
            return string.Format("{0} {1}", name, lastName);
        }

        public static string FormatDate(int? day, int? month, int? year)
        {
            if (day.HasValue && month.HasValue && year.HasValue)
                return string.Format("{0}/{1}/{2}", InfoFormatterHelper.Format(day), InfoFormatterHelper.Format(month), InfoFormatterHelper.Format(year));
            if (month.HasValue && year.HasValue)
                return string.Format("{0}/{1}", InfoFormatterHelper.Format(month), InfoFormatterHelper.Format(year));
            if (year.HasValue)
                return InfoFormatterHelper.Format(year);

            return "";//todas las demas combinaciones son inválidas

        }
        public static string FormatPhone(string value)
        {
            //if (value.HasValue)
            //{
            //    PhoneNumber number = PhoneNumberUtil.Instance.Parse(value.Value.ToString("D"), "AR");
            //    return number.Format(PhoneNumberUtil.PhoneNumberFormat.NATIONAL);
            //}
            //return string.Empty;

            return value;
        }

        public static string FormatCreditCardNumber(string number)
        {
            var formattedNumber = "";
            if (!string.IsNullOrEmpty(number))
            {
                for (int i = 0; i < number.Length; i += 4)
                {
                    if (i > 0)
                    {
                        formattedNumber += " ";
                    }
                    formattedNumber += number.Substring(i, (number.Length - i) > 4 ? 4 : number.Length - i);
                }
            }
            return formattedNumber;
        }

        private static string GetSymbolValue(Symbols symbol)
        {
            switch (symbol)
            {
                case Symbols.ARS:
                    return "$ AR";
                case Symbols.USD:
                    return "U$S";
                case Symbols.ARS_USD:
                    return "$/U$S";
                case Symbols.LENGHT:
                    return "m";
                case Symbols.WEIGTH:
                    return "kg";
                case Symbols.PLUS:
                    return "+";
                case Symbols.MINUS:
                    return "-";
            }
            return string.Empty;
        }
    }
}