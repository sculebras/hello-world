﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Dynamic;
using Newtonsoft.Json.Converters;

namespace Pea.Business
{
    public static class BusinessConfigHelper
    {

        static string basedir;
        const string fileRelativePath = "/App_Data/config.json";
        const string fileRelativePathNotificaion = "/App_Data/configNotificacion.json";
        private static JObject config;
        private static JObject notificacionConfig;
        static BusinessConfigHelper()
        {
            basedir = AppDomain.CurrentDomain.BaseDirectory;
            Load();

            // read JSON directly from a file
            //using(StreamReader file = File.OpenText(@"c:\videogames.json"))
            //using(JsonTextReader reader = new JsonTextReader(file))
            //{
            //    JObject o2 = (JObject)JToken.ReadFrom(reader);
            //}
        }

        public static JObject Config { get { return config; }  }
        public static JObject notificacionlConfig{ get { return notificacionConfig; } }
        private static void Load()
        {
            //var json = File.ReadAllText(fileName);
            //var obj = JsonConvert.DeserializeObject<IDictionary<string, object>>(
            //    json, new JsonConverter[] { new NestedDictionaryConverter() });
            //config = obj;
            config = JObject.Parse(File.ReadAllText(basedir+fileRelativePath));
            notificacionConfig = JObject.Parse(File.ReadAllText(basedir+fileRelativePathNotificaion));
        }


    }

    class NestedDictionaryConverter : CustomCreationConverter<IDictionary<string, object>>
    {
        public override IDictionary<string, object> Create(Type objectType)
        {
            return new Dictionary<string, object>();
        }

        public override bool CanConvert(Type objectType)
        {
            // in addition to handling IDictionary<string, object>
            // we want to handle the deserialization of dict value
            // which is of type object
            return objectType == typeof(object) || base.CanConvert(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.StartObject
                || reader.TokenType == JsonToken.Null)
                return base.ReadJson(reader, objectType, existingValue, serializer);

            // if the next token is not an object
            // then fall back on standard deserializer (strings, numbers etc.)
            return serializer.Deserialize(reader);
        }
    }
}
