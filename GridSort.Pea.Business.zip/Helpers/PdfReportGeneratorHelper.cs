using iTextSharp.text;
using iTextSharp.text.pdf;
using Newtonsoft.Json;
using Pea.Contracts;
using Pea.DataAccess;
using Pea.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Pea.Business.Helpers
{
    public class PdfReportGeneratorHelper
    {
        private float _y;
        private Document _document;
        private PdfWriter _writter;
        protected PdfStyles _pdfStyler;
        protected PEAEntities _db;

        public PdfReportGeneratorHelper()
        {

        }

        public MemoryStream Generate(string idSolicitud)
        {
            MemoryStream ms = new MemoryStream();

            _db = new PEAEntities();
            _pdfStyler = new PdfStyles();
            _document = new Document(PageSize.A4);
            _document.SetMargins(_document.LeftMargin - 16, _document.RightMargin - 10, _document.TopMargin - 6, _document.BottomMargin - 18);
            _writter = PdfWriter.GetInstance(_document, ms);
            _writter.CloseStream = false;
            _document.Open();

            InitYCoordinate();

            var solicitud = GetOne<Solicitud>(idSolicitud) ?? new Solicitud();

            var caratula = GetOne<Caratula>(solicitud.id) ?? new Caratula();
            var datosPa = GetOne<DatosPA>(solicitud.id) ?? new DatosPA();
            var infoLp = Get<InformacionLP>(solicitud.id);
            var modalidadPago = GetOne<ModalidadPago>(solicitud.id) ?? new ModalidadPago();
            var addressQuery = GetaddressQuery();
            var otherLifeInssurance = Get<SeguroDeVida>(datosPa.id);
            var beneficiarios = Get<Beneficiario>(solicitud.id);
            var representanteLegal = GetOne<TomadorDatosRepresentanteLegal>(solicitud.id) ?? new TomadorDatosRepresentanteLegal();
            var datosEmpresa = GetOne<TomadorDatosEmpresa>(solicitud.id) ?? new TomadorDatosEmpresa();
            var datosPersonaFisica = GetOne<TomadorPersonaFisica>(solicitud.id) ?? new TomadorPersonaFisica();
            var cobertura = GetOne<Cobertura>(solicitud.id) ?? new Cobertura();
            var pagador = GetOne<DatosDelPagador>(solicitud.id) ?? new DatosDelPagador();
            var tipoDocumento = Get<TipoDocumento>();
            var tipoTarjetaCredito = Get<TipoTarjetaCredito>();
            var tipoMoneda = Get<TipoMoneda>();
            var antecedentesMedicos = Get<AntecedentesMedicos>(solicitud.id);

            var secciones = Get<Seccion>();


            var designaciones = Get<Designacion>();
            var tipoCargo = Get<TipoCargo>();
            var horariosContacto = Get<HorariosContacto>(caratula.id);
            var tipoTelefono = Get<TipoTelefonoFijo>();
            var horarios = Get<Horario>();
            var dias = Get<DiaSemana>();
            var section0Generator = new Section0Generator(PageWidth(), tipoDocumento);
            AddTables(section0Generator.Generate(solicitud.NroSolicitud, caratula, datosPa, infoLp, modalidadPago, designaciones, tipoCargo, horariosContacto, tipoTelefono, horarios, dias, tipoTarjetaCredito, tipoMoneda));

            AddEmptyPage();

            NewPage();

            var tipoSexo = Get<Sexo>();
            var tipoEstadoCivil = Get<TipoEstadoCivil>();
            var nacionalidades = Get<Nacionalidad>();
            var tipoIva = Get<Iva>();
            var tipoSeguro = Get<TipoSeguro>();
            var provincias = Get<Provincia>();
            var tipoFinalidad = Get<Finalidad>();
            var tipoClaveTributaria = Get<TipoClaveTributaria>();

            var sectionAGenerator = new SectionAGenerator(PageWidth());
            sectionAGenerator.TiposDocumento = tipoDocumento;
            sectionAGenerator.TiposClaveTributaria = tipoClaveTributaria;
            AddTables(sectionAGenerator.Generate(solicitud.NroSolicitud, datosPa, addressQuery, otherLifeInssurance, tipoSexo, tipoEstadoCivil, nacionalidades, tipoIva, tipoSeguro, provincias, tipoFinalidad, tipoMoneda));

            var sectionBGenerator = new SectionBGenerator(PageWidth(), tipoDocumento);
            sectionBGenerator.TiposDocumento = tipoDocumento;
            sectionBGenerator.TiposClaveTributaria = tipoClaveTributaria;
            AddTables(sectionBGenerator.Generate(beneficiarios));

            var caracteresPedidoCobro = Get<CaracterPedido>();
            var modalidadPagoBeneficio = GetOne<ModalidadPagoBeneficio>(solicitud.id) ?? new ModalidadPagoBeneficio();
            var tipoOpcionPago = Get<TipoOpcionPago>();
            var tipoPagoRentaTemporaria = Get<TipoPagoRentaTemporaria>();
            AddTables((new SectionCGenerator(PageWidth(), tipoDocumento)).Generate(modalidadPagoBeneficio, caracteresPedidoCobro, tipoOpcionPago, tipoPagoRentaTemporaria, tipoMoneda));

            NewPage();

            var datosTomador = GetOne<DatosDelTomador>(solicitud.id) ?? new DatosDelTomador();

            var sectionDGenerator = new SectionDGenerator(PageWidth(), tipoDocumento);
            sectionDGenerator.TiposClaveTributaria = tipoClaveTributaria;
            AddTables(sectionDGenerator.Generate(datosTomador, datosPersonaFisica, addressQuery, datosEmpresa, representanteLegal, tipoSexo, tipoEstadoCivil, nacionalidades, tipoIva, tipoFinalidad, provincias));

            NewPage();

            var opcionCuentaFondosAdicionales = Get<OpcionCuentaFondosAdicionales>();
            var tipoPrestamoPagoAut = Get<PrestamoPagoAut>();
            var tipoCaducidad = Get<Caducidad>();
            var tipoCoberturaPesos = Get<TipoCoberturaPesos>();
            var tipoCoberturaDolar = Get<TipoCoberturaDolar>();
            AddTables((new SectionEGenerator(PageWidth(), tipoDocumento)).Generate(solicitud.NroSolicitud, cobertura, tipoMoneda, opcionCuentaFondosAdicionales, tipoPrestamoPagoAut, tipoCaducidad, tipoCoberturaDolar, tipoCoberturaPesos));


            var tipoFrecuenciaPago = Get<TipoFrecuenciaPago>();
            var tipoMedioPago = Get<TipoMedioPago>();
            var tipoFechaDebito = Get<TipoFechaDebito>();
            var tipoCuentaDebito = Get<TipoCuentaDebito>();
            AddTables((new SectionFGenerator(PageWidth(), tipoDocumento)).Generate(modalidadPago, tipoMoneda, tipoFrecuenciaPago, tipoMedioPago, tipoFechaDebito, tipoTarjetaCredito, tipoCuentaDebito));


            var sectionGGenerator = new SectionGGenerator(PageWidth(), tipoDocumento);
            sectionGGenerator.TiposDocumento = tipoDocumento;
            sectionGGenerator.TiposClaveTributaria = tipoClaveTributaria;
            AddTables(sectionGGenerator.Generate(pagador, tipoSexo, tipoEstadoCivil, nacionalidades));

            NewPage();

            var otrasActPa = GetOne<OtrasActDelPA>(solicitud.id) ?? new OtrasActDelPA();
            AddTables((new SectionHGenerator(PageWidth(), tipoDocumento)).Generate(otrasActPa));


            var antecedentesFamiliaresPa = Get<AntecedentesFamDelPA>(solicitud.id);
            var relacionesParentezco = Get<TipoRelacionParentesco>();
            var sectionIGenerator = new SectionIGenerator(PageWidth(), tipoDocumento);
            AddTables(sectionIGenerator.Generate(antecedentesFamiliaresPa, relacionesParentezco));
            var infoPA = GetOne<InfoMedicaDelPA>(solicitud.id) ?? new InfoMedicaDelPA();
            var ultimoConsultado = GetOneById<DatosMedico>(infoPA.DatosUltimoConsultado) ?? new DatosMedico();
            var medicoCabecera = GetOneById<DatosMedico>(infoPA.DatosMedicoCabecera) ?? new DatosMedico();
            AddTables((new SectionJGenerator(PageWidth(), tipoDocumento)).Generate(infoPA, ultimoConsultado, medicoCabecera, addressQuery, provincias));

            NewPage();

            var contextura = GetOne<ContexturaPA>(solicitud.id) ?? new ContexturaPA();
            AddTables((new SectionKGenerator(PageWidth(), tipoDocumento)).Generate(solicitud.NroSolicitud, contextura));

            var usoNicotina = GetOne<UsoNicotina>(solicitud.id) ?? new UsoNicotina();
            AddTables((new SectionLGenerator(PageWidth(), tipoDocumento)).Generate(usoNicotina));

            var antecedentesMedicosPa = GetOne<AntecedentesMedicosPA>(solicitud.id) ?? new AntecedentesMedicosPA();

            var sectionMFGenerator = new SectionMGenerator(PageWidth(), antecedentesMedicos);
            AddTables(sectionMFGenerator.GeneratePage1(antecedentesMedicosPa));

            NewPage();

            AddTables(sectionMFGenerator.GeneratePage2(antecedentesMedicosPa));

            //Cuestionarios:
            var cuestionarioInfoAdicionalPa = new CuestionarioInfoAdicionalPa(PageWidth(), tipoDocumento);
            var infoAdicionalPaCuestionario = GetOne<CuestionarioXVII>(solicitud.id);
            if (infoAdicionalPaCuestionario != null && cuestionarioInfoAdicionalPa.FueCargado<CuestionarioXVII>(infoAdicionalPaCuestionario))
            {
                NewPage();
                AddTables(cuestionarioInfoAdicionalPa.Generate(infoAdicionalPaCuestionario));
            }

            var antecedentesEnfResp = antecedentesMedicos.Where(a => a.id == antecedentesMedicosPa.ProblemaRespiratorio).FirstOrDefault();
            var cuestionarioEnfRespGenerator = new CuestionarioEnfermedadesRespiratoriasGenerator(PageWidth(), tipoDocumento);
            if (antecedentesEnfResp != null && antecedentesEnfResp.Respuesta.HasValue && antecedentesEnfResp.Respuesta.Value)
            {
                var cuestionarioXIII = GetOne<CuestionarioXIII>(solicitud.id);
                if (cuestionarioXIII != null && cuestionarioEnfRespGenerator.FueCargado<CuestionarioXIII>(cuestionarioXIII))
                {
                    AddEmptyPage();
                    NewPage();
                    AddTables(cuestionarioEnfRespGenerator.Generate(datosPa, cuestionarioXIII, solicitud.NroSolicitud));
                }
            }

            var antecedentesEmbarazo = antecedentesMedicos.Where(a => a.id == antecedentesMedicosPa.EstaEmbarazada).FirstOrDefault();
            var cuestionarioEmbarazoGenerator = new CuestionarioEmbarazoGenerator(PageWidth(), tipoDocumento);
            bool yaAgregoHojaBlanco = false;
            if (antecedentesEmbarazo != null && antecedentesEmbarazo.Respuesta.HasValue && antecedentesEmbarazo.Respuesta.Value)
            {
                var cuestionarioXIV = GetOne<CuestionarioXIV>(solicitud.id);
                if (cuestionarioXIV != null && cuestionarioEmbarazoGenerator.FueCargado<CuestionarioXIV>(cuestionarioXIV))
                {
                    AddEmptyPage();
                    NewPage();
                    AddTables(cuestionarioEmbarazoGenerator.Generate(datosPa, cuestionarioXIV, provincias, addressQuery, solicitud.NroSolicitud));
                    var extras = cuestionarioEmbarazoGenerator.GenerateExtras();
                    if (extras.Count() > 0)
                    {
                        NewPage();//Agrego la hoja del reverso con los datos que faltan
                        AddTables(extras);
                        yaAgregoHojaBlanco = true;
                    }                    
                }
            }

            var antecedenteConsumoDrogas = antecedentesMedicos.Where(a => a.id == antecedentesMedicosPa.HaUsadoDrogas).FirstOrDefault();
            if (antecedenteConsumoDrogas != null && antecedenteConsumoDrogas.Respuesta.HasValue && antecedenteConsumoDrogas.Respuesta.Value)
            {
                var cuestionarioDrogasGenerator = new CuestionarioDrogasGenerator(PageWidth(), tipoDocumento);
                var cuestionarioXV = GetOne<CuestionarioXV>(solicitud.id);
                if (cuestionarioXV != null && cuestionarioDrogasGenerator.FueCargado<CuestionarioXV>(cuestionarioXV))
                {
                    if (!yaAgregoHojaBlanco)
                    {
                        AddEmptyPage();
                        yaAgregoHojaBlanco = false;
                    }
                    NewPage();
                    var datosConsumoDroga = Get<DatosConsumoDroga>(solicitud.id);
                    
                    AddTables(cuestionarioDrogasGenerator.Generate(datosPa, cuestionarioXV, datosConsumoDroga, solicitud.NroSolicitud));
                    var extras = cuestionarioDrogasGenerator.GenerateExtras();
                    if(extras.Count() > 0)
                    {
                        NewPage();//Agrego la hoja del reverso con los datos que faltan
                        AddTables(extras);
                        yaAgregoHojaBlanco = true;
                    }
                }
            }

            var cuestionarioXVI = GetOne<CuestionarioXVI>(solicitud.id);
            var tipoSociedad = Get<TipoSociedad>();
            var tipoProposito = Get<TipoProposito>();
            var cuestionarioFinancieraGenerator = new CuestionarioInfoFinancieraGenerator(PageWidth(), tipoDocumento);
            if (cuestionarioXVI != null && cuestionarioFinancieraGenerator.FueCargado< CuestionarioXVI>(cuestionarioXVI))
            {
                if (!yaAgregoHojaBlanco)
                {
                    AddEmptyPage();
                    yaAgregoHojaBlanco = false;
                }
                NewPage();
                AddTables(cuestionarioFinancieraGenerator.Generate(datosPa, cuestionarioXVI, tipoSociedad, tipoProposito, solicitud.NroSolicitud));
            }

            ///Extras INI:
            var fotos = Get<FotoDocumento>(solicitud.id);
            var hayExtras = false;
            var tables = section0Generator.GenerateExtras(infoLp, designaciones, tipoCargo).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            tables = sectionAGenerator.GenerateExtras(datosPa, otherLifeInssurance, tipoSeguro, tipoMoneda, fotos.Where(f => f.sec == "A"), nacionalidades).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            tables = sectionBGenerator.GenerateExtras(beneficiarios).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            tables = sectionDGenerator.GenerateExtras(datosTomador, datosPersonaFisica, fotos.Where(f => f.sec == "D"), nacionalidades).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            tables = sectionGGenerator.GenerateExtras(pagador, fotos.Where(f => f.sec == "G"), nacionalidades).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            tables = sectionIGenerator.GenerateExtras(antecedentesFamiliaresPa, relacionesParentezco).ToList();
            if (!hayExtras && tables.Count() > 0)
            {
                hayExtras = true;
                NewPage();
                AddEmptyPage();
            }
            AddBlockTables(tables);
            foreach (var tableLists in sectionMFGenerator.GenerateExtras())
            {
                AddBlockTables(tableLists);
                NewPage();
            }
            ///Extras FIN:


            _document.Close();

            ms.Flush();
            ms.Position = 0;
            return ms;
        }

        private T GetOne<T>(string gid) where T : class, ISyncable
        {
            return _db.Set<T>().Where(t => !t.del && t.gid == gid).FirstOrDefault();
        }

        private T GetOneById<T>(string id) where T : class, ISyncable
        {
            return _db.Set<T>().Where(t => !t.del && t.id == id).FirstOrDefault();
        }


        private IEnumerable<T> Get<T>(string gid) where T : class, ISyncable
        {
            return _db.Set<T>().Where(t => !t.del && t.gid == gid).ToList();
        }

        private IEnumerable<T> Get<T>() where T : class, ISyncable
        {
            return _db.Set<T>().Where(t => !t.del).ToList();
        }

        private void AddTables(IEnumerable<PdfPTable> tables)
        {
            foreach (var table in tables)
            {
                table.WriteSelectedRows(0, -1, _document.LeftMargin, _y, _writter.DirectContent);
                _y -= table.TotalHeight + table.SpacingAfter;
            }
        }

        //Verifica si puede agregar todas las tablas dentro de la misma pagina, sino agrega al inicio de una nueva pagina
        private void AddBlockTables(IEnumerable<PdfPTable> tables)
        {
            var totalHeight = tables.Sum(t => t.TotalHeight);
            if (_y - totalHeight < 0)
            {
                NewPage();
            }
            AddTables(tables);
        }

        private void NewPage()
        {
            _document.NewPage();
            InitYCoordinate();
        }

        private void AddEmptyPage()
        {
            NewPage();
            PdfPTable table = new PdfPTable(new float[] { 100 });
            table.TotalWidth = 100;
            table.WidthPercentage = 100f;
            table.DefaultCell.Border = PdfPCell.NO_BORDER;

            table.AddCell(" ");
            var list = new List<PdfPTable>() { table };
            AddTables(list);
            NewPage();
        }

        protected float PageWidth()
        {
            return _document.PageSize.Width - (_document.LeftMargin + _document.RightMargin);
        }

        /// <summary>
        /// Posiciona la coordenada Y al inicio de la hoja
        /// </summary>
        private void InitYCoordinate()
        {
            _y = _document.PageSize.Height - _document.TopMargin;
        }

        public IQueryable<Domicilio> GetaddressQuery()
        {
            return _db.Set<Domicilio>().AsNoTracking().AsQueryable();
        }
    }

    public class PdfFont
    {
        public enum TipoFuente
        {
            FUENTE_TITULO, POLICY_NUMBER_FONT, FUENTE_SUBTITLE, FUENTE_TITULO_SOLICITUD_POLIZA, FUENTE_TITULO_SECCION, FUENTE_TITULO_SECCION_IDX, FUENTE_TITULO_SECCION_COMENTARIO
                , FUENTE_ENCABEZADO_GRILLA, FUENTE_COMENTARIO_ENCABEZADO_GRILLA, FUENTE_CELDA_ENCABEZADO_CURSIVA_NEGRITA, FUENTE_CELDA_CONTENIDO
                , FUENTE_CELDA_COMENTARIO, FUENTE_COMENTARIO_PIE_GRILLA, FUENTE_COMENTARIO_PIE_GRILLA_TITLE, FUENTE_OPCION_NO_SELECCIONADA, FUENTE_OPCION_SELECCIONADA
        }

        public static Font GetFont(TipoFuente tipo)
        {
            BaseFont baseFont = BaseFont.CreateFont(AppDomain.CurrentDomain.BaseDirectory + "/fonts/arial-narrow.ttf", BaseFont.CP1252, BaseFont.EMBEDDED);
            BaseFont baseFontBold = BaseFont.CreateFont(AppDomain.CurrentDomain.BaseDirectory + "/fonts/arial-narrow-bold.ttf", BaseFont.CP1252, BaseFont.EMBEDDED);
            BaseFont baseFontItalic = BaseFont.CreateFont(AppDomain.CurrentDomain.BaseDirectory + "/fonts/arial-narrow-italic.ttf", BaseFont.CP1252, BaseFont.EMBEDDED);
            BaseFont baseFontItalicBold = BaseFont.CreateFont(AppDomain.CurrentDomain.BaseDirectory + "/fonts/arial-narrow-bold-italic.ttf", BaseFont.CP1252, BaseFont.EMBEDDED);
            Font font = new Font();
            switch (tipo)
            {
                case TipoFuente.FUENTE_TITULO:
                    font = new Font(baseFontBold, 12, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);
                    break;
                case TipoFuente.POLICY_NUMBER_FONT:
                    font = new Font(baseFontBold, 9, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);
                    break;
                case TipoFuente.FUENTE_SUBTITLE:
                    font = new Font(baseFontBold, 9, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_TITULO_SOLICITUD_POLIZA:
                    font = new Font(baseFontBold, 8, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);
                    break;
                case TipoFuente.FUENTE_TITULO_SECCION:
                    font = new Font(baseFontBold, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_TITULO_SECCION_IDX:
                    font = new Font(baseFontBold, 8, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);
                    break;
                case TipoFuente.FUENTE_TITULO_SECCION_COMENTARIO:
                    font = new Font(baseFontItalicBold, 7, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_ENCABEZADO_GRILLA:
                    font = new Font(baseFont, 6.5f, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_COMENTARIO_ENCABEZADO_GRILLA:
                    font = new Font(baseFontItalicBold, 7f, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_CELDA_ENCABEZADO_CURSIVA_NEGRITA:
                    font = new Font(baseFont, 7f, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_CELDA_CONTENIDO:
                    font = new Font(baseFont, 6.5f, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_CELDA_COMENTARIO:
                    font = new Font(baseFontItalicBold, 7, iTextSharp.text.Font.NORMAL, new BaseColor(0, 0, 0));
                    break;
                case TipoFuente.FUENTE_COMENTARIO_PIE_GRILLA:
                    font = new Font(baseFont, 6.8f, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_COMENTARIO_PIE_GRILLA_TITLE:
                    font = new Font(baseFontBold, 9, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_OPCION_NO_SELECCIONADA:
                    font = new Font(baseFont, 6, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
                case TipoFuente.FUENTE_OPCION_SELECCIONADA:
                    font = new Font(baseFont, 6, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
                    break;
            }
            return font;
        }

        public static BaseColor COLOR_FONDO_TITULO_DOCUMENTO = new BaseColor(149, 179, 215);
        public static BaseColor COLOR_FONDO_TITULO_SECCION = new BaseColor(225, 233, 243);
        public static BaseColor COLOR_FONDO_SUBTITULO_SECCION = BaseColor.WHITE;
        public static BaseColor COLOR_FONDO_ENCABEZADO_GRILLA = new BaseColor(234, 234, 234);
        public static BaseColor POLICY_NUMBER_BACKGROUND_COLOR = new BaseColor(166, 166, 166);
        public static BaseColor POLICY_NUMBER_CONTENT_BACKGROUND_COLOR = new BaseColor(230, 230, 230);
        public static BaseColor COLOR_FONDO_CONTENIDO = BaseColor.WHITE;
        public static BaseColor COLOR_FONDO_DOCUMENTO = BaseColor.WHITE;
        public static BaseColor COLOR_FONDO_SOLICITUD_POLIZA = BaseColor.GRAY;

        public static BaseColor COLOR_BORDE_SUBTITULO_SECCION = BaseColor.WHITE;
        public static BaseColor COLOR_BORDE_TABLA = BaseColor.WHITE;
        public static BaseColor COLOR_BORDE_ENCABEZADO_GRILLA = BaseColor.BLACK;
        public static BaseColor COLOR_BORDE_CELDA_CONTENIDOS = BaseColor.BLACK;
    }

    public class PdfStyles
    {
        public enum CellType { TITULO_DOCUMENTO, TITLE_1, SECTION_TITLE_IDX, SECTION_TITLE, SECTION_TITLE_COMMENT, ENCABEZADO_GRILLA, SUBTITLE, GRID_FOTTER_COMMENT, GRID_FOTTER_COMMENT_TITLE, CONTENIDO, COMENTARIO_ENCABEZADO_PREGUNTA, COMENTARIO, SUBTITLE_COMMENT, ENCABEZADO_PREGUNTA, COMENTARIO_ENCABEZADO_GRILLA, TITLE_COMMENT, MARGIN, DOCUMENT_TITLE, POLICY_NUMBER, POLICY_NUMBER_CONTENT, NON_SELECTED };

        public IPdfPCellEvent GetCellStyleEvent(PdfStyles.CellType cellType)
        {
            switch (cellType)
            {
                case PdfStyles.CellType.ENCABEZADO_GRILLA:
                case PdfStyles.CellType.ENCABEZADO_PREGUNTA:
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA:
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA:
                case PdfStyles.CellType.NON_SELECTED:
                    return new CellSpacing(PdfFont.COLOR_FONDO_DOCUMENTO, PdfFont.COLOR_BORDE_ENCABEZADO_GRILLA, PdfFont.COLOR_FONDO_ENCABEZADO_GRILLA);
                case PdfStyles.CellType.CONTENIDO:
                case PdfStyles.CellType.COMENTARIO:
                    return new CellSpacing(PdfFont.COLOR_FONDO_DOCUMENTO, PdfFont.COLOR_BORDE_CELDA_CONTENIDOS, PdfFont.COLOR_FONDO_CONTENIDO);
                case PdfStyles.CellType.SUBTITLE:
                    return new CellSpacing(PdfFont.COLOR_FONDO_DOCUMENTO, PdfFont.COLOR_BORDE_SUBTITULO_SECCION, PdfFont.COLOR_FONDO_SUBTITULO_SECCION);
                case PdfStyles.CellType.GRID_FOTTER_COMMENT:
                case PdfStyles.CellType.GRID_FOTTER_COMMENT_TITLE:
                    return new CellSpacing(PdfFont.COLOR_FONDO_DOCUMENTO, PdfFont.COLOR_BORDE_SUBTITULO_SECCION, PdfFont.COLOR_FONDO_SUBTITULO_SECCION);
                case PdfStyles.CellType.TITLE_1:
                case PdfStyles.CellType.TITLE_COMMENT:
                case PdfStyles.CellType.SECTION_TITLE_IDX:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.COLOR_FONDO_TITULO_DOCUMENTO);
                case PdfStyles.CellType.SECTION_TITLE:
                case PdfStyles.CellType.SECTION_TITLE_COMMENT:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.COLOR_FONDO_TITULO_SECCION);
                case PdfStyles.CellType.MARGIN:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, BaseColor.WHITE);
                case PdfStyles.CellType.DOCUMENT_TITLE:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.COLOR_FONDO_TITULO_DOCUMENTO);
                case PdfStyles.CellType.POLICY_NUMBER:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.POLICY_NUMBER_BACKGROUND_COLOR);
                case PdfStyles.CellType.POLICY_NUMBER_CONTENT:
                    return new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.POLICY_NUMBER_CONTENT_BACKGROUND_COLOR);
            }

            return null;
        }

        public Font GetFont(PdfStyles.CellType cellType)
        {
            switch (cellType)
            {
                case PdfStyles.CellType.ENCABEZADO_GRILLA:
                case PdfStyles.CellType.MARGIN:
                case PdfStyles.CellType.CONTENIDO:
                case PdfStyles.CellType.ENCABEZADO_PREGUNTA:
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_ENCABEZADO_GRILLA);
                case PdfStyles.CellType.SUBTITLE:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_SUBTITLE);
                case PdfStyles.CellType.GRID_FOTTER_COMMENT:
                case PdfStyles.CellType.TITLE_COMMENT:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_COMENTARIO_PIE_GRILLA);
                case PdfStyles.CellType.COMENTARIO:
                case PdfStyles.CellType.SUBTITLE_COMMENT:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_CELDA_COMENTARIO);
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_COMENTARIO_ENCABEZADO_GRILLA);
                case PdfStyles.CellType.TITLE_1:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_TITULO);
                case PdfStyles.CellType.SECTION_TITLE:
                case PdfStyles.CellType.POLICY_NUMBER_CONTENT:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_TITULO_SECCION);
                case PdfStyles.CellType.SECTION_TITLE_IDX:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_TITULO_SECCION_IDX);
                case PdfStyles.CellType.GRID_FOTTER_COMMENT_TITLE:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_COMENTARIO_PIE_GRILLA_TITLE);
                case PdfStyles.CellType.SECTION_TITLE_COMMENT:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_TITULO_SECCION_COMENTARIO);
                case PdfStyles.CellType.DOCUMENT_TITLE:
                    return PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_TITULO);
                case PdfStyles.CellType.POLICY_NUMBER:
                    return PdfFont.GetFont(PdfFont.TipoFuente.POLICY_NUMBER_FONT);
                case PdfStyles.CellType.NON_SELECTED:
                    var font = PdfFont.GetFont(PdfFont.TipoFuente.FUENTE_ENCABEZADO_GRILLA);
                    font.SetStyle(Font.STRIKETHRU);
                    return font;

            }
            return null;
        }

        public PdfPCell ApplyStyle(PdfPCell cell, PdfStyles.CellType cellType)
        {
            cell.Border = PdfPCell.NO_BORDER;
            cell.CellEvent = GetCellStyleEvent(cellType);
            cell.Padding = 5;
            switch (cellType)
            {
                case PdfStyles.CellType.ENCABEZADO_GRILLA:
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA:
                case PdfStyles.CellType.MARGIN:
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    break;

                case PdfStyles.CellType.SUBTITLE:
                    cell.Padding = 0;
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    break;
                case PdfStyles.CellType.CONTENIDO:
                case PdfStyles.CellType.GRID_FOTTER_COMMENT:
                case PdfStyles.CellType.GRID_FOTTER_COMMENT_TITLE:
                case PdfStyles.CellType.ENCABEZADO_PREGUNTA:
                case PdfStyles.CellType.NON_SELECTED:
                case PdfStyles.CellType.COMENTARIO:
                case PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA:
                case PdfStyles.CellType.TITLE_1:
                case PdfStyles.CellType.SECTION_TITLE:
                case PdfStyles.CellType.SECTION_TITLE_IDX:
                case PdfStyles.CellType.TITLE_COMMENT:
                case PdfStyles.CellType.SECTION_TITLE_COMMENT:
                case PdfStyles.CellType.DOCUMENT_TITLE:
                case PdfStyles.CellType.POLICY_NUMBER:
                case PdfStyles.CellType.POLICY_NUMBER_CONTENT:
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    break;
                case PdfStyles.CellType.SUBTITLE_COMMENT:
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    //cell.VerticalAlignment = Element.ALIGN_BOTTOM;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    break;
            }
            cell.MinimumHeight = 18;
            return cell;

        }
    }

    public class CellSpacing : IPdfPCellEvent, IPdfPTableEvent
    {
        private BaseColor _tableBorderColor;
        private BaseColor _cellBorderColor;
        private BaseColor _cellBackgroundColor;
        private float _borderWidth;

        public CellSpacing(BaseColor tableBorderColor, BaseColor cellBorderColor, BaseColor cellBackgroundColor, float borderWidth = 2)
        {
            _tableBorderColor = tableBorderColor;
            _cellBorderColor = cellBorderColor;
            _cellBackgroundColor = cellBackgroundColor;
            _borderWidth = borderWidth;
        }

        public void TableLayout(PdfPTable table, float[][] width, float[] height, int headerRows, int rowStart, PdfContentByte[] canvas)
        {
            float[] widths = width[0];
            float x1 = widths[0];
            float x2 = widths[widths.Length - 1];
            float y1 = height[0];
            float y2 = height[height.Length - 1];
            PdfContentByte cb = canvas[PdfPTable.LINECANVAS];
            cb.Rectangle(x1, y1, x2 - x1, y2 - y1);
            cb.SetColorStroke(_tableBorderColor);
            cb.Stroke();
            cb.ResetRGBColorStroke();
        }

        public void CellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases)
        {
            float x1 = position.Left + _borderWidth;
            float x2 = position.Right - _borderWidth;
            float y1 = position.Top - _borderWidth;
            float y2 = position.Bottom + _borderWidth;
            PdfContentByte canvas = canvases[PdfPTable.LINECANVAS];
            canvas.SetLineWidth(0);
            canvas.Rectangle(x1, y1, x2 - x1, y2 - y1);
            canvas.SetColorStroke(_cellBorderColor);
            canvas.SetColorFill(_cellBackgroundColor);
            canvas.FillStroke();
        }
    }

    class MyCellField : IPdfPCellEvent
    {
        protected PdfFormField radiogroup;
        protected String value;
        public MyCellField(PdfFormField radiogroup, String value)
        {
            this.radiogroup = radiogroup;
            this.value = value;
        }
        public void CellLayout(PdfPCell cell, Rectangle rectangle, PdfContentByte[] canvases)
        {
            PdfWriter writer = canvases[0].PdfWriter;
            RadioCheckField radio = new RadioCheckField(writer, rectangle, null, value);

            radiogroup.AddKid(radio.RadioField);

        }
    }


    public class SectionGenerator
    {
        public IEnumerable<TipoDocumento> TiposDocumento { get; set; }
        public IEnumerable<TipoClaveTributaria> TiposClaveTributaria { get; set; }

        protected const int CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL = 2;
        protected const string SIN_DECLARAR_LABEL = "No Declara";

        private float _pageWidth;
        protected float PageWidth
        {
            get { return _pageWidth; }
        }

        protected PdfStyles _pdfStyler;
        protected List<PdfPTable> _tables;

        public SectionGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDocumento)
        {
            _pageWidth = pageWidth;
            _pdfStyler = new PdfStyles();
            TiposDocumento = tipoDocumento;
        }

        public SectionGenerator(float pageWidth)
        {
            _pageWidth = pageWidth;
            _pdfStyler = new PdfStyles();
        }

        protected bool IsTrue(bool? value)
        {
            return value.HasValue && value.Value;
        }

        public bool FueCargado<T>(T cuestionario)
        {
            foreach (var p in typeof(T).GetProperties().Where(c => c.PropertyType.IsGenericType && c.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>)))
            {
                if (p.GetValue(cuestionario, null) != null)
                {
                    return true;
                }
            }
            return false;
        }


        protected PdfPTable GenerateDocumentoTitle(string str1, string str2)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell(str1, PdfStyles.CellType.DOCUMENT_TITLE));
            table.AddCell(GenerateCell(str2, PdfStyles.CellType.DOCUMENT_TITLE));
            return table;
        }


        protected PdfPTable GenerateTable(float width, float[] colWidths)
        {
            PdfPTable table = new PdfPTable(colWidths);

            table.TotalWidth = width;
            table.WidthPercentage = 100f;
            table.DefaultCell.Border = PdfPCell.NO_BORDER;
            table.DefaultCell.CellEvent = new CellSpacing(BaseColor.WHITE, BaseColor.WHITE, PdfFont.COLOR_FONDO_TITULO_DOCUMENTO);

            return table;
        }

        protected PdfPTable GenerateSubtitle(string text)
        {
            var table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(text, PdfStyles.CellType.SUBTITLE));
            return table;
        }

        protected PdfPTable GenerateSubtitle(string subtitle, string comment)
        {
            var table = GenerateTable(PageWidth, new float[] { 100 });
            var cell = GenerateCell(string.Empty, PdfStyles.CellType.SUBTITLE);
            var phrase = new Phrase();
            phrase.Add(new Chunk(subtitle, _pdfStyler.GetFont(PdfStyles.CellType.SUBTITLE)));
            phrase.Add(new Chunk(comment, _pdfStyler.GetFont(PdfStyles.CellType.SUBTITLE_COMMENT)));
            cell.AddElement(phrase);
            table.AddCell(cell);
            return table;
        }

        protected PdfPTable GenerateSectionTitle(string sectionName, string sectionTitle)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell(sectionName, PdfStyles.CellType.SECTION_TITLE_IDX));
            table.AddCell(GenerateCell(sectionTitle, PdfStyles.CellType.SECTION_TITLE));
            foreach (var c in table.Rows.First().GetCells())
                c.MinimumHeight = 0;
            return table;
        }

        protected PdfPTable GenerateSectionTitle(string sectionName, string title, string leyend, string number)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 75, 10f, 10 });
            table.AddCell(GenerateCell(sectionName, PdfStyles.CellType.SECTION_TITLE_IDX));
            table.AddCell(GenerateCell(title, PdfStyles.CellType.SECTION_TITLE));
            table.AddCell(GenerateCell(leyend, PdfStyles.CellType.POLICY_NUMBER));
            table.AddCell(GenerateCell(number, PdfStyles.CellType.POLICY_NUMBER_CONTENT));

            return table;
        }


        //protected PdfPTable GenerateSectionTitleNroSolicitud(string sectionName, string sectionTitle, string numeroSolicitud)
        //{
        //    var table = GenerateTable(PageWidth, new float[] { 5, 85, 10 });
        //    table.AddCell(GenerateCell(sectionName, PdfStyles.CellType.SECTION_TITLE_IDX));
        //    table.AddCell(GenerateCell(sectionTitle, PdfStyles.CellType.SECTION_TITLE));
        //    var cell = GenerateCell(numeroSolicitud, PdfStyles.CellType.SECTION_TITLE);
        //    cell.HorizontalAlignment = Element.ALIGN_CENTER;
        //    table.AddCell(cell);

        //    foreach (var c in table.Rows.First().GetCells())
        //        c.MinimumHeight = 0;

        //    return table;
        //}

        protected PdfPTable GenerateSectionTitleComment(string sectionName, string sectionTitle, string comment)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell(sectionName, PdfStyles.CellType.SECTION_TITLE_IDX));

            var cell = GenerateCell(string.Empty, PdfStyles.CellType.SECTION_TITLE);
            var phrase = new Phrase();
            phrase.Add(new Chunk(sectionTitle, _pdfStyler.GetFont(PdfStyles.CellType.SECTION_TITLE)));
            phrase.Add(new Chunk(comment, _pdfStyler.GetFont(PdfStyles.CellType.SECTION_TITLE_COMMENT)));
            cell.AddElement(phrase);
            cell.MinimumHeight = 0;
            cell.PaddingTop = 0;
            table.AddCell(cell);

            foreach (var c in table.Rows.First().GetCells())
                c.MinimumHeight = 0;

            return table;
        }

        protected PdfPTable GenerateSectionTitle(string sectionName, string sectionTitle, string comment)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell(sectionName, PdfStyles.CellType.TITLE_1));

            var cell = GenerateCell(string.Empty, PdfStyles.CellType.SECTION_TITLE);
            var phrase = new Phrase();
            phrase.Add(new Chunk(sectionTitle, _pdfStyler.GetFont(PdfStyles.CellType.SECTION_TITLE)));
            phrase.Add(new Chunk(comment, _pdfStyler.GetFont(PdfStyles.CellType.SECTION_TITLE_COMMENT)));
            cell.AddElement(phrase);
            table.AddCell(cell);
            return table;
        }

        protected PdfPTable GenerateQuestionnaireTitle(string title, string policyTitle, string policyNumber)
        {
            var table = GenerateTable(PageWidth, new float[] { 80, 10, 10 });
            table.AddCell(GenerateCell(title, PdfStyles.CellType.DOCUMENT_TITLE));
            table.AddCell(GenerateCell(policyTitle, PdfStyles.CellType.POLICY_NUMBER));
            table.AddCell(GenerateCell(policyNumber, PdfStyles.CellType.POLICY_NUMBER_CONTENT));

            return table;
        }

        protected PdfPCell GenerateCell(string text, PdfStyles.CellType type, int colspan = 1, int rowspan = 1)
        {
            var cell = new PdfPCell(new iTextSharp.text.Phrase(text, _pdfStyler.GetFont(type)));
            cell.Colspan = colspan;
            cell.Rowspan = rowspan;
            cell.PaddingBottom = -3;
            //cell.FixedHeight = 18;
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateIDCell(int? idNumber, string typeId, PdfStyles.CellType type, int colspan = 1, int rowspan = 1)
        {
            var list = new List<TipoDocumento>()
            {
                new TipoDocumento()
                {
                    id="2",
                    name = "DNI"
                },
                new TipoDocumento()
                {
                    id="4",
                    name = "LE"
                },
                new TipoDocumento()
                {
                    id="3",
                    name = "LC"
                },
                new TipoDocumento()
                {
                    id = "1",
                    name = "CI Mercosur"
                },
            };
            var tipoDocumento = list.Where(l => l.id == typeId).FirstOrDefault();
            var text = "";
            if (tipoDocumento != null)
            {
                text = string.Format("{0}: {1}", tipoDocumento.name, idNumber.HasValue ? idNumber.Value.ToString("D") : string.Empty);
            }
            else
            {
                text = string.Format("{0}", idNumber.HasValue ? idNumber.Value.ToString("D") : string.Empty);
            }

            return GenerateCell(text, type, colspan, rowspan);
        }

        protected PdfPCell GenerateClaveTributariaCell(string claveTributaria, string typeId, PdfStyles.CellType type, int colspan = 1, int rowspan = 1)
        {
            var tipoClave = GetClaveTributariaType(typeId);
            var claveFormateada = InfoFormatterHelper.Format(claveTributaria, InfoFormatterHelper.FormatType.CLAVE_TRIBUTARIA);
            var text = "";
            if (!string.IsNullOrEmpty(tipoClave))
            {
                text = string.Format("{0}: {1}", tipoClave, claveFormateada);
            }
            else
            {
                text = string.Format("{0}", claveFormateada);
            }

            return GenerateCell(text, type, colspan, rowspan);
        }

        protected PdfPCell WithMinHeght(float height, PdfPCell cell)
        {
            cell.MinimumHeight = height;
            return cell;
        }

        protected PdfPCell With(Action<PdfPCell> act, PdfPCell cell)
        {
            act(cell);
            return cell;
        }

        /// <summary>
        /// Agrega el texto en multiples lineas y corta cuando pudo insertar todo el texto
        /// </summary>
        /// <param name="text"></param>
        /// <param name="type"></param>
        /// <param name="percent"></param>
        /// <param name="percentOnlyFirstLine"></param>
        /// <param name="lineCount"></param>
        /// <param name="colspan"></param>
        /// <param name="rowspan"></param>
        /// <returns></returns>
        protected IList<PdfPCell> GenerateCellMultilineAndStops(string text, PdfStyles.CellType type, float percent = 100, bool percentOnlyFirstLine = false, int lineCount = 1, int colspan = 1, int rowspan = 1)
        {
            var text2 = text ?? string.Empty;
            var cells = new List<PdfPCell>();
            var font = _pdfStyler.GetFont(type);

            var fullWith = PageWidth * (percent / 100);//Porcentaje de la linea que ocupa la primera linea

            var cell = GenerateCell(text2, type, colspan, rowspan);//Celda dummy para medir el ancho total
            var usableWidth = fullWith - (cell.PaddingLeft + cell.PaddingRight);

            var textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(text2, font.Size);
            if (textWidth > usableWidth)
            {
                int count = 1;

                var seps = new char[1];
                seps[0] = ' ';
                var line = "";
                foreach (var word in text2.Split(seps))
                {
                    //Si el ancho definido afecta solo a la primer linea => recalculo usando el anocho total de la pagina
                    if (count > 1 && percentOnlyFirstLine)
                    {
                        usableWidth = PageWidth - (cell.PaddingLeft + cell.PaddingRight);
                    }
                    textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(line + " " + word, font.Size);
                    if (textWidth > usableWidth)
                    {
                        var c = GenerateCell(line, type, colspan, rowspan);
                        cells.Add(c);
                        line = " " + word;
                    }
                    else if (textWidth == usableWidth)
                    {
                        line = " " + word;
                        var c = GenerateCell(line, type, colspan, rowspan);
                        cells.Add(c);
                        line = "";
                    }
                    else
                    {
                        line += " " + word;
                    }
                    count++;
                }

                if (!string.IsNullOrEmpty(line))
                {
                    var c = GenerateCell(line, type, colspan, rowspan);
                    cells.Add(c);
                }
            }
            else
            {
                cells.Add(GenerateCell(text2, type, colspan, rowspan));
            }

            //Que pasa si no me da el espacio?

            return cells;
        }

        protected IEnumerable<PdfPCell> GenerateCellMultilineFirst(string text, PdfStyles.CellType type, float percent = 100, float percentFirstLine = 100, int colspan = 1, int colspanFirstLine = 1, int lineCount = 1, int rowspan = 1)
        {
            var cells = new List<PdfPCell>();
            var font = _pdfStyler.GetFont(type);

            var fullWith = PageWidth * (percentFirstLine / 100);//Porcentaje de la linea que ocupa la primera linea

            var cell = GenerateCell(text, type, colspan, rowspan);//Celda dummy para medir el ancho total
            var usableWidth = fullWith - (cell.PaddingLeft + cell.PaddingRight);
            int count = 1;
            var colspanCell = colspanFirstLine;
            var textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(text, font.Size);
            if (textWidth > usableWidth)
            {
                var seps = new char[1];
                seps[0] = ' ';
                var line = "";
                foreach (var word in text.Split(seps))
                {
                    //recalculo usando el anocho total de la pagina
                    if (count > 1)
                    {
                        usableWidth = (PageWidth * (percent / 100)) - (cell.PaddingLeft + cell.PaddingRight);
                        colspanCell = colspan;
                    }
                    textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(line + " " + word, font.Size);
                    if (textWidth > usableWidth)
                    {
                        cells.Add(GenerateCell(line, type, colspanCell, rowspan));
                        line = " " + word;
                        count++;
                    }
                    else if (textWidth == usableWidth)
                    {
                        line = " " + word;
                        cells.Add(GenerateCell(line, type, colspanCell, rowspan));
                        line = "";
                        count++;
                    }
                    else
                    {
                        line += " " + word;
                    }
                }

                if (!string.IsNullOrEmpty(line))
                {
                    if (count > 0)
                    {
                        colspanCell = colspan;
                    }
                    cells.Add(GenerateCell(line, type, colspanCell, rowspan));
                    count++;
                }
            }
            else
            {
                if (count > 0)
                {
                    colspanCell = colspan;
                }
                cells.Add(GenerateCell(text, type, colspanCell, rowspan));
            }

            //Agrego filas vacias hasta completar la cantidad necesaria
            for (int i = lineCount - cells.Count; i > 0; i--)
            {
                if (count > 0)
                {
                    colspanCell = colspan;
                }
                cells.Add(GenerateCell(" ", type, colspanCell, rowspan));
                count++;
            }

            //Que pasa si no me da el espacio?

            return cells;
        }

        protected IEnumerable<PdfPCell> GenerateCellMultiline(string text, PdfStyles.CellType type, float percent = 100, bool percentOnlyFirstLine = false, int lineCount = 1, int colspan = 1, int rowspan = 1)
        {
            var cells = new List<PdfPCell>();
            var font = _pdfStyler.GetFont(type);

            var fullWith = PageWidth * (percent / 100);//Porcentaje de la linea que ocupa la primera linea

            var cell = GenerateCell(text, type, colspan, rowspan);//Celda dummy para medir el ancho total
            var usableWidth = fullWith - (cell.PaddingLeft + cell.PaddingRight);

            var textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(text, font.Size);
            if (textWidth > usableWidth)
            {
                int count = 1;

                var seps = new char[1];
                seps[0] = ' ';
                var line = "";
                foreach (var word in text.Split(seps))
                {
                    //Si el ancho definido afecta solo a la primer linea => recalculo usando el anocho total de la pagina
                    if (count > 1 && percentOnlyFirstLine)
                    {
                        usableWidth = PageWidth - (cell.PaddingLeft + cell.PaddingRight);
                    }
                    textWidth = font.GetCalculatedBaseFont(true).GetWidthPoint(line + " " + word, font.Size);
                    if (textWidth > usableWidth)
                    {
                        cells.Add(GenerateCell(line, type, colspan, rowspan));
                        line = " " + word;
                    }
                    else if (textWidth == usableWidth)
                    {
                        line = " " + word;
                        cells.Add(GenerateCell(line, type, colspan, rowspan));
                        line = "";
                    }
                    else
                    {
                        line += " " + word;
                    }
                    count++;
                }

                if (!string.IsNullOrEmpty(line))
                {
                    cells.Add(GenerateCell(line, type, colspan, rowspan));
                }
            }
            else
            {
                cells.Add(GenerateCell(text, type, colspan, rowspan));
            }

            //Agrego filas vacias hasta completar la cantidad necesaria
            for (int i = lineCount - cells.Count; i > 0; i--)
            {
                cells.Add(GenerateCell(" ", type, colspan, rowspan));
            }

            //Que pasa si no me da el espacio?

            return cells;
        }

        private const int CANTIDAD_MAXIMA_FOTOS_POR_LINEA = 4;

        public PdfPTable GenerateImageTable(IEnumerable<FotoDocumento> fotos, bool selected = false, int colspan = 1, int rowspan = 1)
        {
            var table = GenerateTable(PageWidth, new float[] { 25, 25, 25, 25 });
            if (fotos != null && fotos.Count() > 0)
            {
                var imagenes = fotos.Select(f => DecodeImage(f.Foto));
                var minHeight = imagenes.Min(i => i.Height);
                var minWidth = imagenes.Min(i => i.Width);
                
                try
                {
                    foreach (var imagen in imagenes)
                    {
                        var cell = new PdfPCell();
                        cell.AddElement(imagen);
                        cell.Colspan = colspan;
                        cell.Rowspan = rowspan;
                        _pdfStyler.ApplyStyle(cell, PdfStyles.CellType.MARGIN);
                        table.AddCell(cell);
                    }
                    var cantidadImagenes = imagenes.Count();
                    if (cantidadImagenes % CANTIDAD_MAXIMA_FOTOS_POR_LINEA != 0)
                    {
                        table.AddCell(GenerateCell("", PdfStyles.CellType.MARGIN, colspan: CANTIDAD_MAXIMA_FOTOS_POR_LINEA - (cantidadImagenes % CANTIDAD_MAXIMA_FOTOS_POR_LINEA)));
                    }
                }
                catch (Exception)
                {

                }
            }
            return table;
        }

        public PdfPCell GenerateImageCell(string text, PdfStyles.CellType type, bool selected = false, int colspan = 1, int rowspan = 1)
        {
            Paragraph p = new Paragraph("", _pdfStyler.GetFont(type));
            if (selected)
            {
                Image squareCheck = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/square-check.png");
                squareCheck.ScaleAbsolute(6, 6);
                squareCheck.ScaleToFitHeight = false;
                p.Add(new Chunk(Image.GetInstance(squareCheck), 0, 0));
            }
            else
            {
                Image squareCheck = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/square-not-check.png");
                squareCheck.ScaleAbsolute(6, 6);
                squareCheck.ScaleToFitHeight = false;
                p.Add(new Chunk(Image.GetInstance(squareCheck), 0, 0));
            }

            p.Add(new Chunk(" " + text, _pdfStyler.GetFont(type)));

            var cell = new PdfPCell(p);
            cell.Colspan = colspan;
            cell.Rowspan = rowspan;
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GetDocumentType(string typeId)
        {
            var list = new List<TipoDocumento>()
            {
                new TipoDocumento()
                {
                    id="2",
                    name = "DNI"
                },
                new TipoDocumento()
               {
                    id="4",
                    name = "LE"
                },
                new TipoDocumento()
                {
                    id="3",
                    name = "LC"
                },
                new TipoDocumento()
                {
                    id = "1",
                    name = "CI Mercosur"
                },
            };
            var cell = new PdfPCell();
            int i = 0;
            Paragraph p = new Paragraph("", _pdfStyler.GetFont(PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            foreach (var type in list)
            {
                PdfStyles.CellType cellType = PdfStyles.CellType.NON_SELECTED;
                if (type.id == typeId)
                {
                    cellType = PdfStyles.CellType.CONTENIDO;
                }
                Chunk c = new Chunk(type.name + ((list.Count() == i) ? "" : "/"), _pdfStyler.GetFont(cellType));
                p.Add(c);

            }
            cell.AddElement(p);
            cell.Colspan = 2;
            _pdfStyler.ApplyStyle(cell, PdfStyles.CellType.ENCABEZADO_PREGUNTA);
            return cell;
        }

        protected string GetClaveTributariaType(string id)
        {
            switch (id)
            {
                case "1":
                    return "CDI";
                case "2":
                    return "CUIL";
                case "3":
                    return "CUIT";
                default:
                    return "";
            }
        }

        protected string GetDocumentValue(string tipeId, int? number)
        {
            if (!number.HasValue)
                return string.Empty;

            var documentoType = TiposDocumento.Where(t => t.id == tipeId).FirstOrDefault();

            if (string.IsNullOrEmpty(tipeId) || documentoType == null)
                return InfoFormatterHelper.Format(tipeId);

            return string.Format("{0} {1}", documentoType.name, InfoFormatterHelper.Format(number));
        }

        protected PdfPCell GenerateListCell<T>(IEnumerable<T> options, PdfStyles.CellType type, string selectedId, int colspan = 1, int rowspan = 1, bool differentRows = false)
        {
            Image _selectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/selected-list-item.png");
            _selectListItemImage.ScaleAbsolute(6, 6);
            _selectListItemImage.ScaleToFitHeight = false;

            Image _nonSelectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/non-selected-list-item.png");
            _nonSelectListItemImage.ScaleAbsolute(6, 6);
            _nonSelectListItemImage.ScaleToFitHeight = false;

            Paragraph p = new Paragraph("", _pdfStyler.GetFont(type));
            foreach (var option in options)
            {
                p.Add("  ");

                try
                {
                    var optionId = option.GetType().GetProperty("id").GetValue(option).ToString();
                    var optionName = option.GetType().GetProperty("name").GetValue(option);

                    if (!string.IsNullOrEmpty(selectedId) && selectedId == optionId)
                    {
                        p.Add(new Chunk(Image.GetInstance(_selectListItemImage), 0, 0));
                    }
                    else
                    {
                        p.Add(new Chunk(Image.GetInstance(_nonSelectListItemImage), 0, 0));
                    }
                    if (differentRows)
                    {
                        p.Add(new Chunk(string.Format(" {0}\n", optionName), _pdfStyler.GetFont(type)));
                    }
                    else
                    {
                        p.Add(new Chunk(string.Format(" {0}", optionName), _pdfStyler.GetFont(type)));
                    }

                }
                catch (AmbiguousMatchException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
                catch (ArgumentNullException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
            }
            var cell = new PdfPCell(p);
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateListCell<T>(IEnumerable<T> options, PdfStyles.CellType type, IEnumerable<string> selectedIds, int colspan = 1, int rowspan = 1, bool differentRows = false)
        {
            Image _selectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/selected-list-item.png");
            _selectListItemImage.ScaleAbsolute(6, 6);
            _selectListItemImage.ScaleToFitHeight = false;

            Image _nonSelectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/non-selected-list-item.png");
            _nonSelectListItemImage.ScaleAbsolute(6, 6);
            _nonSelectListItemImage.ScaleToFitHeight = false;

            Paragraph p = new Paragraph("", _pdfStyler.GetFont(type));
            foreach (var option in options)
            {
                p.Add("  ");

                try
                {
                    var optionId = option.GetType().GetProperty("id").GetValue(option).ToString();
                    var optionName = option.GetType().GetProperty("name").GetValue(option);

                    if (selectedIds.Contains(optionId))
                    {
                        p.Add(new Chunk(Image.GetInstance(_selectListItemImage), 0, 0));
                    }
                    else
                    {
                        p.Add(new Chunk(Image.GetInstance(_nonSelectListItemImage), 0, 0));
                    }
                    if (differentRows)
                    {
                        p.Add(new Chunk(string.Format(" {0}\n", optionName), _pdfStyler.GetFont(type)));
                    }
                    else
                    {
                        p.Add(new Chunk(string.Format(" {0}", optionName), _pdfStyler.GetFont(type)));
                    }

                }
                catch (AmbiguousMatchException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
                catch (ArgumentNullException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
            }
            var cell = new PdfPCell(p);
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateListMonedas(PdfStyles.CellType type, string selectedId, int colspan = 1, int rowspan = 1, bool differentRows = false)
        {
            List<string> list = new List<string>();
            list.Add(Resource.DOLARES);
            list.Add(Resource.PESOS);

            var posSelected = -1;
            if (selectedId == "2")
                posSelected = 0;
            if (selectedId == "1")
                posSelected = 1;

            return GenerateListCell(list, type, posSelected: posSelected, colspan: colspan, rowspan: rowspan, differentRows: differentRows);
        }

        protected PdfPCell GenerateListCell(IList<string> options, PdfStyles.CellType type, IEnumerable<int> posSelected, int colspan = 1, int rowspan = 1, bool differentRows = false)
        {
            Image _selectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/selected-list-item.png");
            _selectListItemImage.ScaleAbsolute(6, 6);
            _selectListItemImage.ScaleToFitHeight = false;

            Image _nonSelectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/non-selected-list-item.png");
            _nonSelectListItemImage.ScaleAbsolute(6, 6);
            _nonSelectListItemImage.ScaleToFitHeight = false;

            Paragraph p = new Paragraph("", _pdfStyler.GetFont(type));
            for (int i = 0; i < options.Count; i++)
            {
                p.Add("  ");
                var option = options[i];
                if (posSelected.Contains(i))
                {
                    p.Add(new Chunk(Image.GetInstance(_selectListItemImage), 0, 0));
                }
                else
                {
                    p.Add(new Chunk(Image.GetInstance(_nonSelectListItemImage), 0, 0));
                }
                if (differentRows)
                {
                    p.Add(new Chunk(string.Format(" {0}\n", option), _pdfStyler.GetFont(type)));
                }
                else
                {
                    p.Add(new Chunk(string.Format(" {0}", option), _pdfStyler.GetFont(type)));
                }
            }
            var cell = new PdfPCell(p);
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateListCell(IList<string> options, PdfStyles.CellType type, int colspan = 1, int rowspan = 1, int posSelected = -1, bool differentRows = false)
        {
            Image _selectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/selected-list-item.png");
            _selectListItemImage.ScaleAbsolute(6, 6);
            _selectListItemImage.ScaleToFitHeight = false;

            Image _nonSelectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/non-selected-list-item.png");
            _nonSelectListItemImage.ScaleAbsolute(6, 6);
            _nonSelectListItemImage.ScaleToFitHeight = false;

            Paragraph p = new Paragraph("", _pdfStyler.GetFont(type));
            for (int i = 0; i < options.Count; i++)
            {
                p.Add("  ");
                var option = options[i];
                if (posSelected == i)
                {
                    p.Add(new Chunk(Image.GetInstance(_selectListItemImage), 0, 0));
                }
                else
                {
                    p.Add(new Chunk(Image.GetInstance(_nonSelectListItemImage), 0, 0));
                }
                if (differentRows)
                {
                    p.Add(new Chunk(string.Format(" {0}\n", option), _pdfStyler.GetFont(type)));
                }
                else
                {
                    p.Add(new Chunk(string.Format(" {0}", option), _pdfStyler.GetFont(type)));
                }

            }
            var cell = new PdfPCell(p);
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateListCellWithSpace(IList<string> options, PdfStyles.CellType type, string space, int colspan = 1, int rowspan = 1, int posSelected = -1, bool differentRows = false)
        {
            Image _selectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/selected-list-item.png");
            _selectListItemImage.ScaleAbsolute(6, 6);
            _selectListItemImage.ScaleToFitHeight = false;

            Image _nonSelectListItemImage = Image.GetInstance(AppDomain.CurrentDomain.BaseDirectory + "/images/non-selected-list-item.png");
            _nonSelectListItemImage.ScaleAbsolute(6, 6);
            _nonSelectListItemImage.ScaleToFitHeight = false;

            Paragraph p = new Paragraph(space, _pdfStyler.GetFont(type));
            for (int i = 0; i < options.Count; i++)
            {
                p.Add("  ");
                var option = options[i];
                if (posSelected == i)
                {
                    p.Add(new Chunk(Image.GetInstance(_selectListItemImage), 0, 0));
                }
                else
                {
                    p.Add(new Chunk(Image.GetInstance(_nonSelectListItemImage), 0, 0));
                }
                if (differentRows)
                {
                    p.Add(new Chunk(string.Format(" {0}\n", option), _pdfStyler.GetFont(type)));
                }
                else
                {
                    p.Add(new Chunk(string.Format(" {0}", option), _pdfStyler.GetFont(type)));
                }

            }
            var cell = new PdfPCell(p);
            _pdfStyler.ApplyStyle(cell, type);
            return cell;
        }

        protected PdfPCell GenerateCell(IEnumerable<string> values, PdfStyles.CellType type, int colspan = 1, int rowspan = 1)
        {
            var text = "";
            foreach (var value in values)
            {
                text += (value + "; ");
            }
            return GenerateCell(text, type, colspan, rowspan);
        }

        protected IEnumerable<T> Deserialize<T>(string jsonList)
        {
            var result = new List<T>();
            if (string.IsNullOrEmpty(jsonList))
                return result;
            try
            {
                foreach (var obj in JsonConvert.DeserializeObject<List<T>>(jsonList) ?? new List<T>())
                {
                    result.Add(obj);
                }

            }
            catch (Exception)
            {

            }


            return result;
        }

        protected PdfPCell GenerateMultiselectCell<T>(IEnumerable<T> list, string jsonValues, PdfStyles.CellType type, int colspan = 1, int rowspan = 1, int skip = 0, int take = -1 )
        {
            var text = "";
            if (!string.IsNullOrEmpty(jsonValues))
            {
                try
                {
                    var data = Deserialize<T>(jsonValues);
                    if (data != null)
                    {
                        data = data.Skip(skip);
                        if(take > 0)
                        {
                            data = data.Take(take);
                        }
                        foreach (var option in data)
                        {
                            var optionName = option.GetType().GetProperty("name").GetValue(option);
                            text += (!string.IsNullOrEmpty(text) ? ", " : string.Empty) + optionName;
                        }
                    }
                }
                catch (AmbiguousMatchException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
                catch (ArgumentNullException ex)
                {
                    throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                }
            }
            return GenerateCell(text, type, colspan, rowspan);
        }
        
        protected PdfPCell GenerateCell<T>(IEnumerable<T> options, PdfStyles.CellType type, string selectedId, int colspan = 1, int rowspan = 1)
        {
            var text = "";
            if (!string.IsNullOrEmpty(selectedId))
            {
                foreach (var option in options)
                {
                    try
                    {
                        var optionId = option.GetType().GetProperty("id").GetValue(option).ToString();
                        var optionName = option.GetType().GetProperty("name").GetValue(option).ToString();
                        if (optionId == selectedId)
                        {
                            text = optionName;
                        }
                    }
                    catch (AmbiguousMatchException ex)
                    {
                        throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                    }
                    catch (ArgumentNullException ex)
                    {
                        throw new Exception("Los objetos no contienen una de las propiedades requeridas", ex);
                    }
                }
            }
            return GenerateCell(text, type, colspan, rowspan);
        }

        protected PdfPCell GenerateBooleanListCell(PdfStyles.CellType type, bool? isTrue, int colspan = 1, int rowspan = 1, int posSelected = -1, bool differentRows = false)
        {
            var options = new List<string>() { InfoFormatterHelper.YES_LABEL, InfoFormatterHelper.NO_LABEL };
            if (isTrue.HasValue)
            {
                if (isTrue.Value)
                {
                    return GenerateListCell(options, type, colspan, rowspan, 0, differentRows);
                }
                else
                {
                    return GenerateListCell(options, type, colspan, rowspan, 1, differentRows);
                }
            }
            else
            {
                return GenerateListCell(options, type, colspan, rowspan, differentRows: differentRows);
            }
        }

        protected PdfPCell GenerateBooleanListCellWithSpaces(PdfStyles.CellType type, bool? isTrue, string space, int colspan = 1, int rowspan = 1, int posSelected = -1, bool differentRows = false)
        {
            var options = new List<string>() { InfoFormatterHelper.YES_LABEL, InfoFormatterHelper.NO_LABEL };
            if (isTrue.HasValue)
            {
                if (isTrue.Value)
                {
                    return GenerateListCellWithSpace(options, type, space, colspan, rowspan, 0, differentRows);
                }
                else
                {
                    return GenerateListCellWithSpace(options, type, space, colspan, rowspan, 1, differentRows);
                }
            }
            else
            {
                return GenerateListCellWithSpace(options, type, space, colspan, rowspan, differentRows: differentRows);
            }
        }

        protected int? CalculateAge(DateTime? birthdate)
        {
            var diaCero = new DateTime(1, 1, 1);
            if (birthdate.HasValue)
            {
                return (diaCero + DateTime.Now.Subtract(birthdate.Value)).Year - 1;
            }
            return null;
        }

        protected void AddAddress(string label, IQueryable<Domicilio> addressQuery, string addressId, IEnumerable<Provincia> provincias, IList<PdfPTable> tables)
        {
            var address = addressQuery.Where(d => d.id == addressId).FirstOrDefault() ?? new Domicilio();

            var table = GenerateTable(PageWidth, new float[] { 97.22f, 446.84f });
            table.AddCell(GenerateCell(label, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.Direccion, PdfStyles.CellType.CONTENIDO));
            tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 23.76f, 73.46f, 50.28f, 168.0f, 49.0f, 179f });
            table.AddCell(GenerateCell(Resource.CP, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.CP, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.LOCALIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.Localidad, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.PROVINCIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<Provincia>(provincias, PdfStyles.CellType.CONTENIDO, address.Provincia));
            tables.Add(table);
        }

        protected void AddAddress(string label, IQueryable<Domicilio> addressQuery, string addressId, IEnumerable<Provincia> provincias)
        {
            var address = addressQuery.Where(d => d.id == addressId).FirstOrDefault() ?? new Domicilio();

            var table = GenerateTable(PageWidth, new float[] { 97.22f, 446.84f });
            table.AddCell(GenerateCell(label, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.Direccion, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 23.76f, 73.46f, 50.28f, 168.0f, 49.0f, 179f });
            table.AddCell(GenerateCell(Resource.CP, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.CP, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.LOCALIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(address.Localidad, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.PROVINCIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<Provincia>(provincias, PdfStyles.CellType.CONTENIDO, address.Provincia));
            _tables.Add(table);
        }

        protected void AddAddress(string label, Domicilio address, IEnumerable<Provincia> provincias)
        {
            var table = GenerateTable(PageWidth, new float[] { 20, 80 });
            table.AddCell(GenerateCell(label, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(address.Direccion, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 5, 15, 10, 30, 10, 30 });
            table.AddCell(GenerateCell(Resource.CP, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(address.CP, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.LOCALIDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(address.Localidad, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.PROVINCIA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Provincia>(provincias, PdfStyles.CellType.CONTENIDO, address.Provincia));
            _tables.Add(table);
        }


        protected void AddConyDat(DatosPA datosPa)
        {
            var tipoDocumento = TiposDocumento.Where(t => t.id == datosPa.id).FirstOrDefault() ?? new TipoDocumento();

            var table = GenerateTable(PageWidth, new float[] { 70, 301, 69, 109 });
            table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_CONYUGE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(datosPa.NombresCony, datosPa.ApellidosCony), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NroDocCony, datosPa.TipoDocCony, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);
        }

        protected void AddBasicData(DatosPA datosPa)
        {
            var table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 69.48f, 133.71f, 265 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NumeroDocumento, datosPa.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_PROFESION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Profesion, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);
        }

        protected Image DecodeImage(byte[] imageByte)
        {
            return Image.GetInstance(imageByte);
        }

        protected string GetNacionalidades(string jsonString)
        {
            var nacionalidades = "";
            if (!string.IsNullOrEmpty(jsonString))
            {
                try
                {
                    foreach (var nacionalidad in JsonConvert.DeserializeObject<List<Nacionalidad>>(jsonString) ?? new List<Nacionalidad>())
                    {
                        nacionalidades += (!string.IsNullOrEmpty(nacionalidades) ? ", " : string.Empty) + nacionalidad.name;
                    }
                }
                catch (Newtonsoft.Json.JsonSerializationException)
                {

                }
            }
            return nacionalidades;
        }


        protected void AddDatosAdicionales(DatosPA datosPa, IEnumerable<Finalidad> tipoFinalidad, IEnumerable<Nacionalidad> nacionalidades)
        {
            var table = GenerateTable(PageWidth, new float[] { 142, 26, 42, 129, 210 });
            table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.Extranjero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            if (IsTrue(datosPa.Extranjero))
            {
                table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, datosPa.Pais, PdfStyles.CellType.CONTENIDO, take: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
            }
            else
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_COMENTARIO_CIUDADANIA, PdfStyles.CellType.COMENTARIO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 163, 188, 89, 109 });
            table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_FINALIDAD_PARA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Finalidad>(tipoFinalidad, PdfStyles.CellType.CONTENIDO, datosPa.Finalidad, colspan: 3));
            _tables.Add(table);

            AddConyDat(datosPa);
        }

        protected void AddGridHeaders(IEnumerable<string> headerLabels, float[] widths)
        {
            var table = GenerateTable(PageWidth, widths);
            foreach (var headerLabel in headerLabels)
            {
                table.AddCell(GenerateCell(headerLabel, PdfStyles.CellType.ENCABEZADO_GRILLA));
            }
            _tables.Add(table);
        }
    }

    public class Section0Generator : SectionGenerator
    {
        public Section0Generator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(string nroSolicitud, Caratula caratula, DatosPA datosPa, IEnumerable<InformacionLP> informacionesLp, ModalidadPago modalidadPago, IEnumerable<Designacion> designaciones, IEnumerable<TipoCargo> tipoCargo
            , IEnumerable<HorariosContacto> horariosContacto, IEnumerable<TipoTelefonoFijo> tiposTelefono, IEnumerable<Horario> horarios, IEnumerable<DiaSemana> dias,
            IEnumerable<TipoTarjetaCredito> tipoTarjetaCredito, IEnumerable<TipoMoneda> tiposMoneda)
        {
            _tables = new List<PdfPTable>();

            var table = GenerateSectionTitle("", Resource.SECCION0_TITULO, Resource.SECCION_NRO, nroSolicitud);
            table.SpacingAfter = 24f;
            _tables.Add(table);
            GenerateInfoPa(datosPa);
            GenerateInfoLp(informacionesLp, designaciones, tipoCargo);
            GenerateInfoSuplPa(caratula);
            GenerateInfoSuplSolicitud(caratula, modalidadPago, tipoTarjetaCredito, tiposMoneda);
            GenerateEntrevistaTelesuscripcion(caratula, horariosContacto, tiposTelefono, horarios, dias);

            return _tables;
        }

        private void GenerateInfoPa(DatosPA datosPa)
        {
            //Popuesto asegurado
            var table = GenerateSubtitle(Resource.SECCION0_PA_TITULO);
            _tables.Add(table);
            _tables.Last().SpacingAfter = -5f;


            /////////
            table = GenerateTable(PageWidth, new float[] { 8.5F, 35.5F, 9.5F, 46.5F });
            table.AddCell(GenerateCell(Resource.SECCION0_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCION0_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            table.SpacingAfter = 16f;
            _tables.Add(table);
        }

        private void GenerateInfoLp(IEnumerable<InformacionLP> informacionesLp, IEnumerable<Designacion> designaciones, IEnumerable<TipoCargo> tipoCargo)
        {
            ////////
            _tables.Add(GenerateSubtitle(Resource.SECCION0_LP_TITULO));
            _tables.Last().SpacingAfter = -5f;
            ///////
            var table = GenerateTable(PageWidth, new float[] { 9.5F, 10.3F, 45.2F, 10, 14.8F, 10.2F });

            //Encabezados
            table.AddCell(GenerateCell(Resource.SECCION0_LP_COMISION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_LP_CODIGO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_LP_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_LP_CARGO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_LP_DESIGNACION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_LP_COD_AGENCIA, PdfStyles.CellType.ENCABEZADO_GRILLA));

            //Contenidos:
            foreach (var infoLp in informacionesLp.Take(CANTIDAD_MAXIMA_INFO_LP))
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(infoLp.PorcentajeComision), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(infoLp.CodLP), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(infoLp.NombreApellidoLP, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell<TipoCargo>(tipoCargo, PdfStyles.CellType.CONTENIDO, infoLp.Cargo));
                table.AddCell(GenerateMultiselectCell<Designacion>(designaciones, infoLp.Designacion, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(infoLp.Agencia, PdfStyles.CellType.CONTENIDO));
            }
            for (int i = CANTIDAD_MAXIMA_INFO_LP - informacionesLp.Count(); i > 0; i--)
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
            }

            _tables.Add(table);

            /////
            table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCION0_LP_COMENTARIO, PdfStyles.CellType.GRID_FOTTER_COMMENT));
            table.SpacingAfter = 6f;
            _tables.Add(table);
        }

        private void GenerateInfoSuplPa(Caratula caratula)
        {
            ////////
            _tables.Add(GenerateSubtitle(Resource.SECCION0_SUP_TITULO));
            _tables.Last().SpacingAfter = -5f;
            /////
            var table = GenerateTable(PageWidth, new float[] { 18, 8, 5, 4, 65 });
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_CONOCE_PA, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 3));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_RELACION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(caratula.InfoSuplementariaPARelacion, PdfStyles.CellType.CONTENIDO, colspan: 3));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_CONOCE_DESDE, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(caratula.InfoSuplementariaPAConoceDesde, PdfStyles.CellType.CONTENIDO, colspan: 2));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_CONOCE_EN, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));
            table.AddCell(GenerateCell(caratula.InfoSuplementariaPALugarConoce, PdfStyles.CellType.CONTENIDO));
            table.SpacingAfter = 12f;
            _tables.Add(table);

            /////
            table = GenerateTable(PageWidth, new float[] { 67, 12f, 19f });
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_POLIZA_PRUDENTIAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.PoseeOtroSeguro), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_RESP_POLIZA_PRUDENTIAL, PdfStyles.CellType.COMENTARIO));

            foreach (var celda in GenerateCellMultiline(InfoFormatterHelper.Format(caratula.DetalleOtroSeguro), PdfStyles.CellType.CONTENIDO, lineCount: 2, colspan: 3))
            {
                table.AddCell(celda);
            }


            table.SpacingAfter = 8f;
            _tables.Add(table);

            /////
            table = GenerateTable(PageWidth, new float[] { 67, 12f, 19f });
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_OTRO_FAM_POL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.FamiliarPA), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_RESP_OTRO_FAM_POL, PdfStyles.CellType.COMENTARIO));

            foreach (var celda in GenerateCellMultiline(InfoFormatterHelper.Format(caratula.DetalleFamiliarPA), PdfStyles.CellType.CONTENIDO, lineCount: 2, colspan: 3))
            {
                table.AddCell(celda);
            }

            table.SpacingAfter = 11f;
            _tables.Add(table);
        }

        private void GenerateInfoSuplSolicitud(Caratula caratula, ModalidadPago modalidadPago, IEnumerable<TipoTarjetaCredito> tipoTarjeta, IEnumerable<TipoMoneda> tiposMoneda)
        {
            /////
            _tables.Add(GenerateSubtitle(Resource.SECCION0_SUP_SOL_TITULO));
            _tables.Last().SpacingAfter = -5f;
            var table = GenerateTable(PageWidth, new float[] { 25, 11, 18.5f, 45.5f });
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_NEGOCIO_CORPORATIVO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.NegocioCorporativo), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_TIPO_NEGOCIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(caratula.TipoNegocioCorporativo, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 25, 11, 27, 8, 12, 6, 11 });
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_EXAMEN_MEDICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.ExamenMedico), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_PRIMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_MONEDA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<TipoMoneda>(tiposMoneda, PdfStyles.CellType.CONTENIDO, caratula.PrimaMoneda));
            table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_MONTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.PrimaMonto), PdfStyles.CellType.CONTENIDO));
            table.SpacingAfter = 12f;
            _tables.Add(table);

            //table = GenerateTable(PageWidth, new float[] { 40, 16, 15, 13, 16 });
            //table.AddCell(GenerateCell("Completar sÃ³lo en caso de que el medio de pago fuera Tarjeta de CrÃ©dito", PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA));

            if (modalidadPago.MedioDePago == "3")//Si es pago con Tarjeta de Credito
            {
                table = GenerateTable(PageWidth, new float[] { 40, 16, 15, 13, 16 });
                var tarjeta = tipoTarjeta.Where(t => t.id == modalidadPago.TipoTarjetaCredito).FirstOrDefault();
                table.AddCell(GenerateCell(string.Format("{0} {1}", tarjeta != null ? tarjeta.name : "", InfoFormatterHelper.FormatCreditCardNumber(modalidadPago.NroTC)), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_FECHA_VENC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatDate(null, modalidadPago.MesVencimientoTC, modalidadPago.AnioVencimientoTC), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_COD_SEGURIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.CodigoSeguridadTC), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table = GenerateTable(PageWidth, new float[] { 40, 16, 15, 13, 16 });
                table.AddCell(GenerateCell("", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_FECHA_VENC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatDate(null, modalidadPago.MesVencimientoTC, modalidadPago.AnioVencimientoTC), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCION0_SUP_SOL_COD_SEGURIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.CodigoSeguridadTC), PdfStyles.CellType.CONTENIDO));
            }
            table.SpacingAfter = 13f;
            _tables.Add(table);
        }

        private void GenerateEntrevistaTelesuscripcion(Caratula caratula, IEnumerable<HorariosContacto> horariosContacto, IEnumerable<TipoTelefonoFijo> tiposTelefono, IEnumerable<Horario> horarios, IEnumerable<DiaSemana> dias)
        {
            var table = GenerateTable(PageWidth, new float[] { 23f, 77f });
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_TITULO, PdfStyles.CellType.SUBTITLE));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_COMENTARIO, PdfStyles.CellType.SUBTITLE_COMMENT));
            _tables.Add(table);
            _tables.Last().SpacingAfter = -5f;

            table = GenerateTable(PageWidth, new float[] { 13, 11.5f, 11.5f, 39, 24 });
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_DATOS_CONTACTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, rowspan: 6));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_TEL_FIJO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_PREFIJO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(caratula.TelefonoFijo), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell<TipoTelefonoFijo>(tiposTelefono, PdfStyles.CellType.CONTENIDO, caratula.TipoTelefonoFijo));

            table.AddCell(GenerateCell(Resource.SECCION0_TELE_TEL_MOVIL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_PREFIJO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(caratula.TelefonoMovil), PdfStyles.CellType.CONTENIDO, colspan: 2));

            table.AddCell(GenerateCell(Resource.SECCION0_TELE_EMAIL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(caratula.Email), PdfStyles.CellType.CONTENIDO, colspan: 3));
            //table.SpacingAfter=1;

            _tables.Add(table);
            //TODO: FALTA POPULAR ESTA TABLA!!
            table = GenerateTable(PageWidth, new float[] { 13, 12, 15, 15, 15, 15, 15 });
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_SELECCIONAR_TODO, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_LUN_RES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_MAR_RES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_MIE_RES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_JUE_RES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCION0_TELE_VIE_RES, PdfStyles.CellType.ENCABEZADO_GRILLA));

            table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIOS_CONTACTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, rowspan: 8));

            var dicHorarios = GetHorariosYdias(horariosContacto);

            foreach (var horario in dicHorarios.OrderBy(h => h.Key))
            {
                switch (horario.Key)
                {
                    case TipoHorario.HORARIO1:
                        table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO1, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                        break;
                    case TipoHorario.HORARIO2:
                        table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO2, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                        break;
                    case TipoHorario.HORARIO3:
                        table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO3, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                        break;
                    case TipoHorario.HORARIO4:
                        table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO4, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                        break;
                }
                foreach (var dia in horario.Value.OrderBy(h => h.Key))
                {
                    var seleccionados = new List<int>();
                    if (dia.Value[TipoTel.FIJO])
                    {
                        seleccionados.Add(0);
                    }
                    if (dia.Value[TipoTel.MOVIL])
                    {
                        seleccionados.Add(1);
                    }
                    table.AddCell(GenerateListCell(new List<string>() { Resource.SECCION0_TELE_FIJO, Resource.SECCION0_TELE_MOVIL }, PdfStyles.CellType.CONTENIDO, seleccionados));
                }
            }

            //GetCellHorarioContacto

            //var horario1 = horarios.Where(h => h.id == "1").FirstOrDefault() ?? new Horario();
            //foreach (var cell in Semana(horariosContacto, horario1, dias))
            //{
            //    table.AddCell(cell);
            //}

            //table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO2, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            //var horario2 = horarios.Where(h => h.id == "2").FirstOrDefault() ?? new Horario();
            //foreach (var cell in Semana(horariosContacto, horario2, dias))
            //{
            //    table.AddCell(cell);
            //}

            //table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO3, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            //var horario3 = horarios.Where(h => h.id == "3").FirstOrDefault() ?? new Horario();
            //foreach (var cell in Semana(horariosContacto, horario3, dias))
            //{
            //    table.AddCell(cell);
            //}

            //table.AddCell(GenerateCell(Resource.SECCION0_TELE_HORARIO4, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            //var horario4 = horarios.Where(h => h.id == "4").FirstOrDefault() ?? new Horario();
            //foreach (var cell in Semana(horariosContacto, horario4, dias))
            //{
            //    table.AddCell(cell);
            //}
            //AddRowSpace(table, 2);
            table.SpacingAfter = 13;

            _tables.Add(table);

            _tables.Add(GenerateSubtitle(Resource.SECCION0_COMENTARIO_ADICIONALES));
            _tables.Last().SpacingAfter = -5f;
            table = GenerateTable(PageWidth, new float[] { 100 });
            foreach (var celda in GenerateCellMultiline(InfoFormatterHelper.Format(caratula.ComentarioAdicional), PdfStyles.CellType.CONTENIDO, lineCount: 4, colspan: 3))
            {
                table.AddCell(celda);
            }
            _tables.Add(table);
        }

        //private PdfPCell GetCellHorarioContacto(HorariosContacto horario)
        //{
        //    List<int> fijoMovil = new List<int>();
        //    if (horario != null)
        //    {
        //        if (horario.TelefonoFijo.HasValue && horario.TelefonoFijo.Value)
        //            fijoMovil.Add(0);
        //        if (horario.TelefonoMovil.HasValue && horario.TelefonoMovil.Value)
        //            fijoMovil.Add(1);
        //    }
        //    return GenerateListCell(new List<string>() { Resource.SECCION0_TELE_FIJO, Resource.SECCION0_TELE_MOVIL }, PdfStyles.CellType.CONTENIDO, fijoMovil);
        //}

        private PdfPCell GetCellHorarioContacto(HorariosContacto horario)
        {
            List<int> fijoMovil = new List<int>();
            if (horario != null)
            {
                if (horario.TelefonoFijo.HasValue && horario.TelefonoFijo.Value)
                    fijoMovil.Add(0);
                if (horario.TelefonoMovil.HasValue && horario.TelefonoMovil.Value)
                    fijoMovil.Add(1);
            }
            return GenerateListCell(new List<string>() { Resource.SECCION0_TELE_FIJO, Resource.SECCION0_TELE_MOVIL }, PdfStyles.CellType.CONTENIDO, fijoMovil);
        }

        private enum TipoHorario { HORARIO1 = 1, HORARIO2 = 2, HORARIO3 = 3, HORARIO4 = 4 };
        private enum TipoTel { FIJO = 1, MOVIL = 2 }
        private enum DiasSemana { LUN = 1, MAR = 2, MIE = 3, JUE = 4, VIE = 5 };

        private Dictionary<TipoHorario, Dictionary<DiasSemana, Dictionary<TipoTel, bool>>> InitializeHorariosDias()
        {
            Dictionary<TipoHorario, Dictionary<DiasSemana, Dictionary<TipoTel, bool>>> dic = new Dictionary<TipoHorario, Dictionary<DiasSemana, Dictionary<TipoTel, bool>>>();
            foreach (TipoHorario th in Enum.GetValues(typeof(TipoHorario)))
            {
                dic.Add(th, new Dictionary<DiasSemana, Dictionary<TipoTel, bool>>());
                foreach (DiasSemana d in Enum.GetValues(typeof(DiasSemana)))
                {
                    dic[th].Add(d, new Dictionary<TipoTel, bool>());
                    foreach (TipoTel t in Enum.GetValues(typeof(TipoTel)))
                    {
                        dic[th][d].Add(t, false);
                    }
                }
            }
            return dic;
        }

        private Dictionary<TipoHorario, Dictionary<DiasSemana, Dictionary<TipoTel, bool>>> GetHorariosYdias(IEnumerable<HorariosContacto> horariosContacto)
        {
            Dictionary<TipoHorario, Dictionary<DiasSemana, Dictionary<TipoTel, bool>>> dic = InitializeHorariosDias();

            foreach (var horarioContacto in horariosContacto)
            {
                var dias = Deserialize<DiaSemana>(horarioContacto.DiaSemana);
                var horarios = Deserialize<Horario>(horarioContacto.Horario);
                if (horarios == null || dias == null)
                    return dic;
                foreach (var horario in horarios)
                {
                    var h = TipoHorario.HORARIO1;
                    switch (horario.id)
                    {
                        case "1":
                            h = TipoHorario.HORARIO1;
                            break;
                        case "2":
                            h = TipoHorario.HORARIO2;
                            break;
                        case "3":
                            h = TipoHorario.HORARIO3;
                            break;
                        case "4":
                            h = TipoHorario.HORARIO4;
                            break;
                    }

                    var dicHorario = dic[h];
                    foreach (var dia in dias)
                    {
                        var d = DiasSemana.LUN;
                        switch (dia.id)
                        {
                            case "1":
                                d = DiasSemana.LUN;
                                break;
                            case "2":
                                d = DiasSemana.MAR;
                                break;
                            case "3":
                                d = DiasSemana.MIE;
                                break;
                            case "4":
                                d = DiasSemana.JUE;
                                break;
                            case "5":
                                d = DiasSemana.VIE;
                                break;
                        }
                        var dicDia = dicHorario[d];
                        var telFijo = horarioContacto.TelefonoFijo.HasValue && horarioContacto.TelefonoFijo.Value;
                        if (telFijo)
                        {
                            dicDia[TipoTel.FIJO] = telFijo;
                        }

                        var telMobil = horarioContacto.TelefonoMovil.HasValue && horarioContacto.TelefonoMovil.Value;
                        if (telMobil)
                        {
                            dicDia[TipoTel.MOVIL] = telMobil;
                        }
                    }
                }
            }

            return dic;
        }

        private IEnumerable<PdfPCell> Semana(IEnumerable<HorariosContacto> horariosContacto, Horario horario, IEnumerable<DiaSemana> dias)//TODO:!!! CAMBIO EN LA BASE!
        {
            var cells = new List<PdfPCell>();
            var horarios = horariosContacto.Where(h => h.Horario == horario.id).ToList();

            //var lunes = dias.Where(d => d.name == Resource.SECCION0_TELE_LUNES).FirstOrDefault() ?? new DiaSemana();
            //cells.Add(GetCellHorarioContacto(horarios.Where(h => h.DiaSemana == lunes.id).FirstOrDefault()));

            //var martes = dias.Where(d => d.name == Resource.SECCION0_TELE_MARTES).FirstOrDefault() ?? new DiaSemana();
            //cells.Add(GetCellHorarioContacto(horarios.Where(h => h.DiaSemana == martes.id).FirstOrDefault()));

            //var miercoles = dias.Where(d => d.name == Resource.SECCION0_TELE_MIERCOLES).FirstOrDefault() ?? new DiaSemana();
            //cells.Add(GetCellHorarioContacto(horarios.Where(h => h.DiaSemana == miercoles.id).FirstOrDefault()));

            //var jueves = dias.Where(d => d.name == Resource.SECCION0_TELE_JUEVES).FirstOrDefault() ?? new DiaSemana();
            //cells.Add(GetCellHorarioContacto(horarios.Where(h => h.DiaSemana == jueves.id).FirstOrDefault()));

            //var viernes = dias.Where(d => d.name == Resource.SECCION0_TELE_VIERNES).FirstOrDefault() ?? new DiaSemana();
            //cells.Add(GetCellHorarioContacto(horarios.Where(h => h.DiaSemana == viernes.id).FirstOrDefault()));

            var dic = GetHorariosYdias(horariosContacto);


            return cells;
        }

        private const int CANTIDAD_MAXIMA_INFO_LP = 3;

        public IEnumerable<PdfPTable> GenerateExtras(IEnumerable<InformacionLP> informacionesLp, IEnumerable<Designacion> designaciones, IEnumerable<TipoCargo> tipoCargo)
        {
            _tables = new List<PdfPTable>();

            var infoLpExtra = informacionesLp.Skip(CANTIDAD_MAXIMA_INFO_LP).ToList();
            if (infoLpExtra.Count() > 0)
            {
                var table = GenerateSectionTitle("", Resource.SECCION0_TITULO);
                table.SpacingAfter = 24f;
                _tables.Add(table);

                ////////
                _tables.Add(GenerateSubtitle(Resource.SECCION0_LP_TITULO));
                _tables.Last().SpacingAfter = -5f;
                ///////
                table = GenerateTable(PageWidth, new float[] { 9.5F, 10.3F, 45.2F, 10, 14.8F, 10.2F });

                //Encabezados
                table.AddCell(GenerateCell(Resource.SECCION0_LP_COMISION, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCION0_LP_CODIGO, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCION0_LP_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCION0_LP_CARGO, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCION0_LP_DESIGNACION, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCION0_LP_COD_AGENCIA, PdfStyles.CellType.ENCABEZADO_GRILLA));

                //Contenidos:
                foreach (var infoLp in infoLpExtra)
                {
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(infoLp.PorcentajeComision), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(infoLp.CodLP), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(infoLp.NombreApellidoLP, PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell<TipoCargo>(tipoCargo, PdfStyles.CellType.CONTENIDO, infoLp.Cargo));
                    table.AddCell(GenerateCell<Designacion>(designaciones, PdfStyles.CellType.CONTENIDO, infoLp.Designacion));
                    table.AddCell(GenerateCell(infoLp.Agencia, PdfStyles.CellType.CONTENIDO));
                }

                _tables.Add(table);

                /////
                table = GenerateTable(PageWidth, new float[] { 100 });
                table.AddCell(GenerateCell(Resource.SECCION0_LP_COMENTARIO, PdfStyles.CellType.GRID_FOTTER_COMMENT));
                table.SpacingAfter = 6f;
                _tables.Add(table);

            }
            return _tables;
        }
    }

    public class SectionAGenerator : SectionGenerator
    {
        public SectionAGenerator(float pageWidth)
            : base(pageWidth)
        {
        }

        public IEnumerable<PdfPTable> Generate(string nroSolicitud, DatosPA datosPa, IQueryable<Domicilio> addressQuery, IEnumerable<SeguroDeVida> otherLifeInssurance
            , IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades
            , IEnumerable<Iva> tipoIva, IEnumerable<TipoSeguro> tipoSeguro, IEnumerable<Provincia> provincias, IEnumerable<Finalidad> tipoFinalidad, IEnumerable<TipoMoneda> tiposMoneda)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateQuestionnaireTitle(Resource.SECCION_TITULO, Resource.SECCION_POLIZA, ""));
            _tables.Last().SpacingAfter = 3f;
            //_tables.Add(GenerateSectionTitle("A", Resource.SECCIONA_TITULO));
            _tables.Add(GenerateSectionTitle("A", Resource.SECCIONA_TITULO, Resource.SECCION_NRO, nroSolicitud));
            AddInfoGralPa(datosPa, addressQuery, otherLifeInssurance, tipoSexo, tipoEstadoCivil, nacionalidades, tipoIva, tipoSeguro, provincias, tiposMoneda);
            AddDatosAdicionalesPa(datosPa, tipoFinalidad, nacionalidades);
            _tables.Last().SpacingAfter = 7f;
            return _tables;
        }

        private void AddInfoGralPa(DatosPA datosPa, IQueryable<Domicilio> addressQuery, IEnumerable<SeguroDeVida> otherLifeInssurance
                , IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades
                , IEnumerable<Iva> tipoIva, IEnumerable<TipoSeguro> tipoSeguro, IEnumerable<Provincia> provincias, IEnumerable<TipoMoneda> tiposMoneda)
        {
            _tables.Add(GenerateSubtitle(Resource.SECCIONA_INFO_PA_TITULO));
            _tables.Last().SpacingAfter = -6f;
            /////////
            AddBasicData(datosPa);

            var table = GenerateTable(PageWidth, new float[] { 75.66f, 68, 87.68f, 312.77f });
            table.AddCell(GenerateCell(Resource.CLAVES_TRIBUTARIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateClaveTributariaCell(datosPa.NumeroClaveTributaria, datosPa.TipoClaveTributaria, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_TAREAS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.TareasDesempenia, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 31.56f, 99.86f, 57.51f, 212.36f, 34.0f, 108f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_SEXO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Sexo>(tipoSexo, PdfStyles.CellType.CONTENIDO, datosPa.Sexo));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_ESTADO_CIVIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<TipoEstadoCivil>(tipoEstadoCivil, PdfStyles.CellType.CONTENIDO, datosPa.EstadoCivil));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_HIJOS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.Hijos), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 31.56f, 24.88f, 65, 50.47f, 54.48f, 112.26f, 63.68f, 144f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_EDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(CalculateAge(datosPa.FechaNacimiento)), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NACIONALIDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Nacionalidad>(nacionalidades, PdfStyles.CellType.CONTENIDO, datosPa.Nacionalidad));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_LUGAR_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.LugarDeNacimiento, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 72.51f, 72, 28.33f, 154.0f, 78.55f, 142f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NRO_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.NroIngresosBrutos), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_IVA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tipoIva, PdfStyles.CellType.CONTENIDO, datosPa.Iva));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(datosPa.IngresoBrutoAnual, InfoFormatterHelper.Symbols.ARS), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            AddAddress(Resource.SECCIONA_INFO_PA_DOMICILIO_PARTICULAR, addressQuery, datosPa.DomicilioParticular, provincias);
            AddAddress(Resource.SECCIONA_INFO_PA_DOMICILIO_CORRESPONDENCIA, addressQuery, datosPa.DomicilioCorrespondencia, provincias);
            AddAddress(Resource.SECCIONA_INFO_PA_DOMICILIO_FISCAL, addressQuery, datosPa.DomicilioLaboral, provincias);

            table = GenerateTable(PageWidth, new float[] { 75, 88, 65, 108, 71, 139 });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_TEL_PARTICULAR, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(datosPa.TelefonoParticularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_TEL_CELULAR, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(datosPa.TelefonoCelularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_TEL_LABORAL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(datosPa.TelefonoLaboralNumero), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateImageCell(Resource.SECCIONA_INFO_PA_AUTORIZO_MAIL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA, selected: (datosPa.AutorizacionPrudential.HasValue && datosPa.AutorizacionPrudential.Value)));
            //table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.AutorizacionPrudential), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 54, 75, 418 });
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.AutorizacionPrudential), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_EMAIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Email, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 211, 65, 272 });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_TIENE_OTROS_SEGUROS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.OtroSegurosDeVida), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_COMENTARIO_OTROS_SEGUROS, PdfStyles.CellType.COMENTARIO));
            _tables.Add(table);

            AddOthersInssurances(otherLifeInssurance, tipoSeguro, tiposMoneda);

            table = GenerateTable(PageWidth, new float[] { 273, 38, 238 });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_REEMPLAZA_POLIZA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.Reemplazo), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_COMENTARIO_REEMPLAZA_POLIZA, PdfStyles.CellType.COMENTARIO));

            _tables.Add(table);
            _tables.Last().SpacingAfter = 3f;
        }

        private void AddDatosAdicionalesPa(DatosPA datosPa, IEnumerable<Finalidad> tipoFinalidad, IEnumerable<Nacionalidad> nacionalidades)
        {
            _tables.Add(GenerateSubtitle(Resource.SECCIONA_DATOS_ADIC_TITULO, Resource.SECCIONA_DATOS_ADIC_COMENTARIO_TITULO));
            _tables.Last().SpacingAfter = 3f;
            /////////
            AddDatosAdicionales(datosPa, tipoFinalidad, nacionalidades);

        }

        private const int CANTIDAD_MAXIMA_OTROS_SEGUROS = 2;
        private void AddOthersInssurances(IEnumerable<SeguroDeVida> otherLifeInssurance, IEnumerable<TipoSeguro> tipoSeguro, IEnumerable<TipoMoneda> tiposMoneda)
        {
            for (int i = 0; i < CANTIDAD_MAXIMA_OTROS_SEGUROS && i < otherLifeInssurance.Count(); i++)
            {
                var lifeInssurance = otherLifeInssurance.ToList()[i];

                var table = GenerateTable(PageWidth, new float[] { 52, 86, 50, 81, 57, 49, 78, 42, 55 });
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_COMPANIA, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(lifeInssurance.Compania, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(lifeInssurance.SumaAsegurada, tiposMoneda, lifeInssurance.Moneda), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_ANIO_EMISION, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(lifeInssurance.AnioEmision), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(tipoSeguro, PdfStyles.CellType.CONTENIDO, lifeInssurance.TipoSeguro));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_EXAMEN_MEDICO, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(lifeInssurance.ExamenMedico), PdfStyles.CellType.CONTENIDO));
                _tables.Add(table);
            }
            for (int i = CANTIDAD_MAXIMA_OTROS_SEGUROS - otherLifeInssurance.Count(); i > 0; i--)
            {
                var table = GenerateTable(PageWidth, new float[] { 52, 86, 50, 81, 57, 49, 78, 42, 55 });
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_COMPANIA, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_ANIO_EMISION, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_EXAMEN_MEDICO, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                _tables.Add(table);
            }
        }

        private void AddExtraOthersInssurances(IEnumerable<SeguroDeVida> otherLifeInssurance, IEnumerable<TipoSeguro> tipoSeguro, IEnumerable<TipoMoneda> tiposMoneda, IList<PdfPTable> tables)
        {
            foreach (var lifeInssurance in otherLifeInssurance.Skip(CANTIDAD_MAXIMA_OTROS_SEGUROS))
            {
                var table = GenerateTable(PageWidth, new float[] { 52, 86, 50, 81, 57, 49, 78, 42, 55 });
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_COMPANIA, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(lifeInssurance.Compania, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_GRILLA));

                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(lifeInssurance.SumaAsegurada, tiposMoneda, lifeInssurance.Moneda), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_ANIO_EMISION, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(lifeInssurance.AnioEmision), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(tipoSeguro, PdfStyles.CellType.CONTENIDO, lifeInssurance.TipoSeguro));
                table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_EXAMEN_MEDICO, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(lifeInssurance.ExamenMedico), PdfStyles.CellType.CONTENIDO));
                tables.Add(table);
            }
        }

        public IEnumerable<PdfPTable> GenerateExtras(DatosPA datosPa, IEnumerable<SeguroDeVida> otherLifeInssurance, IEnumerable<TipoSeguro> tipoSeguro, IEnumerable<TipoMoneda> tiposMoneda, IEnumerable<FotoDocumento> fotos, IEnumerable<Nacionalidad> nacionalidades)
        {
            _tables = new List<PdfPTable>();
            var tables1 = new List<PdfPTable>();
            var tables2 = new List<PdfPTable>();
            if (otherLifeInssurance.Count() > CANTIDAD_MAXIMA_OTROS_SEGUROS)
            {
                tables1.Add(GenerateSubtitle(Resource.SECCIONA_INFO_PA_TITULO));
                tables1.Last().SpacingAfter = -6f;
                AddExtraOthersInssurances(otherLifeInssurance, tipoSeguro, tiposMoneda, tables1);
                tables1.Last().SpacingAfter = 7f;
            }
            if (IsTrue(datosPa.Extranjero))
            {
                var cuidadanias = Deserialize<Nacionalidad>(datosPa.Pais);
                if (cuidadanias.Count() > CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL)
                {
                    tables2.Add(GenerateSubtitle(Resource.SECCIONA_DATOS_ADIC_TITULO, Resource.SECCIONA_DATOS_ADIC_COMENTARIO_TITULO));
                    tables2.Last().SpacingAfter = 3f;
                    var table = GenerateTable(PageWidth, new float[] { 142, 26, 42, 339 });
                    table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.Extranjero), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
                    table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, datosPa.Pais, PdfStyles.CellType.CONTENIDO, skip: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
                    tables2.Add(table);
                }
            }
            if (fotos.Count() > 0)
            {
                if(tables1.Count() == 0)
                {
                    tables1.Add(GenerateSubtitle(Resource.SECCIONA_INFO_PA_TITULO));
                    tables1.Last().SpacingAfter = -6f;
                }
                tables1.Add(GenerateImageTable(fotos));
                tables1.Last().SpacingAfter = 7f;
            }

            if (tables1.Count() > 0 || tables2.Count() >0)
            {
                _tables.Add(GenerateQuestionnaireTitle(Resource.SECCION_TITULO, Resource.SECCION_POLIZA, ""));
                _tables.Last().SpacingAfter = 3f;
                _tables.Add(GenerateSectionTitle("A", Resource.SECCIONA_TITULO));
                _tables.AddRange(tables1);
                _tables.AddRange(tables2);
            }
            return _tables;
        }

    }

    public class SectionBGenerator : SectionGenerator
    {
        private const int CANTIDAD_MAXIMA = 7;

        public SectionBGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {

        }

        public IEnumerable<PdfPTable> Generate(IEnumerable<Beneficiario> beneficiarios)
        {
            _tables = new List<PdfPTable>();
            beneficiarios = beneficiarios.OrderBy(b => b.Orden);
            _tables.Add(GenerateSectionTitle("B", Resource.SECCIONB_TITULO));

            var columnsWidths = new float[] { 294, 23, 23, 75, 70, 64 };
            AddGridHeaders(new List<string>()
            {
                Resource.SECCIONB_NOMBRE,
                Resource.SECCIONB_ORDEN,
                Resource.SECCIONB_PORCENTAJE,
                Resource.SECCIONB_RELACION_PA,
                Resource.SECCIONB_DOCUMENTO,
                Resource.SECCIONB_FECHA_NACIMIENTO
            }, columnsWidths);

            var table = GenerateTable(PageWidth, new float[] { 294, 23, 23, 75, 70, 64 });
            for (int i = 0; i < CANTIDAD_MAXIMA && i < beneficiarios.Count(); i++)
            {
                var beneficiario = beneficiarios.ToList()[i];

                table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(beneficiario.Nombre, beneficiario.Apellido), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.Orden), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.Porcentaje), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(beneficiario.RelacionPA, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(GetDocumentValue(beneficiario.TipoDocumento, beneficiario.NumeroDocumento), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.FechaNacimiento), PdfStyles.CellType.CONTENIDO));

            }
            //Completo con lÃ¬neas vacias:
            for (int i = CANTIDAD_MAXIMA - beneficiarios.Count(); i > 0; i--)
            {
                if (beneficiarios.Count() == 0 && i == CANTIDAD_MAXIMA)
                {
                    table.AddCell(GenerateCell(SIN_DECLARAR_LABEL, PdfStyles.CellType.CONTENIDO));
                }
                else
                {
                    table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                }
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
            }

            _tables.Add(table);
            _tables.Last().SpacingAfter = -1f;
            table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(
                With(x => { x.PaddingTop = 0; x.MinimumHeight = 0; }, GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONB_COMENTARIO_1, Resource.SECCIONB_COMENTARIO_2), PdfStyles.CellType.GRID_FOTTER_COMMENT)));
            _tables.Add(table);

            return _tables;
        }

        public IEnumerable<PdfPTable> GenerateExtras(IEnumerable<Beneficiario> beneficiarios)
        {
            _tables = new List<PdfPTable>();
            beneficiarios = beneficiarios.OrderBy(b => b.Orden);
            var beneficiariosExtra = beneficiarios.Skip(CANTIDAD_MAXIMA).ToList();
            if (beneficiariosExtra.Count() > 0)
            {
                _tables.Add(GenerateSectionTitle("B", Resource.SECCIONB_TITULO));

                var columnsWidths = new float[] { 294, 23, 23, 75, 70, 64 };
                AddGridHeaders(new List<string>()
            {
                Resource.SECCIONB_NOMBRE,
                Resource.SECCIONB_ORDEN,
                Resource.SECCIONB_PORCENTAJE,
                Resource.SECCIONB_RELACION_PA,
                Resource.SECCIONB_DOCUMENTO,
                Resource.SECCIONB_FECHA_NACIMIENTO
            }, columnsWidths);

                var table = GenerateTable(PageWidth, new float[] { 294, 23, 23, 75, 70, 64 });
                for (int i = 0; i < beneficiariosExtra.Count(); i++)
                {
                    var beneficiario = beneficiariosExtra.ToList()[i];

                    table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(beneficiario.Nombre, beneficiario.Apellido), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.Orden), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.Porcentaje), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(beneficiario.RelacionPA, PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(GetDocumentValue(beneficiario.TipoDocumento, beneficiario.NumeroDocumento), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(beneficiario.FechaNacimiento), PdfStyles.CellType.CONTENIDO));

                }

                _tables.Add(table);
                _tables.Last().SpacingAfter = -1f;
                table = GenerateTable(PageWidth, new float[] { 100 });
                table.AddCell(
                    With(x => { x.PaddingTop = 0; x.MinimumHeight = 0; }, GenerateCell(Resource.SECCIONB_COMENTARIO_1, PdfStyles.CellType.GRID_FOTTER_COMMENT)));
                _tables.Add(table);
            }
            return _tables;
        }

    }

    public class SectionCGenerator : SectionGenerator
    {
        public SectionCGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDocumento)
            : base(pageWidth, tipoDocumento)
        {
        }

        public IEnumerable<PdfPTable> Generate(ModalidadPagoBeneficio modalidadPago, IEnumerable<CaracterPedido> caracteresPedidoCobro
                 , IEnumerable<TipoOpcionPago> tipoOpcionPago, IEnumerable<TipoPagoRentaTemporaria> tipoPagoRentaTemporaria, IEnumerable<TipoMoneda> tiposMoneda)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("C", Resource.SECCIONC_TITULO));

            var pagoUnico = tipoOpcionPago.Where(o => o.id == "1");
            var pagoRentaTemporaria = tipoOpcionPago.Where(o => o.id == "2");
            var cantidadCuotas = tipoPagoRentaTemporaria.Where(t => t.id == "1");
            var montoFijoCuotas = tipoPagoRentaTemporaria.Where(t => t.id == "2");

            var tipoMoneda = tiposMoneda.Where(t => t.id == modalidadPago.TipoMoneda).FirstOrDefault() ?? new TipoMoneda();

            var table = GenerateTable(PageWidth, new float[] { 50, 120, 207, 113, 59 });
            table.AddCell(GenerateCell(Resource.SECCIONC_PAGO_BENEFICIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, rowspan: 2));
            table.AddCell(GenerateListCell(pagoUnico, PdfStyles.CellType.CONTENIDO, modalidadPago.OpcionPagoBeneficio));
            table.AddCell(GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONC_COMENTARIO_PAGO_BENEFICIO_1, Resource.SECCIONC_COMENTARIO_PAGO_BENEFICIO_2), PdfStyles.CellType.ENCABEZADO_PREGUNTA, rowspan: 2));
            table.AddCell(GenerateListCell(cantidadCuotas, PdfStyles.CellType.CONTENIDO, modalidadPago.TipoPagoRentaTemporaria));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.CantidadFijaCuotas), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateListCell(pagoRentaTemporaria, PdfStyles.CellType.CONTENIDO, modalidadPago.OpcionPagoBeneficio));
            table.AddCell(GenerateListCell(montoFijoCuotas, PdfStyles.CellType.CONTENIDO, modalidadPago.TipoPagoRentaTemporaria));
            table.AddCell(GenerateCell(string.Format("{0} {1}", tipoMoneda.name, InfoFormatterHelper.Format(modalidadPago.MontoFijoCuotas)), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 120, 428 });
            table.AddCell(GenerateCell(Resource.SECCIONC_CARACTER_COBRO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<CaracterPedido>(caracteresPedidoCobro, PdfStyles.CellType.CONTENIDO, modalidadPago.CaracterPedidoCobro));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 50, 498 });
            table.AddCell(GenerateCell(Resource.SECCIONC_PEDIDOS_ESPECIALES, PdfStyles.CellType.ENCABEZADO_PREGUNTA, rowspan: 2));
            //table.AddCell(GenerateCell(modalidadPago.PedidosEspeciales, PdfStyles.CellType.CONTENIDO, rowspan: 2));

            foreach (var celda in GenerateCellMultiline(InfoFormatterHelper.Format(modalidadPago.PedidosEspeciales), PdfStyles.CellType.CONTENIDO, lineCount: 2, percent: 90))
            {
                table.AddCell(celda);
            }

            _tables.Add(table);

            return _tables;
        }

    }

    public class SectionDGenerator : SectionGenerator
    {
        private const string ID_PERSONA_FISICA = "1";
        private const string ID_PERSONA_JURIDICA = "2";
        public SectionDGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(DatosDelTomador datosTomador, TomadorPersonaFisica tomador, IQueryable<Domicilio> addressQuery, TomadorDatosEmpresa tomadorEmpresa, TomadorDatosRepresentanteLegal representanteLegal
            , IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades
            , IEnumerable<Iva> tipoIva, IEnumerable<Finalidad> tipoFinalidad, IEnumerable<Provincia> provincias)
        {
            _tables = new List<PdfPTable>();
            _tables.Add(GenerateSectionTitle("D", Resource.SECCIOND_TITULO));

            _tables.Last().SpacingBefore = -6f;
            _tables.Last().SpacingAfter = 4f;

            if (datosTomador.TipoPersona == ID_PERSONA_FISICA)//Si es persona fisica
            {
                AddInfoTomadorFisico(datosTomador, tomador, addressQuery, tipoSexo, tipoEstadoCivil, nacionalidades, tipoIva, tipoFinalidad, provincias);
                AddInfoTomadorJuridico(new DatosDelTomador(), new TomadorDatosEmpresa(), addressQuery, tipoIva, provincias);
                AddDatosRepLegal(representanteLegal, addressQuery, tipoSexo, tipoEstadoCivil, nacionalidades, provincias);
            }
            else
            {
                AddInfoTomadorFisico(new DatosDelTomador(), new TomadorPersonaFisica(), addressQuery, tipoSexo, tipoEstadoCivil, nacionalidades, tipoIva, tipoFinalidad, provincias);
                AddInfoTomadorJuridico(datosTomador, tomadorEmpresa, addressQuery, tipoIva, provincias);
                AddDatosRepLegal(representanteLegal, addressQuery, tipoSexo, tipoEstadoCivil, nacionalidades, provincias);
            }


            return _tables;
        }


        private void AddInfoTomadorFisico(DatosDelTomador datosTomador, TomadorPersonaFisica tomadorPersonaFisica, IQueryable<Domicilio> addressQuery
            , IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades
            , IEnumerable<Iva> tipoIva, IEnumerable<Finalidad> tipoFinalidad, IEnumerable<Provincia> provincias)
        {
            var table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TITULO, PdfStyles.CellType.SUBTITLE));
            _tables.Add(table);
            _tables.Last().SpacingAfter = -5f;

            table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 69.48f, 133.71f, 265 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(tomadorPersonaFisica.NumeroDocumento, tomadorPersonaFisica.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_PROFESION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.Profesion, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.66f, 69, 87.68f, 311.77f });
            table.AddCell(GenerateCell(Resource.CLAVES_TRIBUTARIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateClaveTributariaCell(tomadorPersonaFisica.NumeroClaveTributaria, tomadorPersonaFisica.TipoClaveTributaria, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TAREAS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.TareasDesempenia, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 36, 53, 50, 199, 72, 138 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_SEXO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Sexo>(tipoSexo, PdfStyles.CellType.CONTENIDO, tomadorPersonaFisica.Sexo));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_ESTADO_CIVIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<TipoEstadoCivil>(tipoEstadoCivil, PdfStyles.CellType.CONTENIDO, tomadorPersonaFisica.EstadoCivil));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_RELACION_PA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.RelacionPA), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 77, 96, 72, 113, 76, 115 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_NACIONALIDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Nacionalidad>(nacionalidades, PdfStyles.CellType.CONTENIDO, tomadorPersonaFisica.Nacionalidad));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_LUGAR_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.LugarDeNacimiento, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 77, 96, 29, 119, 78, 151 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_NRO_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.NroIngresosBrutos), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_IVA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Iva>(tipoIva, PdfStyles.CellType.CONTENIDO, tomadorPersonaFisica.Iva));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(tomadorPersonaFisica.IngresoBrutoAnual, InfoFormatterHelper.Symbols.ARS), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            AddAddress(Resource.SECCIOND_PERS_FISICA_DOMICILIO_PARTICULAR, addressQuery, tomadorPersonaFisica.DomicilioParticular, provincias);
            AddAddress(Resource.SECCIOND_PERS_FISICA_DOMICILIO_CORRESPONDENCIA, addressQuery, datosTomador.DomicilioCorrespondencia, provincias);
            AddAddress(Resource.SECCIOND_PERS_FISICA_DOMICILIO_FISCAL, addressQuery, datosTomador.DomicilioLaboral, provincias);

            table = GenerateTable(PageWidth, new float[] { 75, 88, 65, 108, 71, 139 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TEL_PARTICULAR, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(tomadorPersonaFisica.TelefonoParticularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TEL_CELULAR, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(tomadorPersonaFisica.TelefonoCelularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TEL_LABORAL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(tomadorPersonaFisica.TelefonoLaboralNumero), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 54, 75, 418 });
            //table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_AUTORIZO_MAIL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA, colspan: 3));
            table.AddCell(GenerateImageCell(Resource.SECCIONA_INFO_PA_AUTORIZO_MAIL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA, selected: (tomadorPersonaFisica.AutorizacionPrudential.HasValue && tomadorPersonaFisica.AutorizacionPrudential.Value), colspan: 3));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.AutorizacionPrudential), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_EMAIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(tomadorPersonaFisica.Email, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 177, 36, 42, 89, 215 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.Extranjero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            if (IsTrue(tomadorPersonaFisica.Extranjero))
            {
                table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, tomadorPersonaFisica.Pais, PdfStyles.CellType.CONTENIDO, take: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
            }
            else
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_COMENTARIO_CIUDADANIA, PdfStyles.CellType.COMENTARIO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 163, 188 + 89 + 109 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_FINALIDAD_PARA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Finalidad>(tipoFinalidad, PdfStyles.CellType.CONTENIDO, tomadorPersonaFisica.Finalidad));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 70, 301, 69, 109 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_CONYUGE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(tomadorPersonaFisica.NombresCony, tomadorPersonaFisica.ApellidosCony), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(tomadorPersonaFisica.NroDocCony, tomadorPersonaFisica.TipoDocCony, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            _tables.Last().SpacingAfter = 8f;
        }

        private void AddInfoTomadorJuridico(DatosDelTomador datosTomador, TomadorDatosEmpresa tomadorEmpresa, IQueryable<Domicilio> addressQuery
            , IEnumerable<Iva> tipoIva, IEnumerable<Provincia> provincias)
        {
            var table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_TITULO, PdfStyles.CellType.SUBTITLE));
            _tables.Add(table);
            _tables.Last().SpacingAfter = -5f;

            table = GenerateTable(PageWidth, new float[] { 55, 283, 76, 134 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_RAZON_SOCIAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(tomadorEmpresa.RazonSocial, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.CLAVES_TRIBUTARIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateClaveTributariaCell(tomadorEmpresa.NumeroClaveTributaria, tomadorEmpresa.TipoClaveTributaria, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 59, 279, 76, 134 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_ACTIVIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(tomadorEmpresa.ActPrincipal, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_RELACION_PA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(tomadorEmpresa.RelacionConPA, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 72, 99, 26, 122, 95, 134 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_NRO_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorEmpresa.NroIngBrutos), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_IVA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<Iva>(tipoIva, PdfStyles.CellType.CONTENIDO, tomadorEmpresa.Iva));
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_FACTURACION_ANUAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(tomadorEmpresa.FactBrutaAnual, InfoFormatterHelper.Symbols.ARS), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            AddAddress(Resource.SECCIOND_PERS_JUR_DOMICILIO_FISCAL, addressQuery, datosTomador.DomicilioLaboral, provincias);
            AddAddress(Resource.SECCIOND_PERS_JUR_DOMICILIO_CORRESPONDENCIA, addressQuery, datosTomador.DomicilioCorrespondencia, provincias);

            table = GenerateTable(PageWidth, new float[] { 47, 501 });
            table.AddCell(GenerateCell(Resource.SECCIOND_PERS_JUR_TELEFONOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(tomadorEmpresa.Telefono1), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            _tables.Last().SpacingAfter = 7f;
        }

        private void AddDatosRepLegal(TomadorDatosRepresentanteLegal representanteLegal, IQueryable<Domicilio> addressQuery,
            IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades
            , IEnumerable<Provincia> provincias)
        {
            var table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_TITULO, PdfStyles.CellType.SUBTITLE));
            _tables.Add(table);
            _tables.Last().SpacingAfter = -5f;

            table = GenerateTable(PageWidth, new float[] { 222, 325 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_ES_EL_PA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(representanteLegal.EsPA), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(representanteLegal.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_APELLIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(representanteLegal.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 69.48f, 133.71f, 265 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(representanteLegal.NumeroDocumento, representanteLegal.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_PROFESION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(representanteLegal.Profesion, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.66f, 69, 87.68f, 311.77f });
            table.AddCell(GenerateCell(Resource.CLAVES_TRIBUTARIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateClaveTributariaCell(representanteLegal.NumeroClaveTributaria, representanteLegal.TipoClaveTributaria, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_TAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(representanteLegal.TareasDesempenia, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 33, 56, 54, 404 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_SEXO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<Sexo>(tipoSexo, PdfStyles.CellType.CONTENIDO, representanteLegal.Sexo));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_ESTADO_CIVIL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<TipoEstadoCivil>(tipoEstadoCivil, PdfStyles.CellType.CONTENIDO, representanteLegal.EstadoCivil));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 76, 95, 68, 110, 75, 123 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(representanteLegal.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_NACIONALIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<Nacionalidad>(nacionalidades, PdfStyles.CellType.CONTENIDO, representanteLegal.Nacionalidad));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_LUGAR_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(representanteLegal.LugarDeNacimiento, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            AddAddress(Resource.SECCIOND_RESP_LEGAL_DOMICILIO_PARTICULAR, addressQuery, representanteLegal.DomicilioParticular, provincias);

            table = GenerateTable(PageWidth, new float[] { 75, 88, 65, 108, 71, 139 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_TEL_PARTICULAR, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(representanteLegal.TelefonoParticularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_TEL_CELULAR, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(representanteLegal.TelefonoCelularNumero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_TEL_LABORAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(representanteLegal.TelefonoLaboralNumero), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 54, 75, 418 });
            //table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_AUTORIZO_MAIL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA, colspan: 3));
            table.AddCell(GenerateImageCell(Resource.SECCIONA_INFO_PA_AUTORIZO_MAIL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_GRILLA, selected: (representanteLegal.AutorizacionPrudential.HasValue && representanteLegal.AutorizacionPrudential.Value), colspan:3));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(representanteLegal.AutorizacionPrudential), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_EMAIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(representanteLegal.Email, PdfStyles.CellType.CONTENIDO));

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 70, 301, 69, 109 });
            table.AddCell(GenerateCell(Resource.SECCIOND_RESP_LEGAL_CONYUGE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(representanteLegal.NombresCony, representanteLegal.ApellidosCony), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(representanteLegal.NroDocCony, representanteLegal.TipoDocCony, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);
        }

        public IEnumerable<PdfPTable> GenerateExtras(DatosDelTomador datosTomador, TomadorPersonaFisica tomadorPersonaFisica, IEnumerable<FotoDocumento> fotos, IEnumerable<Nacionalidad> nacionalidades)
        {
            _tables = new List<PdfPTable>();
            var tables = new List<PdfPTable>();
            if (datosTomador.TipoPersona == ID_PERSONA_FISICA)
            {
                if (IsTrue(tomadorPersonaFisica.Extranjero))
                {
                    var ciudadanias = Deserialize<Nacionalidad>(tomadorPersonaFisica.Pais);
                    if (ciudadanias.Count() > CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL)
                    {
                        var table = GenerateTable(PageWidth, new float[] { 142, 26, 42, 339 });
                        table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                        table.AddCell(GenerateCell(InfoFormatterHelper.Format(tomadorPersonaFisica.Extranjero), PdfStyles.CellType.CONTENIDO));
                        table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
                        table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, tomadorPersonaFisica.Pais, PdfStyles.CellType.CONTENIDO, skip: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
                        tables.Add(table);
                    }
                }

                if (fotos.Count() > 0)
                {
                    var table = GenerateTable(PageWidth, new float[] { 100 });
                    table.AddCell(GenerateCell(Resource.SECCIOND_PERS_FISICA_TITULO, PdfStyles.CellType.SUBTITLE));
                    tables.Add(table);
                    tables.Last().SpacingAfter = -5f;

                    tables.Add(GenerateImageTable(fotos));
                }
            }
            if (tables.Count() > 0)
            {
                _tables.Add(GenerateSectionTitle("D", Resource.SECCIOND_TITULO));

                _tables.Last().SpacingBefore = -6f;
                _tables.Last().SpacingAfter = 4f;
                _tables.AddRange(tables);
            }

            return _tables;
        }

    }

    public class SectionEGenerator : SectionGenerator
    {
        public SectionEGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(string nroSolicitud, Cobertura cobertura, IEnumerable<TipoMoneda> tipoMoneda
            , IEnumerable<OpcionCuentaFondosAdicionales> opcionCuentaFondosAdicionales, IEnumerable<PrestamoPagoAut> tipoPrestamoPagoAut, IEnumerable<Caducidad> tipoCaducidad, IEnumerable<TipoCoberturaDolar> tipoCoberturaDolar, IEnumerable<TipoCoberturaPesos> tipoCoberturaPesos)
        {
            _tables = new List<PdfPTable>();

            //_tables.Add(GenerateSectionTitle("E", Resource.SECCIONE_TITULO));
            _tables.Add(GenerateSectionTitle("E", Resource.SECCIONE_TITULO, Resource.SECCION_NRO, nroSolicitud));
            _tables.Last().SpacingAfter = 4f;

            var table = GenerateTable(PageWidth, new float[] { 48, 94, 49, 70, 83, 202 });

            if (cobertura.TipoMoneda == "1")
            {

                table.AddCell(WithMinHeght(24, GenerateCell(Resource.SECCIONE_PLAN_BASICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA)));
                table.AddCell(GenerateCell<TipoCoberturaPesos>(tipoCoberturaPesos, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.PlanBasico)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.PlanBasicoSumaAsegurada, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_MONEDA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateListMonedas(PdfStyles.CellType.CONTENIDO, cobertura.TipoMoneda));
                _tables.Add(table);

                table = GenerateTable(PageWidth, new float[] { 48, 94, 49, 70, 134, 30, 49, 73 });
                table.AddCell(WithMinHeght(24, GenerateCell(Resource.SECCIONE_COBERT_ADIC1, PdfStyles.CellType.ENCABEZADO_PREGUNTA)));
                table.AddCell(GenerateCell<TipoCoberturaPesos>(tipoCoberturaPesos, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional1)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional1SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_BENEFICIO_MUERTE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.BenefMuerteAccidental, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.BenefMuerteAccidentalSumaAseg, null), PdfStyles.CellType.CONTENIDO));

                table.AddCell(GenerateCell(Resource.SECCIONE_COBERT_ADIC2, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell<TipoCoberturaPesos>(tipoCoberturaPesos, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional2)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional2SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_ENFERM_CRITICA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));//TODO: TIENE DOS FUENTE DISTINTAS
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.EnfCritica, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.EnfCriticaSumaAseg, null), PdfStyles.CellType.CONTENIDO));

                table.AddCell(GenerateCell(Resource.SECCIONE_COBERT_ADIC3, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell<TipoCoberturaPesos>(tipoCoberturaPesos, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional3)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional3SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_COMPRA_ADIC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.OpcionCompraSegAdic, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.OpCompraSegAdicSumaAseg, null), PdfStyles.CellType.CONTENIDO));
                _tables.Add(table);
            }
            else
            {

                table.AddCell(WithMinHeght(24, GenerateCell(Resource.SECCIONE_PLAN_BASICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA)));
                table.AddCell(GenerateCell<TipoCoberturaDolar>(tipoCoberturaDolar, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.PlanBasico)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.PlanBasicoSumaAsegurada, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_MONEDA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateListMonedas(PdfStyles.CellType.CONTENIDO, cobertura.TipoMoneda));
                _tables.Add(table);

                table = GenerateTable(PageWidth, new float[] { 48, 94, 49, 70, 134, 30, 49, 73 });
                table.AddCell(WithMinHeght(24, GenerateCell(Resource.SECCIONE_COBERT_ADIC1, PdfStyles.CellType.ENCABEZADO_PREGUNTA)));
                table.AddCell(GenerateCell<TipoCoberturaDolar>(tipoCoberturaDolar, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional1)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional1SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_BENEFICIO_MUERTE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.BenefMuerteAccidental, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.BenefMuerteAccidentalSumaAseg, null), PdfStyles.CellType.CONTENIDO));

                table.AddCell(GenerateCell(Resource.SECCIONE_COBERT_ADIC2, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell<TipoCoberturaDolar>(tipoCoberturaDolar, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional2)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional2SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_ENFERM_CRITICA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));//TODO: TIENE DOS FUENTE DISTINTAS
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.EnfCritica, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.EnfCriticaSumaAseg, null), PdfStyles.CellType.CONTENIDO));

                table.AddCell(GenerateCell(Resource.SECCIONE_COBERT_ADIC3, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell<TipoCoberturaDolar>(tipoCoberturaDolar, PdfStyles.CellType.CONTENIDO, InfoFormatterHelper.Format(cobertura.CoberturaAdicional3)));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.CoberturaAdicional3SumaAseg, null), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONE_COMPRA_ADIC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.OpcionCompraSegAdic, differentRows: true));
                table.AddCell(GenerateCell(Resource.SECCIONE_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.OpCompraSegAdicSumaAseg, null), PdfStyles.CellType.CONTENIDO));
                _tables.Add(table);
            }

            table = GenerateTable(PageWidth, new float[] { 94, 52, 52, 64, 133, 148 });
            table.AddCell(GenerateCell(Resource.SECCIONE_FONDOS_ADIC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, cobertura.AporteFondosAdicionales));
            table.AddCell(GenerateCell(Resource.SECCIONE_APORTE_INICIAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(cobertura.AporteInicial, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONE_CUENTA_FONDOS_ADIC, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<OpcionCuentaFondosAdicionales>(opcionCuentaFondosAdicionales, PdfStyles.CellType.CONTENIDO, cobertura.OpcionCuentaFondosAdicionales));
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 143, 404 });
            table.AddCell(GenerateCell(Resource.SECCIONE_SI_DOTAL, PdfStyles.CellType.COMENTARIO));
            table.AddCell(GenerateImageCell(Resource.SECCIONE_COMENTARIO_DOTAL, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, selected: EsDotal(cobertura)));
            table.AddCell(GenerateCell(Resource.SECCIONE_SI_PESOS_PLUS, PdfStyles.CellType.COMENTARIO));
            table.AddCell(GenerateImageCell(Resource.SECCIONE_COMENTARIO_PESOS_PLUS, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, selected: EsPesosPlus(cobertura)));
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 312, 236 });
            table.AddCell(WithMinHeght(24, GenerateCell(Resource.SECCIONE_NO_ABONA_PRIMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA)));
            table.AddCell(GenerateListCell<PrestamoPagoAut>(tipoPrestamoPagoAut, PdfStyles.CellType.CONTENIDO, Deserialize<PrestamoPagoAut>(cobertura.PrestamoPagoAut).Select(p => p.id), differentRows: true));
            table.AddCell(GenerateCell(Resource.SECCIONE_NO_ABONA_PRIMA_CADUCIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<Caducidad>(tipoCaducidad, PdfStyles.CellType.CONTENIDO, cobertura.Caducidad));
            _tables.Add(table);

            _tables.Last().SpacingAfter = 4f;

            table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(With(x => { x.Padding = 0; x.MinimumHeight = 0; }, GenerateCell(Resource.SECCIONE_SEGURO_PERMANENTE, PdfStyles.CellType.GRID_FOTTER_COMMENT_TITLE)));
            table.AddCell(With(x => { x.Padding = 0; x.MinimumHeight = 0; }, GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONE_COMENTARIO_FINAL_1, Resource.SECCIONE_COMENTARIO_FINAL_2), PdfStyles.CellType.GRID_FOTTER_COMMENT)));
            _tables.Add(table);

            _tables.Last().SpacingAfter = 18f;

            return _tables;
        }

        private const string ID_MONEDA_PESOS = "1";
        private const string ID_MONEDA_DOLAR = "2";
        private static List<string> IDS_PLANES_BASICOS_DOTAL = new List<string>() { "29", "30" };

        private bool EsDotal(Cobertura cobertura)
        {
            return (IDS_PLANES_BASICOS_DOTAL.Contains(cobertura.PlanBasico) || cobertura.TipoMoneda != ID_MONEDA_DOLAR) && cobertura.TipoMoneda != ID_MONEDA_PESOS;
        }

        private bool EsPesosPlus(Cobertura cobertura)
        {
            return cobertura.TipoMoneda == ID_MONEDA_PESOS;
        }

    }

    public class SectionFGenerator : SectionGenerator
    {
        public SectionFGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(ModalidadPago modalidadPago, IEnumerable<TipoMoneda> tipoMoneda, IEnumerable<TipoFrecuenciaPago> tipoFrecuenciaPago
            , IEnumerable<TipoMedioPago> tipoMedioPago, IEnumerable<TipoFechaDebito> tipoFechaDebito, IEnumerable<TipoTarjetaCredito> tipoTarjetaCredito
            , IEnumerable<TipoCuentaDebito> tipoCuentaDebito)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("F", Resource.SECCIONF_TITULO));
            _tables.Last().SpacingAfter = 5f;

            var table = GenerateTable(PageWidth, new float[] { 105, 77, 43, 92, 78, 153 });
            table.AddCell(GenerateCell(Resource.SECCIONF_PRIMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoMoneda>(tipoMoneda, PdfStyles.CellType.CONTENIDO, modalidadPago.TipoMoneda));
            table.AddCell(GenerateCell(Resource.SECCIONF_IMPORTE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.ImportePrima), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONF_FRECUENCIA_PAGO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoFrecuenciaPago>(tipoFrecuenciaPago, PdfStyles.CellType.CONTENIDO, modalidadPago.FrecuenciaPago));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 135, 413 });
            table.AddCell(GenerateCell(Resource.SECCIONF_MEDIO_PAGO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoMedioPago>(tipoMedioPago, PdfStyles.CellType.CONTENIDO, modalidadPago.MedioDePago));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 238, 71, 238 });
            table.AddCell(GenerateCell(Resource.SECCIONF_COMENTARIO_SI_DEBITO, PdfStyles.CellType.COMENTARIO));
            table.AddCell(GenerateCell(Resource.SECCIONF_FECHA_DEBITO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoFechaDebito>(tipoFechaDebito, PdfStyles.CellType.CONTENIDO, modalidadPago.FechaDebito));
            _tables.Add(table);
            _tables.Last().SpacingAfter = 9f;

            _tables.Add(GenerateSubtitle(Resource.SECCIONF_INFO_MEDIO_PAGO_TITULO));
            _tables.Last().SpacingAfter = -5f;

            table = GenerateTable(PageWidth, new float[] { 162, 386 });
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(modalidadPago.NombreTitularMedioPago, modalidadPago.ApellidoTitularMedioPago), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 42, 96, 251, 43, 116 });
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_TARJETA, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_TIPO_TARJETA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoTarjetaCredito>(tipoTarjetaCredito, PdfStyles.CellType.CONTENIDO, modalidadPago.TipoTarjetaCredito));
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_BANCO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(modalidadPago.BancoTC, PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_NRO_TARJETA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            var nroTc = "";
            if (!string.IsNullOrEmpty(modalidadPago.NroTC) && modalidadPago.NroTC.Length >= 4)
            {
                nroTc = "XXXX XXXX XXXX " + modalidadPago.NroTC.Substring(modalidadPago.NroTC.Length - 4, 4);
            }
            table.AddCell(GenerateCell(nroTc, PdfStyles.CellType.CONTENIDO, colspan: 3));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 42, 90, 253, 42, 121 });
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_DEBITO_DIRECTO, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 3));
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_TIPO_CUENTA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateListCell<TipoCuentaDebito>(tipoCuentaDebito, PdfStyles.CellType.CONTENIDO, modalidadPago.TipoCuentaDebito));
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_BANCO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.BancoDebito), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_NRO_CUENTA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.NroCuentaDebito), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_SUCURSAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.SucursalDebito), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONF_INFO_MEDIO_PAGO_CBU, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(modalidadPago.CBUDebito), PdfStyles.CellType.CONTENIDO, colspan: 3));

            table.AddCell(GenerateImageCell(Resource.SECCIONF_INFO_MEDIO_PAGO_AUTORIZO_DEBITO, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, selected: modalidadPago.MedioDePago == "2" || modalidadPago.MedioDePago == "3", colspan: 5));//Si es pago con tarjeta de credito o debito automatico

            table.AddCell(GenerateCell(string.Format("{0} \n {1}", Resource.SECCIONF_FOOTER_1, Resource.SECCIONF_FOOTER_2), PdfStyles.CellType.GRID_FOTTER_COMMENT, colspan: 5));

            _tables.Add(table);
            _tables.Last().SpacingAfter = 14f;

            return _tables;
        }
    }

    public class SectionGGenerator : SectionGenerator
    {
        public SectionGGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(DatosDelPagador pagador, IEnumerable<Sexo> tipoSexo, IEnumerable<TipoEstadoCivil> tipoEstadoCivil, IEnumerable<Nacionalidad> nacionalidades)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("G", Resource.SECCIONG_TITULO));
            _tables.Last().SpacingAfter = 5f;

            var table = GenerateTable(PageWidth, new float[] { 50, 187, 50, 259 });
            table.AddCell(GenerateCell(Resource.SECCIONG_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.Nombres), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONG_APELLIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.Apellidos), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 87, 79, 65, 98, 91, 124 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(pagador.NumeroDocumento, pagador.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.CLAVES_TRIBUTARIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateClaveTributariaCell(pagador.NumeroClaveTributaria, pagador.TipoClaveTributaria, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONG_ING_BRUTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatMoney(pagador.IngresoBrutoAnual, InfoFormatterHelper.Symbols.ARS), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 135, 410 });
            table.AddCell(GenerateCell(Resource.SECCIONG_PROFESION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.Profesion), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 88, 458 });
            table.AddCell(GenerateCell(Resource.SECCIONG_TAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.TareasDesempenia), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 35, 49, 50, 196, 75, 142 });
            table.AddCell(GenerateCell(Resource.SECCIONG_SEXO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Sexo>(tipoSexo, PdfStyles.CellType.CONTENIDO, pagador.Sexo));
            table.AddCell(GenerateCell(Resource.SECCIONG_ESTADO_CIVIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<TipoEstadoCivil>(tipoEstadoCivil, PdfStyles.CellType.CONTENIDO, pagador.EstadoCivil));
            table.AddCell(GenerateCell(Resource.SECCIONG_RELACION_PA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.RelacionPA), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 77, 93, 65, 112, 67, 132 });
            table.AddCell(GenerateCell(Resource.SECCIONG_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONG_NACIONALIDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell<Nacionalidad>(nacionalidades, PdfStyles.CellType.CONTENIDO, pagador.Nacionalidad));
            table.AddCell(GenerateCell(Resource.SECCIONG_LUGAR_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(pagador.LugarDeNacimiento, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 177, 25, 43, 94, 204 });
            table.AddCell(GenerateCell(Resource.SECCIONG_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.Extranjero), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONG_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
            if (IsTrue(pagador.Extranjero))
            {
                table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, pagador.Pais, PdfStyles.CellType.CONTENIDO, take: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
            }
            else
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            table.AddCell(GenerateCell(Resource.SECCIONG_COMENTARIO_CIUDADANIA, PdfStyles.CellType.COMENTARIO));
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 70, 301, 69, 109 });
            table.AddCell(GenerateCell(Resource.SECCIONG_CONYUGE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatName(pagador.NombresCony, pagador.ApellidosCony), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(pagador.NroDocCony, pagador.TipoDocumentoConyuge, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            return _tables;
        }

        public IEnumerable<PdfPTable> GenerateExtras(DatosDelPagador pagador, IEnumerable<FotoDocumento> fotos, IEnumerable<Nacionalidad> nacionalidades)
        {
            _tables = new List<PdfPTable>();
            var tables = new List<PdfPTable>();
            if (IsTrue(pagador.Extranjero))
            {
                var ciudadanias = Deserialize<Nacionalidad>(pagador.Pais);
                if (ciudadanias.Count() > CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL)
                {
                    var table = GenerateTable(PageWidth, new float[] { 142, 26, 42, 339 });
                    table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_OTRA_CIUDADANIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                    table.AddCell(GenerateCell(InfoFormatterHelper.Format(pagador.Extranjero), PdfStyles.CellType.CONTENIDO));
                    table.AddCell(GenerateCell(Resource.SECCIONA_DATOS_ADIC_QUE_PAISES, PdfStyles.CellType.ENCABEZADO_GRILLA));
                    table.AddCell(GenerateMultiselectCell<Nacionalidad>(nacionalidades, pagador.Pais, PdfStyles.CellType.CONTENIDO, skip: CANTIDAD_NACIONALIDADES_SECCION_PRINCIPAL));
                    tables.Add(table);
                }
            }

            if (fotos.Count() > 0)
            {
                tables.Add(GenerateImageTable(fotos));
            }

            if(tables.Count() > 0)
            {
                _tables.Add(GenerateSectionTitle("G", Resource.SECCIONG_TITULO));
                _tables.Last().SpacingAfter = 5f;
                _tables.AddRange(tables);
            }
            return _tables;
        }
    }

    public class SectionHGenerator : SectionGenerator
    {
        public SectionHGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(OtrasActDelPA otrasAct)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("H", Resource.SECCIONH_TITULO));


            var table = GenerateTable(PageWidth, new float[] { 5, 85, 10 });

            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONH_AVIACION_1, Resource.SECCIONH_AVIACION_2), PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(otrasAct.Aviacion), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCIONH_AUTOMOVILISMO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(otrasAct.Automovilismo), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCIONH_PRISION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(otrasAct.Imputado), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("4", PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCIONH_VIAJAR, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(otrasAct.Viajar), PdfStyles.CellType.CONTENIDO));

            string descriptions = "";
            if (otrasAct.Imputado.HasValue && otrasAct.Imputado.Value)
                descriptions += string.Format("{0}: {1}", "3", otrasAct.DetalleImputado);

            var cant = 0;
            foreach (var cell in GenerateCellMultilineAndStops(descriptions, PdfStyles.CellType.CONTENIDO, colspan: 3, lineCount: CANTIDAD_MAXIMA_LINEAS_DETALLE))
            {
                table.AddCell(cell);
                cant++;
            }

            if (otrasAct.Viajar.HasValue && otrasAct.Viajar.Value)
                descriptions = string.Format("{0}: {1} ", "4", otrasAct.DetalleViajar);

            foreach (var cell in GenerateCellMultilineAndStops(descriptions, PdfStyles.CellType.CONTENIDO, colspan: 3, lineCount: CANTIDAD_MAXIMA_LINEAS_DETALLE))
            {
                table.AddCell(cell);
                cant++;
            }

            if (cant < CANTIDAD_MAXIMA_LINEAS_DETALLE)
            {
                foreach (var cell in GenerateCellMultiline("", PdfStyles.CellType.CONTENIDO, colspan: 3, lineCount: CANTIDAD_MAXIMA_LINEAS_DETALLE - cant))
                {
                    table.AddCell(cell);
                    cant++;
                }
            }

            _tables.Add(table);

            return _tables;
        }

        private const int CANTIDAD_MAXIMA_LINEAS_DETALLE = 8;
    }

    public class SectionIGenerator : SectionGenerator
    {
        private const int CANTIDAD_MAXIMA_ANTECEDENTES = 6;
        private const int CANTIDAD_MAXIMA_HERMANOS = 4;
        private IEnumerable<AntecedentesFamDelPA> _antecedentes;
        private IEnumerable<TipoRelacionParentesco> _tipoRelacion;

        private const string ID_RELACION_PADRE = "1";
        private const string ID_RELACION_MADRE = "2";
        private const string ID_RELACION_HERMANO = "3";
        public SectionIGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(IEnumerable<AntecedentesFamDelPA> antecedentes, IEnumerable<TipoRelacionParentesco> tipoRelacion)
        {
            _antecedentes = antecedentes;
            _tipoRelacion = tipoRelacion;
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("I", Resource.SECCIONI_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 10, 5, 35, 10, 40 });

            //Encabezados:
            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONI_VIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONI_FALLECIDOS, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONI_EDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONI_ESTADO_SALUD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONI_EDAD_FALLECER, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONI_CAUSA_DECESO, PdfStyles.CellType.ENCABEZADO_GRILLA));

            AddAntecedenteFamiliar(Resource.SECCIONI_PADRE, table, ID_RELACION_PADRE, antecedentes.Count() == 0);
            AddAntecedenteFamiliar(Resource.SECCIONI_MADRE, table, ID_RELACION_MADRE);

            //Fila Hermano/a:
            var relacionHermano = tipoRelacion.Where(r => r.id == ID_RELACION_HERMANO).FirstOrDefault();
            var antecedentesHermanos = antecedentes.Where(a => a.RelacionParentesco == relacionHermano.id).ToList();
            for (int i = 0; i < antecedentesHermanos.Count(); i++)
            {
                var antecedentesHermano = antecedentesHermanos[i];
                table.AddCell(GenerateCell(Resource.SECCIONI_HERMANO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                AddDatos(antecedentesHermanos[i], table);
            }

            //todo: es posible que no todos los datos esten completos, el pdf se puede generar antes de validar
            for (int i = CANTIDAD_MAXIMA_ANTECEDENTES - antecedentes.Count(); i > 0; i--)//Agrego lineas si faltan hermanos
            {
                AddAntecedenteFamiliar(Resource.SECCIONI_HERMANO, table, "");
            }
            _tables.Add(table);

            return _tables;
        }

        private void AddAntecedenteFamiliar(string nombreRelacion, PdfPTable table, string idTipo, bool sinDatos = false)
        {
            table.AddCell(GenerateCell(nombreRelacion, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            var relacion = _tipoRelacion.Where(r => r.id == idTipo).FirstOrDefault();
            AntecedentesFamDelPA antecedente = null;
            if (relacion != null)
            {
                antecedente = _antecedentes.Where(a => a.RelacionParentesco == relacion.id).FirstOrDefault();
            }
            AddDatos(antecedente, table, sinDatos);
        }

        private void AddDatos(AntecedentesFamDelPA antecedente, PdfPTable table, bool sinDatos = false)
        {
            if (antecedente != null)
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(antecedente.EdadVive), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(antecedente.EstadoSaludVive), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(antecedente.EdadFallecido), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(antecedente.CausaDeceso), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(string.Empty), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(sinDatos ? SIN_DECLARAR_LABEL : string.Empty), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(string.Empty), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(string.Empty), PdfStyles.CellType.CONTENIDO));
            }
        }

        private IEnumerable<AntecedentesFamDelPA> GetAntecedentes()
        {
            var antecedentes = new List<AntecedentesFamDelPA>();
            var antecedentePadre = _antecedentes.Where(a => a.RelacionParentesco == ID_RELACION_PADRE).FirstOrDefault();
            if (antecedentePadre != null)
                antecedentes.Add(antecedentePadre);
            var antecedenteMadre = _antecedentes.Where(a => a.RelacionParentesco == ID_RELACION_MADRE).FirstOrDefault();
            if (antecedenteMadre != null)
                antecedentes.Add(antecedenteMadre);
            antecedentes.AddRange(_antecedentes.Where(a => a.RelacionParentesco == ID_RELACION_HERMANO).Take(CANTIDAD_MAXIMA_HERMANOS));
            return antecedentes;
        }

        private IEnumerable<AntecedentesFamDelPA> GetAntecedentesExtras()
        {
            var antecedentesPrincipales = GetAntecedentes();
            return _antecedentes.Where(a => !antecedentesPrincipales.Select(i => i.id).Contains(a.id));
        }

        public IEnumerable<PdfPTable> GenerateExtras(IEnumerable<AntecedentesFamDelPA> antecedentes, IEnumerable<TipoRelacionParentesco> tipoRelacion)
        {
            _antecedentes = antecedentes;
            _tipoRelacion = tipoRelacion;
            _tables = new List<PdfPTable>();

            var antecedentesExtra = GetAntecedentesExtras();

            if (antecedentesExtra.Count() > 0)
            {
                _tables.Add(GenerateSectionTitle("I", Resource.SECCIONI_TITULO));

                var table = GenerateTable(PageWidth, new float[] { 10, 5, 35, 10, 40 });

                //Encabezados:
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(Resource.SECCIONI_VIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));
                table.AddCell(GenerateCell(Resource.SECCIONI_FALLECIDOS, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));

                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(Resource.SECCIONI_EDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCIONI_ESTADO_SALUD, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCIONI_EDAD_FALLECER, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCIONI_CAUSA_DECESO, PdfStyles.CellType.ENCABEZADO_GRILLA));

                foreach (var antecedente in antecedentesExtra)
                {
                    switch (antecedente.RelacionParentesco)
                    {
                        case ID_RELACION_PADRE:
                            table.AddCell(GenerateCell(Resource.SECCIONI_PADRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                            break;
                        case ID_RELACION_MADRE:
                            table.AddCell(GenerateCell(Resource.SECCIONI_MADRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                            break;
                        case ID_RELACION_HERMANO:
                            table.AddCell(GenerateCell(Resource.SECCIONI_HERMANO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                            break;
                    }

                    AddDatos(antecedente, table);
                }

                _tables.Add(table);
            }

            return _tables;
        }

    }

    public class SectionJGenerator : SectionGenerator
    {
        public SectionJGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(InfoMedicaDelPA infoMedicaPA, DatosMedico ultimoConsultado, DatosMedico medicoCabecera, IQueryable<Domicilio> domiciliosQuery, IEnumerable<Provincia> provincias)
        {
            _tables = new List<PdfPTable>();
            _tables.Add(GenerateSectionTitle("J", Resource.SECCIONJ_TITULO));

            _tables.Add(GenerateSubtitle(Resource.SECCIONJ_ULT_CONSULTADO_TITULO));
            var noRecuerda = (infoMedicaPA.RecuerdaDatosUltimaConsulta.HasValue && infoMedicaPA.RecuerdaDatosUltimaConsulta.Value);
            AddDatosMedicos(ultimoConsultado, provincias, domiciliosQuery, Resource.SECCIONJ_NO_RECUERDA, recuerda: !noRecuerda);

            _tables.Add(GenerateSubtitle(Resource.SECCIONJ_MED_CABECERA_TITULO, Resource.SECCIONJ_MED_CABECERA_COMENTARIO_TITULO));
            AddDatosMedicos(medicoCabecera, provincias, domiciliosQuery, Resource.SECCIONJ_MISMO_CABECERA, mostrarDatos: !(infoMedicaPA.UltimoConsultadoEsCabecera.HasValue && infoMedicaPA.UltimoConsultadoEsCabecera.Value));

            return _tables;
        }

        private void AddDatosMedicos(DatosMedico consulta, IEnumerable<Provincia> provincias, IQueryable<Domicilio> addressQuery, string textoMostrar, bool recuerda = true, bool mostrarDatos = true)
        {
            var table = GenerateTable(PageWidth, new float[] { 7, 43, 7, 43 });
            table.AddCell(GenerateCell(Resource.SECCIONJ_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(mostrarDatos ? consulta.Nombre : string.Empty, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONJ_APELLIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(mostrarDatos ? consulta.Apellido : string.Empty, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            //if (!recuerda || !mostrarDatos)
            //{
            //    table = GenerateTable(PageWidth, new float[] { 100 });
            //    table.AddCell(GenerateCell(textoMostrar, PdfStyles.CellType.ENCABEZADO_GRILLA));
            //    _tables.Add(table);
            //}
            //else
            //{
            table = GenerateTable(PageWidth, new float[] { 15, 61, 7, 15 });
            table.AddCell(GenerateCell(Resource.SECCIONJ_MOTIVO_CONSULTA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            if(!recuerda || !mostrarDatos)
            {
                table.AddCell(GenerateCell(textoMostrar, PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(mostrarDatos ? consulta.MotivoUltimaConsulta : string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            table.AddCell(GenerateCell(Resource.SECCIONJ_FECHA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(mostrarDatos ? InfoFormatterHelper.Format(consulta.FechaUltimaConsulta) : string.Empty, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);
            //}
            table = GenerateTable(PageWidth, new float[] { 30, 70 });
            table.AddCell(GenerateCell(Resource.SECCIONJ_PRESCRIPCION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            var cells = GenerateCellMultilineFirst(mostrarDatos ? InfoFormatterHelper.Format(consulta.Tratamiento) : string.Empty, PdfStyles.CellType.CONTENIDO, percentFirstLine: 70, colspan: 2, lineCount: 2).ToList();
            table.AddCell(cells[0]);
            cells[1].Colspan = 2;
            table.AddCell(cells[1]);
            _tables.Add(table);

            AddAddress(Resource.SECCIONJ_DOMICILIO, addressQuery, mostrarDatos ? consulta.DomicilioLaboral : "-1", provincias);

            table = GenerateTable(PageWidth, new float[] { 7, 20, 5, 66 });
            table.AddCell(GenerateCell(Resource.SECCIONJ_TELEFONO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(mostrarDatos ? InfoFormatterHelper.FormatPhone(consulta.TelefonoNumero) : string.Empty, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONJ_EMAIL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(mostrarDatos ? InfoFormatterHelper.Format(consulta.Email) : string.Empty, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);
        }

    }

    public class SectionKGenerator : SectionGenerator
    {
        public SectionKGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(string nroSolicitud, ContexturaPA contextura)
        {
            _tables = new List<PdfPTable>();

            //_tables.Add(GenerateSectionTitle("K", Resource.SECCIONK_TITULO));
            _tables.Add(GenerateSectionTitle("K", Resource.SECCIONK_TITULO, Resource.SECCION_NRO, nroSolicitud));

            var table = GenerateTable(PageWidth, new float[] { 8, 9, 8, 9, 24, 15, 10, 9 });
            table.AddCell(GenerateCell(Resource.SECCIONK_ALTURA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(contextura.Altura, InfoFormatterHelper.Symbols.LENGHT, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONK_PESO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(contextura.Peso, InfoFormatterHelper.Symbols.WEIGTH, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONK_VARIO_PESO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, contextura.VarioPeso));
            table.AddCell(GenerateCell(Resource.SECCIONK_VARIACION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(contextura.Variacion, InfoFormatterHelper.Symbols.PLUS, null), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            return _tables;
        }

    }

    public class SectionLGenerator : SectionGenerator
    {
        public SectionLGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(UsoNicotina usoNicotina)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("L", Resource.SECCIONL_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 90, 15 });
            table.AddCell(GenerateCell(Resource.SECCIONL_FUMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, usoNicotina.FumaActualmente));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 15, 12.5f, 15, 12.5f, 15, 12.5f });
            table.AddCell(GenerateCell(Resource.SECCIONL_CANTIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(usoNicotina.ConsumoDiarioFuma), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONL_ANIOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(usoNicotina.CantidadAniosFuma), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONL_ULTIMA_VEZ, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(usoNicotina.UltimaVezFumo), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 90, 15 });
            table.AddCell(GenerateCell(Resource.SECCIONL_CONSUME_ALCOHOL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, usoNicotina.ConsumeAlcohol));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 15, 12.5f, 15, 57 });
            table.AddCell(GenerateCell(Resource.SECCIONL_CANTIDAD_ALCOHOL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(usoNicotina.ConsumoDiarioAlcohol), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONL_TIPO_BEBIDA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(usoNicotina.TipoBebida), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            return _tables;
        }

    }

    public class SectionMGenerator : SectionGenerator
    {
        private const int MAX_LINE_COUNT_DESCRIPTION = 38;
        private const int MAX_LINE_COUNT_DESCRIPTION_PLUS = 40;
        private int _lineCount = 0;
        private IEnumerable<AntecedentesMedicos> _antecedentesMedicos;
        public SectionMGenerator(float pageWidth, IEnumerable<AntecedentesMedicos> antecedentesMedicos)
            : base(pageWidth)
        {
            _antecedentesMedicos = antecedentesMedicos;
        }

        public IEnumerable<PdfPTable> GeneratePage1(AntecedentesMedicosPA antecedentes)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle("M", Resource.SECCIONM_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 5, 5, 80, 15 });
            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_HA_SIDO_DIAGNOSTICADO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("a", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_INFARTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaInfarto).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("b", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_HIPERTENSION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaHipertension).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("c", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_CANCER, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaCancer).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("d", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_DIABETES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaDiabetes).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("e", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ASMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaRespiratorio).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("f", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_MAREOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaSistemaNervioso).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("g", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ENF_MENTALES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.EnfermedadMental).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("h", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_HEPATITIS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.TrastornoHepatico).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("i", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ULCERAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaGastrointestinal).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("j", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ENF_RENAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaRenal).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("k", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ENF_SEXUAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.EnfermedadesTransmisionSexual).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("l", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ENF_OJOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemaOjosNarizGarganta).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("m", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ENF_OSEA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.ProblemasOseos).Respuesta));

            ////

            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ADEMAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));



            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("a", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_TOMA_MEDICACION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.TomaMedicamentos).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("b", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_CONSULTA_MEDICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.PiensaSolicitarMedico).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("c", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ESTUVO_INTERNADO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.EstuvoInternado).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("d", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_OPERACION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.SeHaSometidoACirugias).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("e", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ESTUDIOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.SeHaSometidoAEstudiosDiagnostico).Respuesta));


            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("f", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_EMBARAZADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.EstaEmbarazada).Respuesta));

            ////

            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_USO_DROGAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.HaUsadoDrogas).Respuesta));

            ////

            table.AddCell(GenerateCell("4", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_ADICCION, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.HaAsistidoACentroRehabilitacion).Respuesta));

            ////

            table.AddCell(GenerateCell("5", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_OTRO_PROBLEMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.TieneOtroProblemaSalud).Respuesta));

            ////

            table.AddCell(GenerateCell("6", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_POLIZA_RECHAZADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.SeguroVidaRechazado).Respuesta));

            ////

            table.AddCell(GenerateCell("7", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_BENEFICIO_DISCAPACIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateBooleanListCell(PdfStyles.CellType.CONTENIDO, GetAntecedentesMedicos(antecedentes.BeneficiosPorDiscapacidad).Respuesta));

            //table.AddCell(GenerateCell("De obtenerse alguna respuesta afirmativa a alguna de las preguntas precedentes, proporcionar los detalles pertinentes en la siguiente secciÃ³n, indicando el nÃºmero de pregunta.", PdfStyles.CellType.GRID_FOTTER_COMMENT, colspan: 4));

            _tables.Add(table);

            return _tables;
        }

        private AntecedentesMedicos GetAntecedentesMedicos(string id)
        {
            return _antecedentesMedicos.Where(a => a.id == id).FirstOrDefault() ?? new AntecedentesMedicos();
        }

        private IList<PdfPTable> _extraTablesAntecedentesMedicos = new List<PdfPTable>();

        private int AddAntecedentesMedicos(string antecedenteId, string questionNumber, PdfPTable table)
        {
            var antecedente = GetAntecedentesMedicos(antecedenteId);
            if (!string.IsNullOrEmpty(antecedente.Detalle) || !string.IsNullOrEmpty(antecedente.MedicoInstitucion))
            {
                var descriptionCells = GenerateCellMultilineAndStops(antecedente.Detalle, PdfStyles.CellType.CONTENIDO, 70f);
                var institutionCells = GenerateCellMultilineAndStops(antecedente.MedicoInstitucion, PdfStyles.CellType.CONTENIDO, 25f);

                var descripcionCellsCount = descriptionCells.Count();
                var institutionCellsCount = institutionCells.Count();

                var maxLineCount = Math.Max(descripcionCellsCount, institutionCellsCount);

                if (MAX_LINE_COUNT_DESCRIPTION >= _lineCount + maxLineCount)//Si puedo seguir agregando filas en la hoja
                {
                    for (int i = 0; i < maxLineCount; i++)
                    {
                        if (i == 0)
                        {
                            table.AddCell(GenerateCell(questionNumber, PdfStyles.CellType.CONTENIDO));
                        }
                        else
                        {
                            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                        }
                        if (i < descripcionCellsCount)
                        {
                            //  descriptionCells[i].Padding = 2;
                            table.AddCell(descriptionCells[i]);
                        }
                        else
                        {
                            table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                        }
                        if (i < institutionCellsCount)
                        {
                            // institutionCells[i].Padding = 2;
                            table.AddCell(institutionCells[i]);
                        }
                        else
                        {
                            table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                        }
                    }
                    _lineCount += maxLineCount;
                }
                else
                {//tengo que agregar las filas en un apartado!
                    PdfPTable tableExtra = GenerateTable(PageWidth, new float[] { 5, 70, 25 });
                    for (int i = 0; i < maxLineCount; i++)
                    {
                        if (i == 0)
                        {
                            tableExtra.AddCell(GenerateCell(questionNumber, PdfStyles.CellType.CONTENIDO));
                        }
                        else
                        {
                            tableExtra.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                        }
                        if (i < descripcionCellsCount)
                        {
                            tableExtra.AddCell(descriptionCells[i]);
                        }
                        else
                        {
                            tableExtra.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                        }
                        if (i < institutionCellsCount)
                        {
                            tableExtra.AddCell(institutionCells[i]);
                        }
                        else
                        {
                            tableExtra.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                        }
                    }
                    _extraTablesAntecedentesMedicos.Add(tableExtra);
                }

                return maxLineCount;
            }
            return 0;
        }


        public IEnumerable<PdfPTable> GeneratePage2(AntecedentesMedicosPA antecedentes)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSubtitle(Resource.SECCIONM_M1));

            var table = GenerateTable(PageWidth, new float[] { 5, 70, 25 });
            table.AddCell(GenerateCell(Resource.SECCIONM_NRO_M1, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_DETALLE_M1, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONM_DETALLE_MEDICO_INSTITUCION, PdfStyles.CellType.ENCABEZADO_GRILLA));//TODO: PONER LOS SUBTITULOS EN LAS GRILLAS

            _extraTablesAntecedentesMedicos = new List<PdfPTable>();
            AddAntecedentesMedicos(antecedentes.ProblemaInfarto, "1.a", table);
            AddAntecedentesMedicos(antecedentes.ProblemaHipertension, "1.b", table);
            AddAntecedentesMedicos(antecedentes.ProblemaCancer, "1.c", table);
            AddAntecedentesMedicos(antecedentes.ProblemaDiabetes, "1.d", table);
            AddAntecedentesMedicos(antecedentes.ProblemaRespiratorio, "1.e", table);
            AddAntecedentesMedicos(antecedentes.ProblemaSistemaNervioso, "1.f", table);
            AddAntecedentesMedicos(antecedentes.EnfermedadMental, "1.g", table);
            AddAntecedentesMedicos(antecedentes.TrastornoHepatico, "1.h", table);
            AddAntecedentesMedicos(antecedentes.ProblemaGastrointestinal, "1.i", table);
            AddAntecedentesMedicos(antecedentes.ProblemaRenal, "1.j", table);
            AddAntecedentesMedicos(antecedentes.EnfermedadesTransmisionSexual, "1.k", table);
            AddAntecedentesMedicos(antecedentes.ProblemaOjosNarizGarganta, "1.l", table);
            AddAntecedentesMedicos(antecedentes.ProblemasOseos, "1.m", table);
            AddAntecedentesMedicos(antecedentes.TomaMedicamentos, "2.a", table);
            AddAntecedentesMedicos(antecedentes.PiensaSolicitarMedico, "2.b", table);
            AddAntecedentesMedicos(antecedentes.EstuvoInternado, "2.c", table);
            AddAntecedentesMedicos(antecedentes.SeHaSometidoACirugias, "2.d", table);
            AddAntecedentesMedicos(antecedentes.SeHaSometidoAEstudiosDiagnostico, "2.e", table);
            AddAntecedentesMedicos(antecedentes.EstaEmbarazada, "2.f", table);
            AddAntecedentesMedicos(antecedentes.HaUsadoDrogas, "3", table);
            AddAntecedentesMedicos(antecedentes.HaAsistidoACentroRehabilitacion, "4", table);
            AddAntecedentesMedicos(antecedentes.TieneOtroProblemaSalud, "5", table);
            AddAntecedentesMedicos(antecedentes.SeguroVidaRechazado, "6", table);
            AddAntecedentesMedicos(antecedentes.BeneficiosPorDiscapacidad, "7", table);

            for (int i = MAX_LINE_COUNT_DESCRIPTION - _lineCount; i > 0; i--)
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.CONTENIDO));
            }
            table.AddCell(GenerateCell(string.Format("{0} \n {1} \n {2} \n {3}", Resource.SECCIONM_M1_R1, Resource.SECCIONM_M1_R2, Resource.SECCIONM_M1_R3, Resource.SECCIONM_M1_R4), PdfStyles.CellType.GRID_FOTTER_COMMENT, colspan: 3));

            _tables.Add(table);

            return _tables;
        }

        public IEnumerable<IEnumerable<PdfPTable>> GenerateExtras()
        {
            var pages = new List<IEnumerable<PdfPTable>>();
            _tables = new List<PdfPTable>();

            if (_extraTablesAntecedentesMedicos.Count() > 0)
            {
                _tables = new List<PdfPTable>();

                _tables.Add(GenerateSectionTitle("M", Resource.SECCIONM_TITULO));

                _tables.Add(GenerateSubtitle(Resource.SECCIONM_M1));

                var table = GenerateTable(PageWidth, new float[] { 5, 70, 25 });
                table.AddCell(GenerateCell(Resource.SECCIONM_NRO_M1, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCIONM_M1_DETALLE, PdfStyles.CellType.ENCABEZADO_GRILLA));
                table.AddCell(GenerateCell(Resource.SECCIONM_M1_MEDICO_INSTITUCION, PdfStyles.CellType.ENCABEZADO_GRILLA));//TODO: PONER LOS SUBTITULOS EN LAS GRILLAS

                int i = 0;
                foreach (var t in _extraTablesAntecedentesMedicos)
                {
                    _tables.Add(t);
                    i += t.Rows.Count;
                    if (i >= MAX_LINE_COUNT_DESCRIPTION_PLUS)
                    {
                        i = 0;
                        pages.Add(_tables);
                        _tables = new List<PdfPTable>();
                    }
                }

                if (i < MAX_LINE_COUNT_DESCRIPTION_PLUS)
                {
                    pages.Add(_tables);
                }

            }

            return pages;
        }
    }

    public class CuestionarioInfoAdicionalPa : SectionGenerator
    {
        public CuestionarioInfoAdicionalPa(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(CuestionarioXVII cuestionario)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateSectionTitle(" ", Resource.SECCIONXVII_TITULO, Resource.SECCIONXVII_COMENTARIO_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 5, 80, 15 });
            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXVII_DERRAME_CEREBRAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Infarto), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXVII_INTERNADO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Internado), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXVII_PREGUNTA_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.SumaFallecimiento), PdfStyles.CellType.CONTENIDO));

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCIONXVII_CONDICIONES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            _tables.Add(table);

            return _tables;
        }



    }

    public class CuestionarioEnfermedadesRespiratoriasGenerator : SectionGenerator
    {
        public CuestionarioEnfermedadesRespiratoriasGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(DatosPA datosPa, CuestionarioXIII cuestionario, string nroSolicitud)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateQuestionnaireTitle(Resource.SECCIONXIII_TITULO, Resource.SECCION_NRO, nroSolicitud));

            _tables.Add(GenerateSubtitle(Resource.SECCIONXIII_PA_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 122.48f, 60.71f, 285 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NumeroDocumento, datosPa.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_DIAGNOSTICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(cuestionario.Diagnostico, PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FECHA_INICIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaInicioEnf), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FECHA_FIN, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaUltEpisodio), PdfStyles.CellType.CONTENIDO));


            table.AddCell(GenerateCell("4", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_CANTIDAD, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            foreach (var t in GenerateCellMultiline(InfoFormatterHelper.Format(cuestionario.CantEpiAnuales), PdfStyles.CellType.CONTENIDO, lineCount: 2, percent: 95))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(t);
            }

            table.AddCell(GenerateCell("5", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FRECUENCIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));


            foreach (var t in GenerateCellMultiline(InfoFormatterHelper.Format(cuestionario.FrecuenciaEpisodios), PdfStyles.CellType.CONTENIDO, lineCount: 2, percent: 95))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(t);
            }

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 5, 10, 80, 5 });
            table.AddCell(GenerateCell("6", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FUE_HOSPITALIZADO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Hospitalizado), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FECHA_HOSPITALIZADO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaHosp), PdfStyles.CellType.CONTENIDO, colspan: 2));

            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 5, 95 });
            table.AddCell(GenerateCell("7", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FECHA_ULT_CONSULTA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaUltConsulta), PdfStyles.CellType.CONTENIDO));


            table.AddCell(GenerateCell("8", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_NOMBRE_MEDICO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            foreach (var t in GenerateCellMultiline(InfoFormatterHelper.Format(cuestionario.NomApMedico), PdfStyles.CellType.CONTENIDO, lineCount: 3, percent: 95))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(t);
            }

            table.AddCell(GenerateCell("9", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_TRATAMIENTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            foreach (var t in GenerateCellMultiline(InfoFormatterHelper.Format(cuestionario.TratamientoInd), PdfStyles.CellType.CONTENIDO, lineCount: 4, percent: 95))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                table.AddCell(t);
            }

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 5, 10, 80, 5 });
            table.AddCell(GenerateCell("10", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_ESTUDIOS_PULMON, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EstPulmonar), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_FECHA_EST_PULMON, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechasPulmonar), PdfStyles.CellType.CONTENIDO, colspan: 2));

            int i = 0;
            foreach (var t in GenerateCellMultilineFirst(InfoFormatterHelper.Format(cuestionario.Resultados), PdfStyles.CellType.CONTENIDO, lineCount: 4, colspan: 3, colspanFirstLine: 2, percent: 95, percentFirstLine: 85))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                if (i == 0)
                {
                    table.AddCell(GenerateCell(Resource.SECCIONXIII_RESULTADO_EST_PULMON, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                    i++;
                }
                table.AddCell(t);
            }
            table.AddCell(GenerateCell("11", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIII_ENF_ASOCIADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EnfAsociada), PdfStyles.CellType.CONTENIDO));

            //table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
            //table.AddCell(GenerateCell(Resource.SECCIONXIII_ESPECIFICACION_ENF_ASOCIADA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            //table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Especificacion), PdfStyles.CellType.CONTENIDO, colspan: 2));
            i = 0;
            foreach (var t in GenerateCellMultilineFirst(InfoFormatterHelper.Format(cuestionario.Especificacion), PdfStyles.CellType.CONTENIDO, lineCount: 3, colspan: 3, colspanFirstLine: 2, percent: 95, percentFirstLine: 85))
            {
                table.AddCell(GenerateCell(" ", PdfStyles.CellType.MARGIN));
                if (i == 0)
                {
                    table.AddCell(GenerateCell(Resource.SECCIONXIII_ESPECIFICACION_ENF_ASOCIADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                    i++;
                }
                table.AddCell(t);
            }


            _tables.Add(table);

            return _tables;
        }

    }

    public class CuestionarioEmbarazoGenerator : SectionGenerator
    {
        private const int CANTIDAD_LINEAS_DETALLE = 15;
        private const int CANTIDAD_LINEAS_MAX = 20;
        private List<PdfPTable> _extraTablesDetalles = new List<PdfPTable>();
        private int _lineCount = 0;
     
        public CuestionarioEmbarazoGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
            _extraTablesDetalles = new List<PdfPTable>();
            _lineCount = 0;
        }

        public IEnumerable<PdfPTable> Generate(DatosPA datosPa, CuestionarioXIV cuestionario, IEnumerable<Provincia> provincias, IQueryable<Domicilio> addressQuery, string nroSolicitud)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateQuestionnaireTitle(Resource.SECCIONXIV_TITULO, Resource.SECCION_NRO, nroSolicitud));
            _tables.Add(GenerateSubtitle(Resource.SECCIONXIV_PA_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 122.48f, 60.71f, 285 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NumeroDocumento, datosPa.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            Add1a2(cuestionario);
            Add3a7(cuestionario);
            Add8(cuestionario);
            Add9(cuestionario, provincias, addressQuery);

            return _tables;
        }


        private void Add1a2(CuestionarioXIV cuestionario)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 20, 75 });
            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_SEMANA_ACTUAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.SemanaGest), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_FECHA_ESTIMADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaParto), PdfStyles.CellType.CONTENIDO));

            _tables.Add(table);
        }

        private void Add3a7(CuestionarioXIV cuestionario)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 20, 6, 15, 54 });
            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_PRIMER_EMBARAZO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.PrimerEmbarazo), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_CANTIDAD_HIJOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));

            if (cuestionario.PrimerEmbarazo.HasValue && !cuestionario.PrimerEmbarazo.Value)
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.CantidadHijos), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 5, 20, 6, 10, 10, 7, 42 });
            table.AddCell(GenerateCell("4", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_EMBARAZOS_ECTOPICOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EmbEctopicos), PdfStyles.CellType.CONTENIDO));

            if (cuestionario.EmbEctopicos.HasValue && cuestionario.EmbEctopicos.Value)
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_FECHA_ECTOPICOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaEstimadaEmbEc), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_SECUELAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Secuelas), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_FECHA_ECTOPICOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_SECUELAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }

            table.AddCell(GenerateCell("5", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_ABORTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Abortos), PdfStyles.CellType.CONTENIDO));

            if (cuestionario.Abortos.HasValue && cuestionario.Abortos.Value)
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_FECHA_ABORTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.FechaEstAborto), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_ABORTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MotivoAborto), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_FECHA_ABORTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_ABORTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }

            table.AddCell(GenerateCell("6", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_CESAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Cesareas), PdfStyles.CellType.CONTENIDO));

            if (cuestionario.Cesareas.HasValue && cuestionario.Cesareas.Value)
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_CANTIDAD_CESAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.CantCesareas), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_CESAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MotivoCesarea), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_CANTIDAD_CESAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_CESAREAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }

            table.AddCell(GenerateCell("7", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_CESAREA_PROGRAMADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.PartoProgramado), PdfStyles.CellType.CONTENIDO));

            if (cuestionario.PartoProgramado.HasValue && cuestionario.PartoProgramado.Value)
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_CESAREA_PROGRAMADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MotivoPartoProg), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_MOTIVO_CESAREA_PROGRAMADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            _tables.Add(table);
        }

        private void Add8(CuestionarioXIV cuestionario)
        {
            /////
            var table = GenerateTable(PageWidth, new float[] { 5, 5, 90, 5 });
            table.AddCell(GenerateCell("8", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_ENFERMEDADES_PREGUNTA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("a", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_SOBREPESO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Sobrepeso), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("b", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_DIABETES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Diabetes), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("c", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_HIPERTENSION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.TensionArterial), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("d", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_ENF_RENAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EnfermedadRenal), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("e", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_ANEMIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Anemia), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("f", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_EDEMA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Edema), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("g", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_TROMBOSIS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Trombosis), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("h", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_PLACENTA_PREVIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Placenta), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("i", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_OTRAS_PATOLOGIAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.OtrasPatologias), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_PA_OTRAS_ENF, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, colspan: 3));
            _tables.Add(table);

            //Detalles:
            _lineCount = 0;
            table = GenerateTable(PageWidth, new float[] { 5, 95 });
            if (cuestionario.Sobrepeso.HasValue && cuestionario.Sobrepeso.Value && !string.IsNullOrEmpty(cuestionario.DetalleSobrepeso))
                _lineCount += AddDetailCells(table, "a: " + cuestionario.DetalleSobrepeso, 95);

            if (cuestionario.Diabetes.HasValue && cuestionario.Diabetes.Value && !string.IsNullOrEmpty(cuestionario.DetalleDiabetes))
                _lineCount += AddDetailCells(table, "b: " + cuestionario.DetalleDiabetes, 95);

            if (cuestionario.TensionArterial.HasValue && cuestionario.TensionArterial.Value && !string.IsNullOrEmpty(cuestionario.DetalleTensionArt))
                _lineCount += AddDetailCells(table, "c: " + cuestionario.DetalleTensionArt, 95);

            if (cuestionario.EnfermedadRenal.HasValue && cuestionario.EnfermedadRenal.Value && !string.IsNullOrEmpty(cuestionario.DetalleEnfRenal))
                _lineCount += AddDetailCells(table, "d: " + cuestionario.DetalleEnfRenal, 95);

            if (cuestionario.Anemia.HasValue && cuestionario.Anemia.Value && !string.IsNullOrEmpty(cuestionario.DetalleAnemia))
                _lineCount += AddDetailCells(table, "e: " + cuestionario.DetalleAnemia, 95);

            if (cuestionario.Edema.HasValue && cuestionario.Edema.Value && !string.IsNullOrEmpty(cuestionario.DetalleEdema))
                _lineCount += AddDetailCells(table, "f: " + cuestionario.DetalleEdema, 95);

            if (cuestionario.Trombosis.HasValue && cuestionario.Trombosis.Value && !string.IsNullOrEmpty(cuestionario.DetalleTrombosis))
                _lineCount += AddDetailCells(table, "g: " + cuestionario.DetalleTrombosis, 95);

            if (cuestionario.Placenta.HasValue && cuestionario.Placenta.Value && !string.IsNullOrEmpty(cuestionario.DetallePlacenta))
                _lineCount += AddDetailCells(table, "h: " + cuestionario.DetallePlacenta, 95);

            if (cuestionario.OtrasPatologias.HasValue && cuestionario.OtrasPatologias.Value && !string.IsNullOrEmpty(cuestionario.DetalleOtrasPatologias))
                _lineCount += AddDetailCells(table, "i: " + cuestionario.DetalleOtrasPatologias, 95);
            _tables.Add(table);
            for (; _lineCount < CANTIDAD_LINEAS_DETALLE; _lineCount++)
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO, colspan: 3));
            }
        }
       
        private int AddDetailCells(PdfPTable table, string text, float porcentaje)
        {
            var list = GenerateCellMultilineAndStops(text, PdfStyles.CellType.CONTENIDO, colspan: 3, percent: porcentaje);
            foreach (var cell in list)
            {
                if (_lineCount <= CANTIDAD_LINEAS_MAX)
                {
                    table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                    table.AddCell(cell);
                }
                else
                {
                    var extraTable = GenerateTable(PageWidth, new float[] { 5, 95 });
                    extraTable.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                    extraTable.AddCell(cell);
                    _extraTablesDetalles.Add(extraTable);
                }
            }
            return list.Count();
        }

        private void Add9(CuestionarioXIV cuestionario, IEnumerable<Provincia> provincias, IQueryable<Domicilio> addressQuery)
        {
            /////
            var table = GenerateTable(PageWidth, new float[] { 5, 5, 40, 10, 40 });
            table.AddCell(GenerateCell("9", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_DATOS_MEDICO_TITULO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 4));

            table.AddCell(GenerateCell(Resource.SECCIONXIV_DATOS_MEDICO_NOMBRE, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.NombreMedico), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_DATOS_MEDICO_APELLIDO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ApellidoMedico), PdfStyles.CellType.CONTENIDO));

            if (_lineCount < CANTIDAD_LINEAS_MAX)
            {
                _tables.Add(table);
                _lineCount++;
            }
            else
                _extraTablesDetalles.Add(table);

            _lineCount += 2;//las lineas del domicilio
            if (_lineCount < CANTIDAD_LINEAS_MAX)
            {
                AddAddress(Resource.SECCIONXIV_DATOS_MEDICO_DOMICILIO, addressQuery, cuestionario.DomMedico, provincias);
            }
            else
            {
                AddAddress(Resource.SECCIONXIV_DATOS_MEDICO_DOMICILIO, addressQuery, cuestionario.DomMedico, provincias, _extraTablesDetalles);
            }
            table = GenerateTable(PageWidth, new float[] { 5, 5, 10, 10, 30, 10, 30 });

            table.AddCell(GenerateCell(Resource.SECCIONXIV_DATOS_MEDICO_TELEFONO, PdfStyles.CellType.ENCABEZADO_GRILLA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.FormatPhone(cuestionario.TelMedico), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXIV_DATOS_MEDICO_EMAIL, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MailMedico), PdfStyles.CellType.CONTENIDO, colspan: 3));

            if (_lineCount < CANTIDAD_LINEAS_MAX)
            {
                _tables.Add(table);
                _lineCount++;
            }
            else
                _extraTablesDetalles.Add(table);
        }

        public List<PdfPTable> GenerateExtras()
        {
            return _extraTablesDetalles;
        }
    }

    public class CuestionarioDrogasGenerator : SectionGenerator
    {
        private int _cantidadLineas = 0;
        private List<PdfPTable> _extraTables;
        private const int CANTIDAD_MAXIMA_CONSUMOS = 5;
        private const int CANTIDAD_MAXIMA_LINEAS_HOJA = 39;
        public CuestionarioDrogasGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
            _extraTables = new List<PdfPTable>();
        }
        
        private void AddTable(PdfPTable tabla, int cantidadLineasOcupa = 1)
        {
            if(_cantidadLineas + cantidadLineasOcupa > CANTIDAD_MAXIMA_LINEAS_HOJA)
            {
                _extraTables.Add(tabla);
            }
            else
            {
                _tables.Add(tabla);
                _cantidadLineas += cantidadLineasOcupa;
            }
            
        }

        public IEnumerable<PdfPTable> GenerateExtras()
        {
            return _extraTables;
        }

        public IEnumerable<PdfPTable> Generate(DatosPA datosPa, CuestionarioXV cuestionario, IEnumerable<DatosConsumoDroga> datosConsumoDroga, string nroSolicitud)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateQuestionnaireTitle(Resource.SECCIONXV_TITULO, Resource.SECCION_NRO, nroSolicitud));

            _tables.Add(GenerateSubtitle(Resource.SECCIONXV_PA_TITULO));

            var table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 122.48f, 60.71f, 285 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NumeroDocumento, datosPa.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            Add1(cuestionario, datosConsumoDroga);
            Add2(cuestionario);
            Add3(cuestionario);
            Add4a6(cuestionario);

            return _tables;
        }


        private void Add1(CuestionarioXV cuestionario, IEnumerable<DatosConsumoDroga> datosConsumoDroga)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 5, 90, 5 });
            table.AddCell(GenerateCell("1", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_HA_CONSUMIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("a", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_ANFETAMINAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioAnfetaminas), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("b", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_BARBITURICOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioBarbituricos), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("c", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_CANNABIS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioCannabis), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("d", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_CACAINA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioCocaina), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("e", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_ALUCINOGENOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioAlucinogenos), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("f", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_OPIACEOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioOpiaceos), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("g", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_SEDATIVOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioSedativos), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell("h", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_OTROS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioOtrasDrogas), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONXV_MAS_INFORMACION, PdfStyles.CellType.COMENTARIO_ENCABEZADO_PREGUNTA, colspan: 3));
            
            AddTable(table, cantidadLineasOcupa: 10);

            table = GenerateTable(PageWidth, new float[] { 5, 19, 19, 19, 19, 19 });
            table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
            table.AddCell(GenerateCell(Resource.SECCIONXV_NOMBRE_FARMACO, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_CANTIDAD, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_FRECUENCIA, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_DURACION, PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_ULTIMO_CONSUMO, PdfStyles.CellType.ENCABEZADO_GRILLA));

            foreach (var datos in datosConsumoDroga)
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(datos.Tipo), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(datos.Cantidad), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(datos.Frecuencia), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(datos.Duracion), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(datos.UltimoConsumo), PdfStyles.CellType.CONTENIDO));
            }

            for (int i = datosConsumoDroga.Count(); i < CANTIDAD_MAXIMA_CONSUMOS; i++)
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            //_tables.Add(table);
            AddTable(table, cantidadLineasOcupa: Math.Max(datosConsumoDroga.Count(), CANTIDAD_MAXIMA_CONSUMOS) + 1);//Sumo una linea mas por el encabezado
        }


        private void Add2(CuestionarioXV cuestionario)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
            table.AddCell(GenerateCell("2", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONXV_TRATAMIENTO_1, Resource.SECCIONXV_TRATAMIENTO_2), PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.RealizoTratamientoDrogas), PdfStyles.CellType.CONTENIDO));

            AddTable(table, cantidadLineasOcupa: 1);
            
            var texto = string.Empty;
            if (cuestionario.RealizoTratamientoDrogas.HasValue && cuestionario.RealizoTratamientoDrogas.Value)
            {
                texto = InfoFormatterHelper.Format(cuestionario.TratamientoDrogas);
            }
            foreach (var t in GenerateCellMultiline(texto, PdfStyles.CellType.CONTENIDO, colspan: 3, lineCount: 4, percent: 90))
            {
                table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(t);
                AddTable(table, cantidadLineasOcupa: 1);
            }
        }

        private void Add3(CuestionarioXV cuestionario)
        {

            var table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });

            table.AddCell(GenerateCell("3", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_INTRAVENOSA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumioDrogasIntravenosa), PdfStyles.CellType.CONTENIDO));

            AddTable(table, cantidadLineasOcupa: 1);
            
            table = GenerateTable(PageWidth, new float[] { 5, 18, 50, 22, 5 });

            if (cuestionario.ConsumioDrogasIntravenosa.HasValue && cuestionario.ConsumioDrogasIntravenosa.Value)
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(Resource.SECCIONXV_LUGAR_AGUJAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.DondeObtuvoJeringas), PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXV_COMPARTIO_JERINGAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.CompartioJeriingas), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(GenerateCell(Resource.SECCIONXV_LUGAR_AGUJAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
                table.AddCell(GenerateCell(Resource.SECCIONXV_COMPARTIO_JERINGAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.CONTENIDO));
            }
            AddTable(table, cantidadLineasOcupa: 1);
        }

        private void Add4a6(CuestionarioXV cuestionario)
        {
            var table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
            table.AddCell(GenerateCell("4", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONXV_ENF_RELACIONADA_1, Resource.SECCIONXV_ENF_RELACIONADA_2), PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.PadecioEnfermedad), PdfStyles.CellType.CONTENIDO));

            AddTable(table, cantidadLineasOcupa: 2);

            var textoPadecioEnfermedad = string.Empty;
            if (cuestionario.PadecioEnfermedad.HasValue && cuestionario.PadecioEnfermedad.Value)
            {
                textoPadecioEnfermedad = InfoFormatterHelper.Format(cuestionario.EnfermedadDrogas);
            }
            foreach (var t in GenerateCellMultiline(textoPadecioEnfermedad, PdfStyles.CellType.CONTENIDO, lineCount: 4, percent: 90, colspan: 3))
            {
                table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(t);
                AddTable(table, cantidadLineasOcupa: 1);
            }

            table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
            table.AddCell(GenerateCell("5", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(string.Format("{0}\n{1}", Resource.SECCIONXV_CONSUME_1, Resource.SECCIONXV_CONSUME_2), PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.ConsumeDrogas), PdfStyles.CellType.CONTENIDO));
            AddTable(table, cantidadLineasOcupa: 1);

            var textoDrogasConsumidas = string.Empty;
            if (cuestionario.ConsumeDrogas.HasValue && cuestionario.ConsumeDrogas.Value)
            {
                textoDrogasConsumidas = InfoFormatterHelper.Format(cuestionario.DograsConsumidas);
            }
            foreach (var t in GenerateCellMultiline(textoDrogasConsumidas, PdfStyles.CellType.CONTENIDO, percent: 90, colspan: 3, lineCount: 3))
            {
                table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(t);
                AddTable(table, cantidadLineasOcupa: 1);
            }

            table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
            table.AddCell(GenerateCell("6", PdfStyles.CellType.ENCABEZADO_GRILLA));
            table.AddCell(GenerateCell(Resource.SECCIONXV_MAS_INFO_DROGAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));
            AddTable(table, cantidadLineasOcupa: 1);

            foreach (var t in GenerateCellMultiline(InfoFormatterHelper.Format(cuestionario.InformacionAdicional), PdfStyles.CellType.CONTENIDO, percent: 90, colspan: 3, lineCount: 3))
            {
                table = GenerateTable(PageWidth, new float[] { 5, 5, 85, 5 });
                table.AddCell(GenerateCell(string.Empty, PdfStyles.CellType.MARGIN));
                table.AddCell(t);
                AddTable(table, cantidadLineasOcupa: 1);
            }
        }
    }

    public class CuestionarioInfoFinancieraGenerator : SectionGenerator
    {
        public CuestionarioInfoFinancieraGenerator(float pageWidth, IEnumerable<TipoDocumento> tipoDoc)
            : base(pageWidth, tipoDoc)
        {
        }

        public IEnumerable<PdfPTable> Generate(DatosPA datosPa, CuestionarioXVI cuestionario, IEnumerable<TipoSociedad> tipoSociedad, IEnumerable<TipoProposito> tipoProposito, string nroSolicitud)
        {
            _tables = new List<PdfPTable>();

            _tables.Add(GenerateQuestionnaireTitle(Resource.SECCIONXVI_TITULO, Resource.SECCION_NRO, nroSolicitud));

            var table = GenerateTable(PageWidth, new float[] { 100 });
            table.AddCell(GenerateCell(Resource.SECCIONXVI_LEYENDA_CONFIDENCIALIDAD, PdfStyles.CellType.GRID_FOTTER_COMMENT));
            _tables.Add(table);

            _tables.Add(GenerateSubtitle(Resource.SECCIONXVI_PA_TITULO));

            table = GenerateTable(PageWidth, new float[] { 48.39f, 202.47f, 50.90f, 241.83f });
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_NOMBRE, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(datosPa.Nombres, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_APELLIDO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(datosPa.Apellidos, PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 75.14f, 122.48f, 60.71f, 285 });
            table.AddCell(GenerateCell(Resource.DOCUMENTOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateIDCell(datosPa.NumeroDocumento, datosPa.TipoDocumento, PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONA_INFO_PA_FECHA_NACIMIENTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(datosPa.FechaNacimiento), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 50, 50 });
            table.AddCell(GenerateCell(Resource.SECCIONXVI_PA_LEYENDA_FECHA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Fecha), PdfStyles.CellType.CONTENIDO));
            _tables.Add(table);

            AddBalancePersonal(cuestionario);
            AddBreveBalanceComercial(cuestionario, tipoSociedad, tipoProposito);
            return _tables;
        }

        private void AddBalancePersonal(CuestionarioXVI cuestionario)
        {
            _tables.Add(GenerateSubtitle(Resource.SECCIONXVI_BAL_PERS_TITULO, Resource.SECCIONXVI_BAL_PERS_COMENTARIO_TITULO));
            _tables.Last().SpacingAfter = 4f;

            var table = GenerateTable(PageWidth, new float[] { 10, 25, 30, 15, 10, 15 });
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_ACTIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 5));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_EFECTIVO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EftLiquidos), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoEftLiq, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_TOTAL, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 7));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.TotalActivos, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, rowspan: 7));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_PROPIEDAD_PERSONAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.PropPers), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoPropPers, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_BIENES_RAICES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Bienes), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoBienes, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_INVERSIONES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Inversiones), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoInversiones, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_OTROS_ACTIVOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.OtrosAct), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoOtrosAct, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_PASIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_HIPOTECAS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Hipotecas), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoHipotecas, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_OTROS_PASIVOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.OtrosPas), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoOtrosPas, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_INGRESOS_ANUALES, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 3));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_REMUNERACION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Remuneracion), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoRemuneracion, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_TOTAL_INGRESOS_ANUALES, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 3));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.TotalIngresos, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, rowspan: 3));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_BONOS, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Bonos), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoBonos, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_PERS_RENTA_POR_INVERSIONES, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Renta), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoRenta, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.SpacingAfter = 6f;
            _tables.Add(table);
        }

        private void AddBreveBalanceComercial(CuestionarioXVI cuestionario, IEnumerable<TipoSociedad> tipoSociedad, IEnumerable<TipoProposito> tipoProposito)
        {
            _tables.Add(GenerateSubtitle(Resource.SECCIONXVI_BAL_COM_TITULO));

            _tables.Last().SpacingAfter = -4f;

            var table = GenerateTable(PageWidth, new float[] { 18, 34, 5, 43 });
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_RAZON_SOCIAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Nombre), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_RUBRO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Rubro), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_TIPO_ORGANIZACION, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<TipoSociedad>(tipoSociedad, PdfStyles.CellType.CONTENIDO, cuestionario.Tipo, colspan: 3));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_PROPOSITO_SEGURO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell<TipoProposito>(tipoProposito, PdfStyles.CellType.CONTENIDO, cuestionario.Proposito, colspan: 3));

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 18, 8, 3, 13, 10, 48 });

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_PORCENTAJE_NEGOCIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Porcentaje), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_SUMA_ASEGURADA, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 3));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Factores), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_OTRO_ACTIVO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.OtroActivo), PdfStyles.CellType.CONTENIDO, colspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_MONTO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            if (cuestionario.OtroActivo.HasValue && cuestionario.OtroActivo.Value)
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoOtroActivo, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(string.Empty, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            }

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_OTRO_INDIVIDUO_SIMILAR, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.OtroIndividuo), PdfStyles.CellType.CONTENIDO, colspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_INDIVIDUO, PdfStyles.CellType.ENCABEZADO_PREGUNTA, colspan: 2));
            if (cuestionario.OtroIndividuo.HasValue && cuestionario.OtroIndividuo.Value)
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.EspOtroIndividuo), PdfStyles.CellType.CONTENIDO));
            }
            else
            {
                table.AddCell(GenerateCell(InfoFormatterHelper.Format(string.Empty), PdfStyles.CellType.CONTENIDO));
            }
            _tables.Add(table);


            table = GenerateTable(PageWidth, new float[] { 10, 50, 15, 10, 15 });

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_ACTIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_EFECTIVO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Corriente, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_TOTAL_ACTIVO, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.TotalActivosBalance, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, rowspan: 2));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_FIJO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Fijo, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_PASIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_CORTO_PLAZO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.CortoPlazo, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_TOTAL_PASIVOS, PdfStyles.CellType.ENCABEZADO_GRILLA, rowspan: 2));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.TotalPasivosBalance, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, rowspan: 2));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_LARGO_PLAZO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.LargoPlazo, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, rowspan: 2));

            _tables.Add(table);

            table = GenerateTable(PageWidth, new float[] { 16, 5, 6, 15, 5, 6, 15, 5, 6, 15 });

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_FACTURACION_ANUAL, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.Facturacion, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO, colspan: 9));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_GANANCIA, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_ANIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.GananciaAnio1), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoGananciaAnio1, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_ANIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.GananciaAnio2), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoGananciaAnio2, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            table.AddCell(GenerateCell(Resource.SECCIONXVI_BAL_COM_ANIO, PdfStyles.CellType.ENCABEZADO_PREGUNTA));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.GananciaAnio3), PdfStyles.CellType.CONTENIDO));
            table.AddCell(GenerateCell(InfoFormatterHelper.Format(cuestionario.MontoGananciaAnio3, InfoFormatterHelper.Symbols.ARS, null), PdfStyles.CellType.CONTENIDO));

            _tables.Add(table);
        }


    }
}

