﻿using Pea.Model;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Pea.Business.Helpers
{
    public static class LoggerHelper
    {

        public static string GetCurrentMethodFromMethodBase(MethodBase methodBase)
        {
            var interfaceName = ((MemberInfo)methodBase).DeclaringType.FullName;
            var methodName = methodBase.Name;
            var fullSignature = interfaceName + '.' + methodName;
            return fullSignature;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethodFromStackTrace(int frameIndex = 1)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(frameIndex);

            return GetCurrentMethodFromMethodBase(sf.GetMethod());
        }


        public static void ExceptionCatchAndLog(Action fn, string className = null, string data = null)
        {
            try
            {
                fn();
            }
            catch (Exception ex)
            {
                className = LogException(ex, className, data, 3);
            }

        }

        public static T ExceptionCatchAndLog<T>(Func<T> fn, string className = null, string data = null)
        {
            try
            {
                return fn();
            }
            catch (Exception ex)
            {
                className = LogException(ex, className, data, 3);
            }
            return default(T);
        }

        public static string LogException(Exception ex, string className = null, string data = null, int frameIndex = 2)
        {
            var username = string.Empty;
            try
            {
                username = UserBusiness.GetMyUserName();
            }
            catch (Exception)
            {

            }
            try
            {
                className = className == null ? GetCurrentMethodFromStackTrace(frameIndex) : className;
            }
            catch (Exception)
            {
                className = string.Empty;
            }

            using (var ctx = new Pea.DataAccess.BaseContext<Log>().GetDbCtx())
            {


                var log = new Log();
                log.msg = ex.ToString();
                log.id = log.gid = log.ver = Guid.NewGuid().ToString();
                log.del = false;
                log.serverupdated = log.updated = log.created = DateTime.UtcNow;
                log.createdby = log.updatedby = log.usuario = username;
                log.tipo = "error";
                log.data = data;
                log.clientType = "s";
                log.className = className;
                log.stack = ex.StackTrace.ToString();
                ctx.Log.Add(log);
                ctx.SaveChanges();

            }

            return className;
        }
    }
}
