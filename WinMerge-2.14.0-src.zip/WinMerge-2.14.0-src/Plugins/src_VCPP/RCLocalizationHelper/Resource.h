//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RCLocalizationHelper.rc
//
#define IDS_PROJNAME                    100
#define IDR_WINMERGESCRIPT              101
#define IDS_EXT_NOT_DLL                 101
#define IDS_BAD_IGNORE_LINES_COUNT      102
#define IDS_MISSING_IGNORE_ENTRY        103
#define IDS_BAD_EXP                     104
#define IDS_BAD_SUBS_COUNT              105
#define IDS_MISSING_SUBS_ENTRY          106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
