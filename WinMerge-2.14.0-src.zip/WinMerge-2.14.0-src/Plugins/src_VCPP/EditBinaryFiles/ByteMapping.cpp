#include "ByteMapping.h"

bool
ByteMapping::Map(unsigned char * byte)
{
	if (byte == '#')
}

