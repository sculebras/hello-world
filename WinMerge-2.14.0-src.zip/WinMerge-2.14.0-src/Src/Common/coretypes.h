#ifndef CORETYPES_H
#define CORETYPES_H

#ifndef countof
#define countof(array)  (sizeof(array)/sizeof((array)[0]))
#endif /* countof */

#endif

