WINMERGE

WinMerge Windowserako Iturri Irekiko alderaketa eta batuketa tresna bat da. 
WinMergek bi agiritegi eta bi agiri alderatu ditzake, ezberdintasunak  ulertzeko 
eta kudeatzeko erraza den ikus idazki heuskarrian aurkeztuz.
WinMergek kanpoko ezberdintze/batze tresna bezala erabili daiteke edo aplikazio aske bezala.

WinMerge oso lagungarria da alderaketak, aldiberetzeak eta batuketak ahalik eta errazen eta erabilgarrien egiteko. 
Programazio hizkuntza ugari eta beste agiri heuskarriak joskera-nabarmenduak dira.

WinMergeren azken bertsioa eta WinMerge argibideak eskuragarri daude hemen:
http://winmerge.org/.

Hasiera Azkarra
===========
WinMerge ezarri ondorengo ohinarrizko eragiketak nola egin jakiteko, klikatu
Laguntza>WinMerge Laguntza eta nabigatu Hasiera Azkarra gaian. Edo, joan Webgune
bertsio honetara: http://manual.winmerge.org/QuickStart.html.

WinMerge Laguntza
============= 
WinMerge Laguntza ordenagailuan ezartzen da Microsoft HTML Laguntza agiri bezala, WinMerge.chm,
WinMerge ezartzen duzunean. Laguntza irekitzeko, klikatu Laguntza>WinMerge Laguntza edo sakatu F1
WinMerge leihoan. Komando lerroan, ekin WinMerge exekutagarriari /? laguntza giltzarekin.

WinMerge Laguntzaren HTML bertsioa hemen ere bilatu dezakezu:
http://manual.winmerge.org/.

Agiri Sostengua
===============
WinMergek 7-Zip (http://www.7-zip.org) Iturri Irekiko agiri tresna erabiltzen du
agiri sostengua agiritegiratzeko. 7-Zip aplikazioa ezartzea gomendatzen dugu
jeitsiz eta abiaraziz 7-Zip plugin ezartzailea hemendik:
http://winmerge.org/downloads/.

Ezin baduzu 7-Zip tresna ezarri zerbaitengaitik, 7-zip plugin ezartzailea 
erabili dezakezu agiri sostengurako beharrezkoak diren agiriak bakarrik ezarriz.
Ikusi Laguntza gaia, "7-Zip eta agiri sostengua" xehetasunetarako.

WinMerge Sostengua
================
Galderarik edo iradokizunik WinMergeri buruz? Hasteko toki on bat WinMerge
herkidego boletina da: http://forums.winmerge.org/. Garatzaileek sarri irakurtzen
eta erantzuten dizkiete galderei bi eztabaidaguneetan. Erabili Ireki Eztabaida gunea
WinMergeri buruzko galdera orokorrak egiteko. Erabili Garatzaile eztabaidagunea
WinMergeren garapenari buruzko galderentzat.

Akatsak eta Eginkizun Eskabideak
=========================
Gairen bat konpondu gabe badago WinMerge eztabaidagunetan, egiaztatu egitasmo
aztarnariak hona joz: http://project.winmerge.org/, eta klikatu Aztarnarien menuko 
loturan, Akatsak eta Eginkizun Eskabideak, non gaiak bilatu edo aurkeztu ahal izango dituzun.

Akats bat aurkezten baduzu, mesedez barneratu WinMerge bertsio zenbakia zure jakinarazpenean.
Ohar itxurapen bat sortu dezakezu klikatuz Laguntza>Itxurapena.
Mesedez jaso itxurapen ohar-agiria akats jakinarazpenean; argibide oso erabilgarriak ditu garatzaileentzat.


- WinMerge Garatzaileak
