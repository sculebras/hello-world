Graphics:
Alexander Skinner
neonapple@users.sourceforge.net

For WinMerge

Dimensions: 436 x 100
Resolution: 72 DPI

PNG Images
---
WinMerge_logo_shadow_24bit.png (Subtle Dropshadow, White Background)
WinMerge_logo_24bit.png (Flat, White Background)


TIFF Images
---
WinMerge_logo_shadow_trans.tif (Subtle Dropshadow, Transparent Background)
WinMerge_logo_trans.tif (Flat, Transparent Background)